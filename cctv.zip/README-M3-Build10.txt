TAPO/RTSP CCTV Streamer by @neddscape — Native M3 · Build 10
=============================================================

CCTV-Streamer-M3-Build10.exe — replaces Build 9. Swap the exe;
settings.json carries over (it gains "rotate", "rotsec" and a
per-camera "rot" flag). Keep camerawall_m3.cpp / .rc / .ico
next to the exe — the source-law from §24 continues.

YOUR ITEMS
----------
1. CAMERA ROTATION. Your parked cameras now cycle through the
   open panes.
   · ⚙ Settings gains two rows under MS UPDATE:
       ROTATION      OFF | ON        (default OFF — nothing
                                      changes until you enable it)
       ROTATE EVERY  3 s ——— 60 s    (slider, default 10 s)
   · When ON, ALL unlocked panes advance together every tick.
     Fair round-robin: whoever leaves the wall goes to the back
     of the queue, so every pool camera gets equal wall time.
   · SEAMLESS: the incoming cameras connect HIDDEN a few seconds
     before the tick, and the swap only fires once their frames
     are actually flowing — no CONNECTING flash, boom, live view.
     (If a camera refuses to come up, a 6 s grace runs out and
     the swap happens honestly — you'll see its real state.)
   · Both your choices persist in settings.json.

2. LOCK / POOL — two views of the same per-camera flag:
   · HOVER STRIP: while rotation is ON, a 🔓/🔒 button appears
     left of ↻. Click to lock — the border and padlock go LED
     cyan, that pane is pinned and never rotates out. Click
     again to release it back into the cycle.
   · ⚙ SETTINGS: every camera row now has a ⟳ box between the
     show-checkbox and the name. Filled cyan = in the rotation
     pool; empty = locked/excluded. Same flag as the strip
     button, ticked = rotating. Saved per camera.

3. STRIP SHADOW CUT DOWN. The hover strip's dark gradient is
   now a 46 px band instead of 84 px — same opacity, it just
   hugs the button row instead of climbing the picture.
   Nothing else on the strip was touched.

BEHAVIOUR NOTES
---------------
· Rotation politely pauses while you're in settings, an editor,
  any fullscreen, or mid-drag — and re-arms a fresh full
  interval when you come back.
· Any manual change (pane takeover, ✕/checkbox, drag, delete,
  RESET WALL) also resets the clock, so the wall never yanks a
  camera you just deliberately picked.
· Hidden preroll cameras never leak audio.
· With rotation OFF the wall is Build-9-identical (except the
  thinner strip shadow).

QUICK LOOK
----------
1. ⚙ -> ROTATION ON, ROTATE EVERY 5 s -> close settings ->
   after ~5 s all three panes flip to parked cameras at once,
   already live. Watch the log: "rotation preroll · connecting
   hidden" then "rotate: Gate -> K_Back, ..."
2. Hover a pane -> click 🔓 -> it turns 🔒 cyan -> that pane
   sits still while the others keep cycling.
3. ⚙ -> untick a camera's ⟳ box -> it drops out of the cycle.
4. Restart the app -> rotation state, interval and locks stuck.

For support, contact: neddscape@gmail.com
