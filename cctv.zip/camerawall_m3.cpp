// ============================================================================
//  TAPO/RTSP CCTV Streamer by @neddscape — Native M3 · Build 10
//  camerawall_m3.cpp — the entire application, single translation unit.
//
//  Build 10 (29 Aug 2026): CAMERA ROTATION — parked cameras cycle through
//    the open panes. All unlocked panes advance together every ROTATE EVERY
//    seconds (3–60 s slider, default 10); swaps are SEAMLESS: incoming
//    cameras pre-connect hidden a few seconds ahead and the wall only
//    advances once their frames are live (6 s grace, then honest swap).
//    Per-camera ⟳ pool membership: ⟳ checkbox in every settings row AND a
//    🔒 lock button on the hover strip (visible while rotation is on) —
//    both flip the same flag; locked cameras are pinned and never rotate.
//    ROTATION OFF/ON toggle + interval slider live under MS UPDATE.
//    Rotation pauses in settings/editor/fullscreen/drag and re-arms fresh
//    on resume; manual takeovers and pane toggles reset the clock.
//    settings.json v2 gains "rotate", "rotsec" and per-camera "rot".
//    Owner polish: the hover-strip scrim is cut down (84 → 46 px band,
//    same opacity ramp) so the shadow hugs the button row only.
//  Build 9 (1 Aug 2026): MS UPDATE slider under SOFTNESS (0.0 s = per-frame
//    to 3.0 s hold, default 1.0 s; stall climbs always live; persisted as
//    settings.json "msup"); ☰ grip added before each camera checkbox as
//    the visible drag-to-reorder handle (name area still drags too).
//  Build 8 (1 Aug 2026): the strip ms is the 5.3 LIVE-DELAY, not decode —
//    it shows the real-time gap between frame arrivals (bounces with
//    network jitter, climbs live to 800ms+ during stalls/reconnects, the
//    behaviour the owner described from Build 3). Decode time stays on
//    the D overlay. Settings column now sits on a framed panel (seam
//    border + subtle face) over the deep dim.
//  Build 7 (1 Aug 2026): latency readout fixed (the stopwatch now covers
//    decode + the d3d11 copy-back — hw decode had timed as 0 ms); settings
//    dim deepened (.86, editor .72); gear gets an always-on plate + hover
//    highlight and moved below the stamp line; every boxed glyph (strip
//    buttons, mute, gear, sheet pen/x, checkmark) is now centred by its
//    baked bitmap via drawTextC.
//  Build 6 (1 Aug 2026): owner's post-retest polish list — Build 3 strip
//    readouts restored (H264 · 21ms beside ↻, bordered buttons, cyan knob);
//    settings sheet rebuilt to the owner's Build 3 screenshot (full-window
//    overlay, version+contact under the title, CLOSE button, DISPLAY before
//    CAMERAS, HD/SD twin boxes, checkmark boxes, mono styling, list capped
//    9); all text baked at 2x and downsampled (smooth, uniform sizes);
//    stamps = letter-spaced uppercase mono; pen popup anchors lower-right
//    of ITS OWN pane; address fields open showing the full rtsp:// URL in
//    a wider box; text selection everywhere (drag, Shift+arrows,
//    Ctrl+A/C/X/V). Confirmed unchanged: zero background on close,
//    retry-forever engine, Build 3 performance architecture.
//  Build 5 (1 Aug 2026): Build 4 was DOA — two hand-written COM GUIDs were
//    each one digit off: IID_ID3D11Texture2D (swapchain GetBuffer returned
//    E_NOINTERFACE 0x80004002 -> "Direct3D 11 could not start") and
//    IID_IAudioClient (0x4C32, not 0x4C31 — would have muted the wall).
//    Both now verified against the platform headers. No other changes.
//  Build 4 (1 Aug 2026):
//    · NEW  double-click a pane  -> true fullscreen on the CURRENT MONITOR
//           (borderless, covers the taskbar, only that pane visible).
//           Double-click again, or Esc, returns to the normal window with
//           all panes showing. ⛶ is untouched: pane fills the WINDOW only.
//           Owner law: "⛶ always means window · double-click always means
//           monitor". While in monitor fullscreen ⛶ drops to the windowed
//           pane view. settings.json never stores the fullscreen bounds.
//    · This file is a from-the-record rebuild: the Build 3 source never
//      left its (incognito) build session. Rebuilt 1 Aug 2026 from the
//      project documentation + everything recoverable from
//      CCTV-Streamer-M3-Build3.exe (all UI strings, the complete HLSL
//      shader suite, log formats, settings writer, internal names).
//      Behaviour is intended to be Build-3-faithful; a full owner retest
//      is required. KEEP THIS FILE NEXT TO THE EXE FOREVER.
//
//  Sections: 1 utils/log · 2 data model + settings · 3 decode workers
//            4 WASAPI mixer · 5 D3D11 renderer + GDI baker · 6 wall UI
//            7 modals (sheet/editor) · 8 input + window + WinMain
//
//  Compile (see §18 of the documentation; camerawall.res via windres):
//    x86_64-w64-mingw32-g++-win32 -O2 -std=c++17 -mwindows camerawall_m3.cpp
//      camerawall.res -Iffbuild/include -Lffbuild/lib
//      -lavformat -lavcodec -lavutil -ld3d11 -ldxgi -ldxguid -luuid
//      -ld3dcompiler -lgdi32 -luser32 -lole32 -lws2_32 -lbcrypt -liphlpapi
//      -static -static-libgcc -static-libstdc++
// ============================================================================

#define WIN32_LEAN_AND_MEAN
#define NOMINMAX
#include <windows.h>
#include <windowsx.h>
#include <d3d11.h>
#include <dxgi1_2.h>
#include <d3dcompiler.h>
#include <mmreg.h>
#include <mmdeviceapi.h>
#include <audioclient.h>

#include <string>
#include <vector>
#include <map>
#include <atomic>
#include <algorithm>
#include <cmath>
#include <cstdio>
#include <cstdarg>
#include <cstring>
#include <cwctype>

extern "C" {
#include <libavformat/avformat.h>
#include <libavcodec/avcodec.h>
#include <libavutil/hwcontext.h>
#include <libavutil/imgutils.h>
#include <libavutil/opt.h>
#include <libavutil/time.h>
}

// ---------------------------------------------------------------- identity --
static const wchar_t* kTitle     = L"TAPO/RTSP CCTV Streamer by @neddscape \u2014 Native M3 \u00b7 Build 10";
static const wchar_t* kMilestone = L"Native M3";
static const wchar_t* kBuild     = L"Build 10";
static const wchar_t* kWndClass  = L"CCTVStreamerWall";      // recovered from Build 3 exe
static const wchar_t* kMutexName = L"CCTVStreamer_neddscape_single"; // recovered
static const wchar_t* kEmail     = L"neddscape@gmail.com";

// ------------------------------------------------------------------- GUIDs --
// Defined locally so the import table never grows past the documented set.
static const CLSID kCLSID_MMDeviceEnumerator = {0xBCDE0395,0xE52F,0x467C,{0x8E,0x3D,0xC4,0x57,0x92,0x91,0x69,0x2E}};
static const IID   kIID_IMMDeviceEnumerator  = {0xA95664D2,0x9614,0x4F35,{0xA7,0x46,0xDE,0x8D,0xB6,0x36,0x17,0xE6}};
static const IID   kIID_IAudioClient         = {0x1CB9AD4C,0xDBFA,0x4C32,{0xB1,0x78,0xC2,0xF5,0x68,0xA7,0x03,0xB2}};
static const IID   kIID_IAudioRenderClient   = {0xF294ACFC,0x3146,0x4483,{0xA7,0xBF,0xAD,0xDC,0xA7,0xC2,0x60,0xE2}};
static const GUID  kKSDATAFORMAT_FLOAT       = {0x00000003,0x0000,0x0010,{0x80,0x00,0x00,0xAA,0x00,0x38,0x9B,0x71}};
static const IID   kIID_IDXGIDevice          = {0x54EC77FA,0x1377,0x44E6,{0x8C,0x32,0x88,0xFD,0x5F,0x44,0xC8,0x4C}};
static const IID   kIID_IDXGIFactory2        = {0x50C83A1C,0xE072,0x4C48,{0x87,0xB0,0x36,0x30,0xFA,0x36,0xA6,0xD0}};
static const IID   kIID_ID3D11Texture2D      = {0x6F15AAF2,0xD208,0x4E89,{0x9A,0xB4,0x48,0x95,0x35,0xD3,0x4F,0x9C}};

// ----------------------------------------------------------------- palette --
#define C_BG      RGB(0x00,0x00,0x00)
#define C_PANEL   RGB(0x15,0x18,0x1C)
#define C_PANEL2  RGB(0x1B,0x1F,0x24)
#define C_FACE    RGB(0x10,0x13,0x16)
#define C_SEAM    RGB(0x2B,0x31,0x38)
#define C_TEXT    RGB(0xE8,0xED,0xF0)
#define C_DIM     RGB(0x9A,0xA4,0xAB)
#define C_LED     RGB(0x3D,0xDC,0xFF)
#define C_RED     RGB(0xFF,0x4D,0x4D)
#define C_WHITE   RGB(0xFF,0xFF,0xFF)
#define C_BLACK   RGB(0x00,0x00,0x00)

// ------------------------------------------------------------------ tuning --
static const int   CLEAN_COOL_MS   = 6000;   // Tapo slot release after a live session (§9.3)
static const int   READ_DEADLINE   = 8000;   // ms io/read deadline -> frozen-feed watchdog (§23.6)
static const int   STAGGER_MS      = 600;    // launch stagger between panes
static const int   MAX_PANES       = 9;      // 3×3 wall cap ("wall is full (9 panes)")
static const int   MAX_CAMS        = 16;     // list storage cap
static const int   HIST_MAX        = 12;     // remembered RTSP addresses (settings.json v2)
static const int   NAME_MAX        = 22;     // per-pane editor name limit
static const int   RING_N          = 32768;  // audio ring, s16 mono 8 kHz (~4 s)
static const int   SURE_MS         = 2500;   // two-click delete arm window
static const int   FADE_MS         = 120;    // modal fade-and-rise
static const float P010_SCALE      = 1.003906f; // 10-bit MSB-aligned correction

// -------------------------------------------------------------- forward IO --
static void  logf(const char* fmt, ...);
static void  saveSettings();
static void  sanitizeOrder();

// ------------------------------------------------------------------- utils --
static uint64_t nowMs() { return GetTickCount64(); }

static LARGE_INTEGER g_qpcF, g_qpc0;
static double appSec() { LARGE_INTEGER t; QueryPerformanceCounter(&t);
    return double(t.QuadPart - g_qpc0.QuadPart) / double(g_qpcF.QuadPart); }

static std::string toUtf8(const std::wstring& w) {
    if (w.empty()) return {};
    int n = WideCharToMultiByte(CP_UTF8, 0, w.c_str(), (int)w.size(), 0, 0, 0, 0);
    std::string s(n, 0);
    WideCharToMultiByte(CP_UTF8, 0, w.c_str(), (int)w.size(), &s[0], n, 0, 0);
    return s;
}
static std::wstring toWide(const std::string& s) {
    if (s.empty()) return {};
    int n = MultiByteToWideChar(CP_UTF8, 0, s.c_str(), (int)s.size(), 0, 0);
    std::wstring w(n, 0);
    MultiByteToWideChar(CP_UTF8, 0, s.c_str(), (int)s.size(), &w[0], n);
    return w;
}
static std::wstring wfmt(const wchar_t* f, ...) {
    wchar_t b[512]; va_list a; va_start(a, f); _vsnwprintf(b, 511, f, a); va_end(a);
    b[511] = 0; return b;
}

static std::wstring exeDir() {
    wchar_t p[MAX_PATH]; GetModuleFileNameW(0, p, MAX_PATH);
    wchar_t* s = wcsrchr(p, L'\\'); if (s) *s = 0; return p;
}

// host part of rtsp://user:pass@HOST/... — the cooldown-ledger key
static std::string hostOf(const std::string& url) {
    size_t a = url.rfind('@');
    size_t b = (a == std::string::npos) ? url.find("://") : a;
    size_t s = (a == std::string::npos)
             ? (b == std::string::npos ? 0 : b + 3) : a + 1;
    size_t e = url.find_first_of("/:?", s);
    return url.substr(s, e == std::string::npos ? std::string::npos : e - s);
}
// swap /stream1 <-> /stream2 per quality; no-op when the address has neither
static std::string resolvedUrl(const std::string& url, bool sd) {
    std::string u = url; size_t p = u.find("stream");
    if (p != std::string::npos && p + 6 < u.size()) {
        char& d = u[p + 6];
        if (d == '1' || d == '2') d = sd ? '2' : '1';
    }
    return u;
}

// --------------------------------------------------------------- log (dedup) --
static FILE*            g_log = nullptr;
static CRITICAL_SECTION g_logCs;
static char             g_logLast[512] = {0};
static unsigned         g_logRep = 0;
static double           g_logRepT0 = 0;

static void logLineRaw(const char* line) {
    if (!g_log) return;
    fprintf(g_log, "[%8.3f] %s\n", appSec(), line);
    fflush(g_log);
}
static void logf(const char* fmt, ...) {
    char b[512]; va_list a; va_start(a, fmt); vsnprintf(b, 511, fmt, a); va_end(a);
    b[511] = 0;
    EnterCriticalSection(&g_logCs);
    if (!strcmp(b, g_logLast)) {                 // dedupe keeps it readable (§22)
        g_logRep++;
        if (appSec() - g_logRepT0 >= 30.0) {     // summary every 30 s
            char s[560]; snprintf(s, 559, "(\u00d7%u more) %s", g_logRep, b);
            logLineRaw(s); g_logRep = 0; g_logRepT0 = appSec();
        }
    } else {
        if (g_logRep) { char s[560]; snprintf(s, 559, "(\u00d7%u more) %s", g_logRep, g_logLast); logLineRaw(s); g_logRep = 0; }
        logLineRaw(b);
        strcpy(g_logLast, b); g_logRepT0 = appSec();
    }
    LeaveCriticalSection(&g_logCs);
}
// ffmpeg spam (Tapo's malformed SEI) funnels through the same dedupe
static void ffLogCb(void*, int level, const char* fmt, va_list vl) {
    if (level > AV_LOG_WARNING) return;
    char b[400]; vsnprintf(b, 399, fmt, vl); b[399] = 0;
    size_t n = strlen(b); while (n && (b[n-1] == '\n' || b[n-1] == '\r')) b[--n] = 0;
    if (n) logf("ff: %s", b);
}
static void openLog() {
    std::wstring p = exeDir() + L"\\camerawall.log";   // fresh file each run
    g_log = _wfopen(p.c_str(), L"w");
}

// ============================================================================
// SECTION 2 · data model + settings.json
// ============================================================================

struct VFrame {                       // one decoded picture, CPU side
    int w = 0, h = 0; bool p010 = false;
    std::vector<uint8_t> y, uv;       // Y plane + interleaved UV plane
    int strideY = 0, strideUV = 0;
    bool valid = false;
};

enum CamState { ST_OFF = 0, ST_CONNECT, ST_LIVE, ST_RETRY, ST_RESET, ST_CLOSED };
enum FitMode  { FIT_COVER = 0, FIT_CONTAIN, FIT_STRETCH };

struct Cam {
    int  idx  = 0;                    // storage slot = identity (Build 2 fix)
    int  stag = 0;                    // launch stagger slot; runtime adds use 0
    std::atomic<bool> dead{false};    // removed cameras park here forever

    // ---- editable settings, guarded by g_dataLock (worker snapshots) ----
    std::wstring name; std::string url; bool sd = false; bool on = false;
    bool rot = true;                  // Build 10: in the rotation pool (false = locked/pinned)

    // ---- worker control ----
    std::atomic<bool> quit{false}, reconn{false};
    std::atomic<bool> pre{false};     // Build 10: preroll — connect hidden before a rotation swap
    std::atomic<int>  state{ST_OFF};
    std::atomic<int>  coolLeft{0};    // seconds shown on the RESETTING pane
    std::atomic<int>  attempt{0};
    SRWLOCK errLock = SRWLOCK_INIT; std::wstring errText;

    // ---- live stats for diagnostics ----
    std::atomic<int>   vw{0}, vh{0};
    std::atomic<float> fps{0}, decMs{0}, kbps{0};
    std::atomic<uint64_t> lastFrame{0};   // live-delay: last frame arrival
    int uiMsShown = 0; uint64_t uiMsTick = 0;  // held readout (MS UPDATE)
    std::atomic<int>      frameGap{0};    // ms between the last two frames
    char codecName[16]  = {0};        // written before LIVE, read after
    char decodeMode[16] = {0};        // d3d11va(copy) / software
    char audioDesc[16]  = {0};        // pcm_alaw / none

    // ---- video triple buffer (worker <-> render) ----
    SRWLOCK fLock = SRWLOCK_INIT;
    VFrame fr[3]; int fWrite = 0, fPending = -1, fFront = 2; bool fNew = false;

    // ---- audio ring, s16 mono 8 kHz (worker writes, mixer reads) ----
    SRWLOCK aLock = SRWLOCK_INIT;
    std::vector<int16_t> ring; uint64_t aWr = 0; double aRd = 0;
    uint64_t lastResyncLog = 0;
    std::atomic<float> vol{0.0f};     // 0 = muted; panes start muted (§20)
    float volPre = 0.6f;              // pre-mute level for the mute toggle

    // ---- GPU side, render thread only ----
    ID3D11Texture2D *texY = nullptr, *texUV = nullptr;
    ID3D11ShaderResourceView *srvY = nullptr, *srvUV = nullptr;
    int texW = 0, texH = 0; bool texP010 = false;

    HANDLE th = 0;
    Cam() { ring.resize(RING_N); }
};

// ------------------------------------------------------------ global state --
static SRWLOCK             g_dataLock = SRWLOCK_INIT; // cams meta + order + hist
static std::vector<Cam*>   g_cams;                    // stable pointers, never erased
static std::vector<int>    g_order;                   // wall order (cam idx list)
static std::vector<std::string> g_hist;               // remembered RTSP addresses
static std::atomic<int>    g_fit{FIT_COVER};
static std::atomic<int>    g_soft{0};                 // 0..30 -> 0.0..3.0 px
static std::atomic<int>    g_msUpd{10};               // ms-readout refresh, 0..30 -> 0.0..3.0 s
static std::atomic<int>    g_rotOn{0};                // Build 10: camera rotation master switch
static std::atomic<int>    g_rotSec{10};              // Build 10: rotate every 3..60 s
static struct { UINT show = 1; LONG x = 100, y = 100, w = 1280, h = 720; bool have = false; } g_win;

static HWND  g_hwnd = 0;
static int   g_cw = 1280, g_ch = 720;
static float g_uiS = 1.0f;                            // dpi scale (logged)
static std::atomic<bool> g_quitAll{false};

static int   g_fsPane = -1;                           // windowed pane-fullscreen (⛶)
static bool  g_monFS  = false;                        // Build 4 monitor fullscreen
static WINDOWPLACEMENT g_preFS = { sizeof(WINDOWPLACEMENT) };
static LONG_PTR g_preStyle = 0, g_preEx = 0;

// audio ground truth for the sheet footer
static wchar_t g_audioLine[96] = L"starting";
static wchar_t g_gpuLine[96]   = L"";

// ---------------------------------------------------------- cooldown ledger --
static SRWLOCK g_coolLock = SRWLOCK_INIT;
static std::map<std::string, uint64_t> g_cool;        // host -> tick until free
static void coolSet(const std::string& host, int ms) {
    AcquireSRWLockExclusive(&g_coolLock);
    uint64_t until = nowMs() + ms;
    uint64_t& e = g_cool[host]; if (until > e) e = until;
    ReleaseSRWLockExclusive(&g_coolLock);
}
static int coolLeftMs(const std::string& host) {
    AcquireSRWLockShared(&g_coolLock);
    auto it = g_cool.find(host);
    int left = 0; uint64_t t = nowMs();
    if (it != g_cool.end() && it->second > t) left = (int)(it->second - t);
    ReleaseSRWLockShared(&g_coolLock);
    return left;
}

// -------------------------------------------------------------- wall order --
// self-heal: drop out-of-range/dead/duplicate entries, append orphans (§23.4)
static void sanitizeOrder() {         // caller holds g_dataLock exclusive
    size_t before = g_order.size();
    std::vector<int> out; std::vector<bool> seen(g_cams.size(), false);
    for (int id : g_order)
        if (id >= 0 && id < (int)g_cams.size() && !g_cams[id]->dead && !seen[id]) {
            seen[id] = true; out.push_back(id);
        }
    for (size_t i = 0; i < g_cams.size(); i++)
        if (!seen[i] && !g_cams[i]->dead) out.push_back((int)i);
    if (out.size() != before)
        logf("order: self-healed (%zu -> %zu entries)", before, out.size());
    g_order.swap(out);
}
// first MAX_PANES cameras that are on — the visible wall (caller holds shared)
static std::vector<int> computeVis() {
    std::vector<int> v;
    for (int id : g_order)
        if (g_cams[id]->on && !g_cams[id]->dead && (int)v.size() < MAX_PANES)
            v.push_back(id);
    return v;
}
static int onCount() {                // caller holds g_dataLock (any)
    int n = 0; for (auto c : g_cams) if (c->on && !c->dead) n++;
    return n;
}

// ------------------------------------------------------------------- seeds --
struct Seed { const wchar_t* name; const char* url; bool on; };
static const Seed kSeeds[7] = {       // §7 — recovered verbatim from the exe
    { L"Gate",     "rtsp://itsnedd:ad45yk0m@192.168.0.153/stream1",  true  },
    { L"Balcony",  "rtsp://itsnedd:ad45yk0m@192.168.0.150/stream1",  true  },
    { L"Back",     "rtsp://itsnedd:ad45yk0m@192.168.0.151/stream1",  true  },
    { L"K_Back",   "rtsp://itsnedd:ad45yk0m@192.168.0.154/stream1",  false },
    { L"K_Side",   "rtsp://itsnedd:ad45yk0m@192.168.0.155/stream1",  false },
    { L"Driveway", "rtsp://itsnedd2:ad45yk0m@192.168.0.152/stream1", false },
    { L"Indoor",   "rtsp://itsnedd:ad45yk0m@192.168.0.140/stream1",  false },
};
static Cam* addCamRaw(const std::wstring& name, const std::string& url, bool sd, bool on) {
    Cam* c = new Cam();
    c->idx = (int)g_cams.size(); c->name = name; c->url = url; c->sd = sd; c->on = on;
    g_cams.push_back(c); g_order.push_back(c->idx);
    return c;
}
static void seedWall() {              // cameras.txt first, else the built-in 7
    std::wstring p = exeDir() + L"\\cameras.txt";
    FILE* f = _wfopen(p.c_str(), L"rb");
    if (f) {
        char line[600]; size_t n = 0;
        while (fgets(line, 599, f) && (int)g_cams.size() < MAX_CAMS) {
            std::string s(line);
            while (!s.empty() && (s.back()=='\n'||s.back()=='\r'||s.back()==' ')) s.pop_back();
            size_t bar = s.find('|');
            if (bar == std::string::npos || s.empty() || s[0] == '#') continue;
            std::string nm = s.substr(0, bar), url = s.substr(bar + 1);
            if (url.rfind("rtsp://", 0) != 0) continue;
            addCamRaw(toWide(nm), url, false, n < MAX_PANES); n++;
        }
        fclose(f);
        if (n) { logf("loaded %zu cameras from cameras.txt", n); return; }
    }
    for (auto& s : kSeeds) addCamRaw(s.name, s.url, false, s.on);
    logf("using built-in wall: 7 cameras");
}

// ---------------------------------------------------------- settings.json --
// tolerant scanners for the v2 (and legacy v1) file
static bool jFindKey(const std::string& s, size_t from, const char* key, size_t& pos) {
    std::string k = std::string("\"") + key + "\"";
    size_t p = s.find(k, from); if (p == std::string::npos) return false;
    pos = p + k.size(); return true;
}
static bool jStr(const std::string& s, size_t from, const char* key, std::string& out, size_t lim = std::string::npos) {
    size_t p; if (!jFindKey(s, from, key, p) || p > lim) return false;
    size_t a = s.find('"', p); if (a == std::string::npos || a > lim) return false;
    size_t b = s.find('"', a + 1); if (b == std::string::npos) return false;
    out = s.substr(a + 1, b - a - 1); return true;
}
static bool jInt(const std::string& s, size_t from, const char* key, long& out, size_t lim = std::string::npos) {
    size_t p; if (!jFindKey(s, from, key, p) || p > lim) return false;
    while (p < s.size() && (s[p] == ':' || s[p] == ' ' || s[p] == '\t')) p++;
    if (p >= s.size() || (!isdigit((unsigned char)s[p]) && s[p] != '-')) return false;
    out = strtol(s.c_str() + p, nullptr, 10); return true;
}

static bool loadSettings() {          // returns true when cams came from disk
    std::wstring p = exeDir() + L"\\settings.json";
    FILE* f = _wfopen(p.c_str(), L"rb");
    if (!f) return false;
    std::string s; char buf[4096]; size_t r;
    while ((r = fread(buf, 1, 4096, f)) > 0) s.append(buf, r);
    fclose(f);
    if (s.empty()) return false;

    long v; size_t wp;
    if (jFindKey(s, 0, "window", wp)) {
        size_t lim = s.find('}', wp);
        if (jInt(s, wp, "show", v, lim)) g_win.show = (UINT)v;
        if (jInt(s, wp, "x", v, lim)) g_win.x = v;
        if (jInt(s, wp, "y", v, lim)) g_win.y = v;
        if (jInt(s, wp, "w", v, lim)) g_win.w = v;
        if (jInt(s, wp, "h", v, lim)) g_win.h = v;
        g_win.have = true;
    }
    std::string fit;
    if (jStr(s, 0, "fit", fit)) {
        g_fit = fit == "contain" ? FIT_CONTAIN : fit == "stretch" ? FIT_STRETCH : FIT_COVER;
    }
    if (jInt(s, 0, "soft", v)) g_soft = (int)std::max(0L, std::min(30L, v));
    if (jInt(s, 0, "msup", v)) g_msUpd = (int)std::max(0L, std::min(30L, v));
    if (jInt(s, 0, "rotate", v)) g_rotOn = v ? 1 : 0;                  // Build 10
    if (jInt(s, 0, "rotsec", v)) g_rotSec = (int)std::max(3L, std::min(60L, v));

    size_t hp;
    if (jFindKey(s, 0, "hist", hp)) {
        size_t a = s.find('[', hp), e = s.find(']', hp);
        while (a != std::string::npos && e != std::string::npos) {
            size_t q1 = s.find('"', a + 1); if (q1 == std::string::npos || q1 > e) break;
            size_t q2 = s.find('"', q1 + 1); if (q2 == std::string::npos || q2 > e) break;
            if ((int)g_hist.size() < HIST_MAX) g_hist.push_back(s.substr(q1 + 1, q2 - q1 - 1));
            a = q2;
        }
    }

    bool gotCams = false;
    size_t cp;
    if (jFindKey(s, 0, "cams", cp)) {
        size_t a = s.find('[', cp);
        size_t end = a == std::string::npos ? std::string::npos : s.find(']', a);
        size_t o = a;
        while (o != std::string::npos && (o = s.find('{', o)) != std::string::npos && o < end) {
            size_t c = s.find('}', o); if (c == std::string::npos) break;
            std::string nm, url, res; long on = 1, rt = 1;
            jStr(s, o, "name", nm, c); jStr(s, o, "url", url, c);
            jStr(s, o, "res", res, c); jInt(s, o, "on", on, c);
            jInt(s, o, "rot", rt, c);                        // Build 10, default: in pool
            if (!url.empty() && (int)g_cams.size() < MAX_CAMS) {
                bool dup = false;
                for (auto cc : g_cams)
                    if (cc->url == url && toUtf8(cc->name) == nm) { dup = true; break; }
                if (dup) {
                    logf("settings: duplicate camera entry skipped (%s)", nm.c_str());
                } else {
                    Cam* nc = addCamRaw(toWide(nm), url, res == "sd", on != 0);
                    nc->rot = rt != 0;
                    gotCams = true;
                }
            }
            o = c + 1;
        }
    }
    if (gotCams) {
        logf("settings: %zu camera(s) loaded from settings.json", g_cams.size());
    } else {
        // v1 file: window/closed only — seed, then migrate the closed list
        seedWall();
        size_t xp;
        if (jFindKey(s, 0, "closed", xp)) {
            size_t a = s.find('[', xp), e = s.find(']', xp);
            int migrated = 0;
            if (a != std::string::npos && e != std::string::npos) {
                size_t q = a;
                while ((q = s.find('"', q + 1)) != std::string::npos && q < e) {
                    size_t q2 = s.find('"', q + 1); if (q2 == std::string::npos || q2 > e) break;
                    std::string nm = s.substr(q + 1, q2 - q - 1);
                    for (auto c : g_cams)
                        if (toUtf8(c->name) == nm && c->on) { c->on = false; migrated++; }
                    q = q2;
                }
            }
            if (migrated) logf("settings: %d pane(s) migrated closed from v1", migrated);
        }
    }
    logf("settings.json loaded (fit=%s soft=%d)",
         g_fit == FIT_CONTAIN ? "contain" : g_fit == FIT_STRETCH ? "stretch" : "cover",
         g_soft.load());
    logf("rotation: %s \u00b7 every %d s", g_rotOn ? "on" : "off", g_rotSec.load());
    return true;
}

static void saveSettings() {          // byte-faithful to the recovered writer
    if (g_monFS) {                    // Build 4 law: never store fullscreen bounds
        // window fields were frozen at enterMonFS(); fall through and write them
    }
    std::wstring p = exeDir() + L"\\settings.json";
    FILE* f = _wfopen(p.c_str(), L"w");
    if (!f) { logf("settings: cannot write settings.json"); return; }
    fprintf(f, "{\n");
    fprintf(f, "  \"window\": { \"show\": %u, \"x\": %ld, \"y\": %ld, \"w\": %ld, \"h\": %ld },\n",
            g_win.show, g_win.x, g_win.y, g_win.w, g_win.h);
    fprintf(f, "  \"fit\": \"%s\",\n",
            g_fit == FIT_CONTAIN ? "contain" : g_fit == FIT_STRETCH ? "stretch" : "cover");
    fprintf(f, "  \"soft\": %d,\n", g_soft.load());
    fprintf(f, "  \"msup\": %d,\n", g_msUpd.load());
    fprintf(f, "  \"rotate\": %d,\n", g_rotOn.load());
    fprintf(f, "  \"rotsec\": %d,\n", g_rotSec.load());
    fprintf(f, "  \"hist\": [");
    AcquireSRWLockShared(&g_dataLock);
    for (size_t i = 0; i < g_hist.size(); i++)
        fprintf(f, "%s\"%s\"", i ? ", " : " ", g_hist[i].c_str());
    fprintf(f, "%s],\n", g_hist.empty() ? " " : " ");
    fprintf(f, "  \"cams\": [\n");
    bool first = true;
    for (int id : g_order) {
        Cam* c = g_cams[id]; if (c->dead) continue;
        fprintf(f, "%s    { \"name\": \"%s\", \"url\": \"%s\", \"res\": \"%s\", \"on\": %d, \"rot\": %d }",
                first ? "" : ",\n", toUtf8(c->name).c_str(), c->url.c_str(),
                c->sd ? "sd" : "hd", c->on ? 1 : 0, c->rot ? 1 : 0);
        first = false;
    }
    ReleaseSRWLockShared(&g_dataLock);
    fprintf(f, "\n  ]\n}\n");
    fclose(f);
}
static void histPush(const std::string& url) {  // caller holds exclusive
    for (auto it = g_hist.begin(); it != g_hist.end(); ++it)
        if (*it == url) { g_hist.erase(it); break; }
    g_hist.insert(g_hist.begin(), url);
    while ((int)g_hist.size() > HIST_MAX) g_hist.pop_back();
}

// ============================================================================
// SECTION 3 · decode workers — RTSP/TCP -> libavformat -> libavcodec
//             (D3D11VA hw decode, copy-back) -> NV12/P010 triple buffer (§17)
// ============================================================================

struct IoCtl { Cam* c; std::atomic<uint64_t> deadline{0}; };
static int ioIntr(void* o) {
    IoCtl* ic = (IoCtl*)o; Cam* c = ic->c;
    if (g_quitAll || c->quit || c->dead || c->reconn || (!c->on && !c->pre)) return 1;
    if (nowMs() > ic->deadline) return 1;         // 8 s read deadline (§23.6)
    return 0;
}
static enum AVPixelFormat pickFmt(AVCodecContext* ctx, const enum AVPixelFormat* fmts) {
    for (const enum AVPixelFormat* p = fmts; *p != AV_PIX_FMT_NONE; p++)
        if (*p == AV_PIX_FMT_D3D11) return AV_PIX_FMT_D3D11;
    logf("cam: decoder did not offer d3d11 \u00b7 software path");
    return fmts[0];
}
static const char* stName(int st) {
    switch (st) { case ST_LIVE: return "LIVE"; case ST_CONNECT: return "CONNECTING";
        case ST_RETRY: return "RETRYING"; case ST_RESET: return "RESETTING";
        case ST_CLOSED: return "CLOSED"; } return "OFF";
}
static void setErr(Cam* c, const wchar_t* w) {
    AcquireSRWLockExclusive(&c->errLock); c->errText = w; ReleaseSRWLockExclusive(&c->errLock);
}
static void packFrame(Cam* c, AVFrame* f) {
    int w = f->width, h = f->height; if (w <= 0 || h <= 0) return;
    bool p10 = (f->format == AV_PIX_FMT_P010LE);
    int bpp = p10 ? 2 : 1;
    VFrame& vf = c->fr[c->fWrite];
    vf.w = w; vf.h = h; vf.p010 = p10;
    vf.strideY = w * bpp; vf.strideUV = w * bpp;      // UV interleaved, half height
    vf.y.resize((size_t)vf.strideY * h);
    vf.uv.resize((size_t)vf.strideUV * ((h + 1) / 2));
    int h2 = (h + 1) / 2;
    if (f->format == AV_PIX_FMT_NV12 || f->format == AV_PIX_FMT_P010LE) {
        for (int r = 0; r < h;  r++) memcpy(&vf.y[(size_t)r * vf.strideY],  f->data[0] + (size_t)r * f->linesize[0], vf.strideY);
        for (int r = 0; r < h2; r++) memcpy(&vf.uv[(size_t)r * vf.strideUV], f->data[1] + (size_t)r * f->linesize[1], vf.strideUV);
    } else if (f->format == AV_PIX_FMT_YUV420P || f->format == AV_PIX_FMT_YUVJ420P) {
        for (int r = 0; r < h; r++) memcpy(&vf.y[(size_t)r * vf.strideY], f->data[0] + (size_t)r * f->linesize[0], w);
        for (int r = 0; r < h2; r++) {
            uint8_t* d = &vf.uv[(size_t)r * vf.strideUV];
            const uint8_t* u = f->data[1] + (size_t)r * f->linesize[1];
            const uint8_t* v = f->data[2] + (size_t)r * f->linesize[2];
            for (int x = 0; x < w / 2; x++) { d[2*x] = u[x]; d[2*x+1] = v[x]; }
        }
    } else {
        logf("[%s] unsupported pixel format %d", toUtf8(c->name).c_str(), f->format);
        return;
    }
    vf.valid = true;
    AcquireSRWLockExclusive(&c->fLock);
    c->fPending = c->fWrite; c->fNew = true;
    for (int s = 0; s < 3; s++) if (s != c->fPending && s != c->fFront) { c->fWrite = s; break; }
    ReleaseSRWLockExclusive(&c->fLock);
    c->vw = w; c->vh = h;
}
static void ringWrite(Cam* c, const int16_t* s, int n, const char* nmA) {
    AcquireSRWLockExclusive(&c->aLock);
    if (c->aWr - (uint64_t)c->aRd > (uint64_t)(RING_N - 1600)) {
        c->aRd = (double)(c->aWr > 1600 ? c->aWr - 1600 : 0);
        if (nowMs() - c->lastResyncLog > 2000) {
            c->lastResyncLog = nowMs();
            logf("[%s] audio resync (ring deep)", nmA);
        }
    }
    for (int i = 0; i < n; i++) c->ring[(c->aWr + i) % RING_N] = s[i];
    c->aWr += n;
    ReleaseSRWLockExclusive(&c->aLock);
}

static DWORD WINAPI camWorker(LPVOID pv) {
    Cam* c = (Cam*)pv;
    bool firstRun = true, wasOn = false;
    char nmA[80]; std::string urlSnap; bool sdSnap = false;

    for (;;) {
        if (g_quitAll || c->quit || c->dead) break;

        AcquireSRWLockShared(&g_dataLock);
        snprintf(nmA, 79, "%s", toUtf8(c->name).c_str());
        urlSnap = c->url; sdSnap = c->sd; bool on = c->on || c->pre;   // preroll connects hidden (B10)
        ReleaseSRWLockShared(&g_dataLock);
        std::string url = resolvedUrl(urlSnap, sdSnap);
        std::string host = hostOf(url);

        if (!on) { c->state = ST_CLOSED; wasOn = false; Sleep(120); continue; }
        if (!wasOn && !firstRun)
            logf("[%s] %s", nmA, c->on ? "restored \u00b7 reconnecting"
                                       : "rotation preroll \u00b7 connecting hidden");
        wasOn = true;

        if (firstRun) {
            firstRun = false;
            logf("[%s] worker started \u00b7 %s", nmA, url.c_str());
            c->state = ST_CONNECT;
            for (int t = 0; t < c->stag * STAGGER_MS; t += 50) {
                if (g_quitAll || c->quit || c->dead || (!c->on && !c->pre)) break; Sleep(50);
            }
            continue;
        }
        int cl = coolLeftMs(host);
        if (cl > 0) {                                  // honest countdown (§23)
            c->state = ST_RESET; c->coolLeft = (cl + 999) / 1000;
            Sleep(150); continue;
        }

        c->state = ST_CONNECT; c->attempt++;
        IoCtl ic; ic.c = c; ic.deadline = nowMs() + READ_DEADLINE;
        AVFormatContext* fc = avformat_alloc_context();
        fc->interrupt_callback.callback = ioIntr;
        fc->interrupt_callback.opaque = &ic;
        AVDictionary* opts = nullptr;
        av_dict_set(&opts, "rtsp_transport", "tcp", 0);
        av_dict_set(&opts, "fflags", "nobuffer", 0);
        av_dict_set(&opts, "timeout", "8000000", 0);
        av_dict_set(&opts, "max_delay", "500000", 0);
        av_dict_set(&opts, "reorder_queue_size", "0", 0);
        int r = avformat_open_input(&fc, url.c_str(), nullptr, &opts);
        AVDictionaryEntry* de = nullptr;
        while ((de = av_dict_get(opts, "", de, AV_DICT_IGNORE_SUFFIX)))
            logf("[%s] option not consumed: %s", nmA, de->key);
        av_dict_free(&opts);
        char eb[128];
        if (r < 0) {
            av_strerror(r, eb, 127);
            logf("[%s] open failed: %s", nmA, eb); setErr(c, toWide(eb).c_str());
            if (fc) avformat_free_context(fc);
            c->state = ST_RETRY; Sleep(700); continue;
        }
        ic.deadline = nowMs() + READ_DEADLINE;
        r = avformat_find_stream_info(fc, nullptr);
        if (r < 0) {
            av_strerror(r, eb, 127);
            logf("[%s] stream info failed: %s", nmA, eb); setErr(c, toWide(eb).c_str());
            avformat_close_input(&fc); c->state = ST_RETRY; Sleep(700); continue;
        }
        int vIdx = -1, aIdx = -1;
        for (unsigned i = 0; i < fc->nb_streams; i++) {
            AVCodecParameters* par = fc->streams[i]->codecpar;
            logf("[%s] stream %u: type=%d codec=%s", nmA, i, par->codec_type,
                 avcodec_get_name(par->codec_id));
            if (par->codec_type == AVMEDIA_TYPE_VIDEO && vIdx < 0) vIdx = i;
            if (par->codec_type == AVMEDIA_TYPE_AUDIO && aIdx < 0) aIdx = i;
        }
        if (vIdx < 0) {
            logf("[%s] no decodable video stream", nmA);
            setErr(c, L"no decodable video stream");
            avformat_close_input(&fc); c->state = ST_RETRY; Sleep(700); continue;
        }
        AVCodecParameters* vp = fc->streams[vIdx]->codecpar;
        const AVCodec* vdec = avcodec_find_decoder(vp->codec_id);
        AVBufferRef* hwdev = nullptr;
        int hr = av_hwdevice_ctx_create(&hwdev, AV_HWDEVICE_TYPE_D3D11VA, nullptr, nullptr, 0);
        if (hr < 0) {
            av_strerror(hr, eb, 127);
            logf("[%s] d3d11va create failed (%s) \u00b7 software decode", nmA, eb);
            hwdev = nullptr;
        }
        AVCodecContext* vctx = avcodec_alloc_context3(vdec);
        avcodec_parameters_to_context(vctx, vp);
        if (hwdev) { vctx->hw_device_ctx = av_buffer_ref(hwdev); vctx->get_format = pickFmt; }
        else vctx->thread_count = 4;
        r = avcodec_open2(vctx, vdec, nullptr);
        if (r < 0) {
            av_strerror(r, eb, 127);
            logf("[%s] video decoder open failed: %s", nmA, eb); setErr(c, toWide(eb).c_str());
            avcodec_free_context(&vctx); if (hwdev) av_buffer_unref(&hwdev);
            avformat_close_input(&fc); c->state = ST_RETRY; Sleep(700); continue;
        }
        snprintf(c->codecName, 15, "%s", avcodec_get_name(vp->codec_id));
        logf("[%s] video decoder %s open \u00b7 hw_device=%s", nmA, c->codecName,
             hwdev ? "d3d11va" : "none");
        AVCodecContext* actx = nullptr;
        if (aIdx >= 0) {
            AVCodecParameters* ap = fc->streams[aIdx]->codecpar;
            const AVCodec* adec = avcodec_find_decoder(ap->codec_id);
            if (adec) {
                actx = avcodec_alloc_context3(adec);
                avcodec_parameters_to_context(actx, ap);
                if (avcodec_open2(actx, adec, nullptr) < 0) { avcodec_free_context(&actx); actx = nullptr; }
            }
            if (actx) {
                snprintf(c->audioDesc, 15, "%s", avcodec_get_name(ap->codec_id));
                logf("[%s] audio: %s %d Hz", nmA, c->audioDesc, ap->sample_rate);
            } else logf("[%s] audio decoder open failed \u00b7 video only", nmA);
        }
        if (!actx) snprintf(c->audioDesc, 15, "none");
        snprintf(c->decodeMode, 15, "%s", hwdev ? "d3d11va(copy)" : "software");

        AVPacket* pkt = av_packet_alloc();
        AVFrame *vf = av_frame_alloc(), *sw = av_frame_alloc(), *af = av_frame_alloc();
        bool live = false; int err = 0;
        uint64_t statT = nowMs(), bytes = 0; int frames = 0;
        LARGE_INTEGER qf; QueryPerformanceFrequency(&qf);

        for (;;) {
            if (g_quitAll || c->quit || c->dead) { err = 1; break; }
            if (!c->on && !c->pre) { err = 2; break; }
            if (c->reconn) { err = 3; break; }
            ic.deadline = nowMs() + READ_DEADLINE;
            r = av_read_frame(fc, pkt);
            if (r < 0) {
                if (g_quitAll || c->quit || c->dead) { err = 1; break; }
                if (!c->on && !c->pre) { err = 2; break; }
                if (c->reconn) { err = 3; break; }
                av_strerror(r, eb, 127);
                logf("[%s] read: %s", nmA, eb); setErr(c, toWide(eb).c_str());
                err = 4; break;
            }
            if (pkt->stream_index == vIdx) {
                bytes += pkt->size;
                LARGE_INTEGER t0, t1; QueryPerformanceCounter(&t0);
                r = avcodec_send_packet(vctx, pkt);
                if (r < 0 && r != AVERROR(EAGAIN)) {
                    av_strerror(r, eb, 127); logf("[%s] send_packet: %s", nmA, eb);
                }
                while ((r = avcodec_receive_frame(vctx, vf)) == 0) {
                    AVFrame* use = vf;
                    if (vf->format == AV_PIX_FMT_D3D11) {
                        av_frame_unref(sw);
                        int tr = av_hwframe_transfer_data(sw, vf, 0);
                        if (tr < 0) { av_strerror(tr, eb, 127); logf("[%s] hw transfer: %s", nmA, eb); av_frame_unref(vf); continue; }
                        use = sw;
                    }
                    QueryPerformanceCounter(&t1);        // decode + hw copy-back
                    float ms = float(double(t1.QuadPart - t0.QuadPart) * 1000.0 / qf.QuadPart);
                    c->decMs = c->decMs * 0.9f + ms * 0.1f;
                    packFrame(c, use);
                    { uint64_t nt2 = nowMs(), lf = c->lastFrame.load();
                      if (lf) c->frameGap = (int)(nt2 - lf);
                      c->lastFrame = nt2; }
                    frames++;
                    if (!live) {
                        live = true; c->state = ST_LIVE; c->attempt = 0;
                        logf("[%s] LIVE %dx%d %s decode=%s audio=%s", nmA,
                             use->width, use->height, c->codecName, c->decodeMode, c->audioDesc);
                    }
                    av_frame_unref(vf);
                }
                uint64_t nt = nowMs();
                if (nt - statT >= 1000) {
                    c->fps  = frames * 1000.0f / float(nt - statT);
                    c->kbps = bytes  * 8.0f    / float(nt - statT);
                    frames = 0; bytes = 0; statT = nt;
                }
            } else if (actx && pkt->stream_index == aIdx) {
                if (avcodec_send_packet(actx, pkt) == 0)
                    while (avcodec_receive_frame(actx, af) == 0) {
                        if (af->format == AV_SAMPLE_FMT_S16 && af->nb_samples > 0)
                            ringWrite(c, (const int16_t*)af->data[0], af->nb_samples, nmA);
                        av_frame_unref(af);
                    }
            }
            av_packet_unref(pkt);
        }
        bool wasLive = live;
        av_packet_free(&pkt); av_frame_free(&vf); av_frame_free(&sw); av_frame_free(&af);
        if (actx) avcodec_free_context(&actx);
        avcodec_free_context(&vctx);
        if (hwdev) av_buffer_unref(&hwdev);
        avformat_close_input(&fc);
        c->fps = 0; c->kbps = 0; c->lastFrame = 0; c->frameGap = 0;
        if (wasLive) coolSet(host, CLEAN_COOL_MS);     // let the camera free its slot

        if (err == 1) break;                            // quit/dead -> worker exit
        if (err == 2) {                                 // ✕ / checkbox off
            logf("[%s] closed \u00b7 connection dropped, slot released", nmA);
            c->state = ST_CLOSED; continue;
        }
        if (err == 3) {                                 // ↻ hard reset
            c->reconn = false;
            logf("[%s] hard reset (was %s)", nmA, stName(wasLive ? ST_LIVE : ST_CONNECT));
            c->state = wasLive ? ST_RESET : ST_CONNECT; continue;
        }
        c->state = ST_RETRY;                            // retry-forever engine
        Sleep(700);
    }
    logf("[%s] worker exit", nmA);
    return 0;
}

// ============================================================================
// SECTION 4 · WASAPI mixer — shared mode float32, 8 kHz -> mix rate (§17)
//             one persistent stream; per-pane volume; muted panes stay live.
// ============================================================================

static int  g_mixRate = 48000, g_mixCh = 2;

static DWORD WINAPI audioThread(LPVOID) {
    HRESULT hr = CoInitializeEx(nullptr, COINIT_MULTITHREADED);
    const char* stage = "enumerator";
    IMMDeviceEnumerator* de = nullptr; IMMDevice* dev = nullptr;
    IAudioClient* ac = nullptr; IAudioRenderClient* rc = nullptr;
    WAVEFORMATEX* wf = nullptr; bool started = false;
    do {
        hr = CoCreateInstance(kCLSID_MMDeviceEnumerator, nullptr, CLSCTX_ALL,
                              kIID_IMMDeviceEnumerator, (void**)&de);
        if (FAILED(hr)) break;
        stage = "default endpoint";
        hr = de->GetDefaultAudioEndpoint(eRender, eConsole, &dev);
        if (FAILED(hr)) break;
        stage = "activate";
        hr = dev->Activate(kIID_IAudioClient, CLSCTX_ALL, nullptr, (void**)&ac);
        if (FAILED(hr)) break;
        stage = "mix format";
        hr = ac->GetMixFormat(&wf);
        if (FAILED(hr)) break;
        if (wf->wFormatTag == WAVE_FORMAT_EXTENSIBLE) {
            WAVEFORMATEXTENSIBLE* wx = (WAVEFORMATEXTENSIBLE*)wf;
            if (!IsEqualGUID(wx->SubFormat, kKSDATAFORMAT_FLOAT)) { stage = "mix subformat"; hr = E_FAIL; break; }
            if (wf->wBitsPerSample != 32) { stage = "mix bits"; hr = E_FAIL; break; }
        } else if (!(wf->wFormatTag == WAVE_FORMAT_IEEE_FLOAT && wf->wBitsPerSample == 32)) {
            stage = "mix bits"; hr = E_FAIL; break;
        }
        stage = "initialize";
        hr = ac->Initialize(AUDCLNT_SHAREMODE_SHARED, 0, 2000000, 0, wf, nullptr);
        if (FAILED(hr)) break;
        UINT32 bufFrames = 0; ac->GetBufferSize(&bufFrames);
        stage = "render client";
        hr = ac->GetService(kIID_IAudioRenderClient, (void**)&rc);
        if (FAILED(hr)) break;
        ac->Start(); started = true;
        g_mixRate = wf->nSamplesPerSec; g_mixCh = wf->nChannels;
        logf("audio: %s \u00b7 %u Hz \u00b7 %u ch \u00b7 buffer %u frames",
             "float32", (unsigned)wf->nSamplesPerSec, (unsigned)wf->nChannels, (unsigned)bufFrames);
        wcscpy(g_audioLine, L"ok");

        const double step = 8000.0 / g_mixRate;         // linear resample stride
        const UINT32 target = g_mixRate / 20;           // keep ~50 ms queued
        while (!g_quitAll) {
            UINT32 pad = 0;
            if (FAILED(ac->GetCurrentPadding(&pad))) { logf("audio: padding lost"); break; }
            if (pad >= target) { Sleep(5); continue; }
            UINT32 n = target - pad;
            if (n > bufFrames - pad) n = bufFrames - pad;
            if (!n) { Sleep(5); continue; }
            BYTE* pb = nullptr;
            if (FAILED(rc->GetBuffer(n, &pb))) { logf("audio: buffer lost"); break; }
            float* out = (float*)pb;
            memset(out, 0, (size_t)n * g_mixCh * sizeof(float));

            AcquireSRWLockShared(&g_dataLock);
            std::vector<Cam*> cams = g_cams;            // stable pointers
            ReleaseSRWLockShared(&g_dataLock);
            for (Cam* c : cams) {
                float vol = c->vol;
                AcquireSRWLockExclusive(&c->aLock);
                if (c->aWr > 4800 && c->aWr - (uint64_t)c->aRd > 4800)
                    c->aRd = double(c->aWr - 1200);     // stay live, drop backlog
                if (vol > 0.001f && c->on) {      // B10: preroll stays silent
                    for (UINT32 i = 0; i < n; i++) {
                        double pos = c->aRd + step * i;
                        uint64_t i0 = (uint64_t)pos;
                        if (i0 + 1 >= c->aWr) break;
                        float fr = float(pos - i0);
                        float s0 = c->ring[i0 % RING_N] / 32768.0f;
                        float s1 = c->ring[(i0 + 1) % RING_N] / 32768.0f;
                        float sm = (s0 + (s1 - s0) * fr) * vol;
                        out[i * g_mixCh] += sm;
                        if (g_mixCh > 1) out[i * g_mixCh + 1] += sm;
                    }
                }
                c->aRd += step * n;                     // muted panes still advance
                if (c->aRd > double(c->aWr)) c->aRd = double(c->aWr);
                ReleaseSRWLockExclusive(&c->aLock);
            }
            for (UINT32 i = 0; i < n * (UINT32)g_mixCh; i++) {
                float v = out[i]; out[i] = v < -1.f ? -1.f : (v > 1.f ? 1.f : v);
            }
            rc->ReleaseBuffer(n, 0);
        }
        ac->Stop();
    } while (0);
    if (FAILED(hr)) {
        logf("audio unavailable at '%s' (0x%08lX) \u00b7 wall runs silent", stage, (unsigned long)hr);
        wcscpy(g_audioLine, L"unavailable");
    } else if (!started) wcscpy(g_audioLine, L"unavailable");
    if (wf) CoTaskMemFree(wf);
    if (rc) rc->Release(); if (ac) ac->Release();
    if (dev) dev->Release(); if (de) de->Release();
    CoUninitialize();
    return 0;
}

// ============================================================================
// SECTION 5 · D3D11 renderer + GDI text baker
//   Flip-model swapchain, one quad per draw (SV_VertexID), constants per draw.
//   The HLSL below is the Build 3 shader suite, recovered verbatim from the
//   exe — including the 5.3 scrim comment. Do not reformat.
// ============================================================================

static const char* kShaderSrc = R"HLSL(
cbuffer VSCB : register(b0) { float4 dst; float4 uvr; };
struct VOut { float4 pos : SV_Position; float2 uv : TEXCOORD0; };
VOut vsMain(uint id : SV_VertexID) {
    float2 c = float2(id & 1, id >> 1);
    VOut o;
    float2 p = dst.xy + c * dst.zw;
    o.pos = float4(p.x, p.y, 0, 1);
    o.uv  = uvr.xy + c * uvr.zw;
    return o;
}
Texture2D tY  : register(t0);
Texture2D tUV : register(t1);
SamplerState smp : register(s0);
cbuffer PSCB : register(b1) { float4 misc; float4 misc2; };
float4 psVideo(VOut i) : SV_Target {
    float2 o = float2(misc.y, misc.z);
    float  y; float2 uv;
    if (o.x <= 0.000001) {
        y  = tY.Sample(smp, i.uv).r;
        uv = tUV.Sample(smp, i.uv).rg;
    } else {
        y  = tY.Sample(smp, i.uv).r * 4.0
           + (tY.Sample(smp, i.uv + float2( o.x, 0)).r
           +  tY.Sample(smp, i.uv + float2(-o.x, 0)).r
           +  tY.Sample(smp, i.uv + float2(0,  o.y)).r
           +  tY.Sample(smp, i.uv + float2(0, -o.y)).r) * 2.0
           +  tY.Sample(smp, i.uv + float2( o.x,  o.y)).r
           +  tY.Sample(smp, i.uv + float2(-o.x,  o.y)).r
           +  tY.Sample(smp, i.uv + float2( o.x, -o.y)).r
           +  tY.Sample(smp, i.uv + float2(-o.x, -o.y)).r;
        y /= 16.0;
        uv  = tUV.Sample(smp, i.uv).rg * 4.0
            + (tUV.Sample(smp, i.uv + float2( o.x, 0)).rg
            +  tUV.Sample(smp, i.uv + float2(-o.x, 0)).rg
            +  tUV.Sample(smp, i.uv + float2(0,  o.y)).rg
            +  tUV.Sample(smp, i.uv + float2(0, -o.y)).rg) * 2.0
            +  tUV.Sample(smp, i.uv + float2( o.x,  o.y)).rg
            +  tUV.Sample(smp, i.uv + float2(-o.x,  o.y)).rg
            +  tUV.Sample(smp, i.uv + float2( o.x, -o.y)).rg
            +  tUV.Sample(smp, i.uv + float2(-o.x, -o.y)).rg;
        uv /= 16.0;
    }
    y  = y  * misc.x;
    uv = uv * misc.x;
    y = (y - 0.0627) * 1.1644;
    float u = uv.x - 0.5, v = uv.y - 0.5;
    float3 rgb = float3(y + 1.7927 * v,
                        y - 0.2132 * u - 0.5329 * v,
                        y + 2.1124 * u);
    return float4(saturate(rgb), 1);
}
Texture2D tOv : register(t0);
float4 psOverlay(VOut i) : SV_Target {
    float4 c = tOv.Sample(smp, i.uv);
    c.a *= misc2.y;
    return c;
}
float4 psSolid(VOut i) : SV_Target { return misc; }
float4 psGrad(VOut i) : SV_Target {          // 5.3 scrim: .96 -> .78 @55% -> 0
    float f = 1.0 - i.uv.y;                  // 0 at bottom
    float a = (f <= 0.55) ? lerp(0.96, 0.78, f / 0.55)
                          : lerp(0.78, 0.0, (f - 0.55) / 0.45);
    return float4(0, 0, 0, a * misc.w);
}
float4 psCircle(VOut i) : SV_Target {
    float d = length(i.uv * 2.0 - 1.0);
    float a = saturate((1.0 - d) * misc2.x) * misc.w;
    return float4(misc.xyz, a);
}
float4 psGlow(VOut i) : SV_Target {
    float d = saturate(1.0 - length(i.uv * 2.0 - 1.0));
    return float4(misc.xyz, d * d * misc.w);
}
)HLSL";

static ID3D11Device*           g_dev  = nullptr;
static ID3D11DeviceContext*    g_ctx  = nullptr;
static IDXGISwapChain1*        g_swap = nullptr;
static ID3D11RenderTargetView* g_rtv  = nullptr;
static ID3D11VertexShader*     g_vs   = nullptr;
enum { SH_VIDEO = 0, SH_OVERLAY, SH_SOLID, SH_GRAD, SH_CIRCLE, SH_GLOW, SH_COUNT };
static ID3D11PixelShader*      g_ps[SH_COUNT] = {};
static ID3D11Buffer            *g_cbVS = nullptr, *g_cbPS = nullptr;
static ID3D11BlendState*       g_blend = nullptr;
static ID3D11SamplerState*     g_samp  = nullptr;
static ID3D11RasterizerState*  g_rast  = nullptr;
static float                   g_uiA   = 1.0f;    // Build 3 global draw alpha

static void fatalD3D() {
    MessageBoxW(0, L"Direct3D 11 could not start.\nSee camerawall.log next to the exe.",
                L"Camera Wall", MB_ICONERROR);
    ExitProcess(1);
}
static bool makeRTV() {
    ID3D11Texture2D* bb = nullptr;
    HRESULT hr = g_swap->GetBuffer(0, kIID_ID3D11Texture2D, (void**)&bb);
    if (FAILED(hr)) { logf("GetBuffer 0x%08lX", (unsigned long)hr); return false; }
    hr = g_dev->CreateRenderTargetView(bb, nullptr, &g_rtv);
    bb->Release();
    if (FAILED(hr)) { logf("CreateRTV 0x%08lX", (unsigned long)hr); return false; }
    return true;
}
static void initD3D() {
    UINT flags = D3D11_CREATE_DEVICE_BGRA_SUPPORT;
    D3D_FEATURE_LEVEL fl;
    HRESULT hr = D3D11CreateDevice(nullptr, D3D_DRIVER_TYPE_HARDWARE, 0, flags,
                                   nullptr, 0, D3D11_SDK_VERSION, &g_dev, &fl, &g_ctx);
    if (FAILED(hr)) {
        logf("HW device failed (0x%08lX), trying WARP", (unsigned long)hr);
        hr = D3D11CreateDevice(nullptr, D3D_DRIVER_TYPE_WARP, 0, flags,
                               nullptr, 0, D3D11_SDK_VERSION, &g_dev, &fl, &g_ctx);
        if (FAILED(hr)) { logf("WARP failed 0x%08lX", (unsigned long)hr); fatalD3D(); }
    }
    IDXGIDevice* dxdev = nullptr; IDXGIAdapter* adap = nullptr; IDXGIFactory2* fac = nullptr;
    g_dev->QueryInterface(kIID_IDXGIDevice, (void**)&dxdev);
    if (dxdev) dxdev->GetAdapter(&adap);
    if (adap) {
        DXGI_ADAPTER_DESC ad; adap->GetDesc(&ad);
        logf("GPU: %ls \u00b7 feature level 0x%X", ad.Description, fl);
        wcsncpy(g_gpuLine, ad.Description, 95);
        adap->GetParent(kIID_IDXGIFactory2, (void**)&fac);
    }
    if (dxdev) dxdev->Release();
    if (!fac) { logf("CreateSwapChain 0x%08lX", 0UL); fatalD3D(); }
    DXGI_SWAP_CHAIN_DESC1 sd = {};
    sd.Width = g_cw; sd.Height = g_ch;
    sd.Format = DXGI_FORMAT_B8G8R8A8_UNORM;
    sd.SampleDesc.Count = 1;
    sd.BufferUsage = DXGI_USAGE_RENDER_TARGET_OUTPUT;
    sd.BufferCount = 2;
    sd.Scaling = DXGI_SCALING_NONE;
    sd.SwapEffect = DXGI_SWAP_EFFECT_FLIP_DISCARD;
    sd.AlphaMode = DXGI_ALPHA_MODE_IGNORE;
    hr = fac->CreateSwapChainForHwnd(g_dev, g_hwnd, &sd, nullptr, nullptr, &g_swap);
    if (adap) adap->Release();
    fac->Release();
    if (FAILED(hr)) { logf("CreateSwapChain 0x%08lX", (unsigned long)hr); fatalD3D(); }
    if (!makeRTV()) fatalD3D();

    // shaders — compile the recovered suite
    const char* entries[SH_COUNT] = { "psVideo", "psOverlay", "psSolid", "psGrad", "psCircle", "psGlow" };
    ID3DBlob *blob = nullptr, *errb = nullptr;
    hr = D3DCompile(kShaderSrc, strlen(kShaderSrc), nullptr, nullptr, nullptr,
                    "vsMain", "vs_4_0", 0, 0, &blob, &errb);
    if (FAILED(hr)) { logf("shader %s: 0x%08lX %s", "vsMain", (unsigned long)hr,
                          errb ? (char*)errb->GetBufferPointer() : ""); fatalD3D(); }
    hr = g_dev->CreateVertexShader(blob->GetBufferPointer(), blob->GetBufferSize(), nullptr, &g_vs);
    if (FAILED(hr)) { logf("create shader %d 0x%08lX", -1, (unsigned long)hr); fatalD3D(); }
    blob->Release(); if (errb) { errb->Release(); errb = nullptr; }
    for (int i = 0; i < SH_COUNT; i++) {
        hr = D3DCompile(kShaderSrc, strlen(kShaderSrc), nullptr, nullptr, nullptr,
                        entries[i], "ps_4_0", 0, 0, &blob, &errb);
        if (FAILED(hr)) { logf("shader %s: 0x%08lX %s", entries[i], (unsigned long)hr,
                              errb ? (char*)errb->GetBufferPointer() : ""); fatalD3D(); }
        hr = g_dev->CreatePixelShader(blob->GetBufferPointer(), blob->GetBufferSize(), nullptr, &g_ps[i]);
        if (FAILED(hr)) { logf("create shader %d 0x%08lX", i, (unsigned long)hr); fatalD3D(); }
        blob->Release(); if (errb) { errb->Release(); errb = nullptr; }
    }
    D3D11_BUFFER_DESC bd = {};
    bd.ByteWidth = 32; bd.Usage = D3D11_USAGE_DYNAMIC;
    bd.BindFlags = D3D11_BIND_CONSTANT_BUFFER; bd.CPUAccessFlags = D3D11_CPU_ACCESS_WRITE;
    g_dev->CreateBuffer(&bd, nullptr, &g_cbVS);
    g_dev->CreateBuffer(&bd, nullptr, &g_cbPS);
    D3D11_BLEND_DESC bl = {};
    bl.RenderTarget[0].BlendEnable = TRUE;
    bl.RenderTarget[0].SrcBlend = D3D11_BLEND_SRC_ALPHA;
    bl.RenderTarget[0].DestBlend = D3D11_BLEND_INV_SRC_ALPHA;
    bl.RenderTarget[0].BlendOp = D3D11_BLEND_OP_ADD;
    bl.RenderTarget[0].SrcBlendAlpha = D3D11_BLEND_ONE;
    bl.RenderTarget[0].DestBlendAlpha = D3D11_BLEND_INV_SRC_ALPHA;
    bl.RenderTarget[0].BlendOpAlpha = D3D11_BLEND_OP_ADD;
    bl.RenderTarget[0].RenderTargetWriteMask = D3D11_COLOR_WRITE_ENABLE_ALL;
    g_dev->CreateBlendState(&bl, &g_blend);
    D3D11_SAMPLER_DESC smp = {};
    smp.Filter = D3D11_FILTER_MIN_MAG_MIP_LINEAR;
    smp.AddressU = smp.AddressV = smp.AddressW = D3D11_TEXTURE_ADDRESS_CLAMP;
    smp.MaxLOD = D3D11_FLOAT32_MAX;
    g_dev->CreateSamplerState(&smp, &g_samp);
    D3D11_RASTERIZER_DESC rs = {};
    rs.FillMode = D3D11_FILL_SOLID; rs.CullMode = D3D11_CULL_NONE;
    rs.DepthClipEnable = TRUE;
    g_dev->CreateRasterizerState(&rs, &g_rast);
}
static void resizeD3D() {
    if (!g_swap) return;
    if (g_rtv) { g_rtv->Release(); g_rtv = nullptr; }
    g_ctx->OMSetRenderTargets(0, nullptr, nullptr);
    g_swap->ResizeBuffers(0, g_cw, g_ch, DXGI_FORMAT_UNKNOWN, 0);
    makeRTV();
}
// ------------------------------------------------------------ draw helpers --
static void cbWrite(ID3D11Buffer* b, const float* v) {
    D3D11_MAPPED_SUBRESOURCE m;
    if (SUCCEEDED(g_ctx->Map(b, 0, D3D11_MAP_WRITE_DISCARD, 0, &m))) {
        memcpy(m.pData, v, 32); g_ctx->Unmap(b, 0);
    }
}
static void drawQuad(float x, float y, float w, float h,
                     float u0, float v0, float u1, float v1, int ps,
                     const float* misc, const float* misc2,
                     ID3D11ShaderResourceView* t0 = nullptr,
                     ID3D11ShaderResourceView* t1 = nullptr) {
    float vs[8] = {
        x / g_cw * 2 - 1, 1 - y / g_ch * 2,
        w / g_cw * 2,     -h / g_ch * 2,
        u0, v0, u1 - u0, v1 - v0
    };
    cbWrite(g_cbVS, vs);
    float pscb[8] = { 0,0,0,0, 0,0,0,0 };
    if (misc)  memcpy(pscb, misc, 16);
    if (misc2) memcpy(pscb + 4, misc2, 16);
    cbWrite(g_cbPS, pscb);
    g_ctx->VSSetShader(g_vs, nullptr, 0);
    g_ctx->PSSetShader(g_ps[ps], nullptr, 0);
    g_ctx->VSSetConstantBuffers(0, 1, &g_cbVS);
    g_ctx->PSSetConstantBuffers(1, 1, &g_cbPS);
    ID3D11ShaderResourceView* srvs[2] = { t0, t1 };
    g_ctx->PSSetShaderResources(0, 2, srvs);
    g_ctx->PSSetSamplers(0, 1, &g_samp);
    g_ctx->IASetPrimitiveTopology(D3D11_PRIMITIVE_TOPOLOGY_TRIANGLESTRIP);
    g_ctx->IASetInputLayout(nullptr);
    g_ctx->Draw(4, 0);
}
static void fillRect(float x, float y, float w, float h, COLORREF c, float a) {
    x = floorf(x + 0.5f); y = floorf(y + 0.5f);
    float m[4] = { GetRValue(c)/255.f, GetGValue(c)/255.f, GetBValue(c)/255.f, a * g_uiA };
    drawQuad(x, y, floorf(w + 0.5f), floorf(h + 0.5f), 0,0,1,1, SH_SOLID, m, nullptr);
}
static void borderRect(float x, float y, float w, float h, COLORREF c, float a, float t = 1) {
    fillRect(x, y, w, t, c, a); fillRect(x, y + h - t, w, t, c, a);
    fillRect(x, y, t, h, c, a); fillRect(x + w - t, y, t, h, c, a);
}
static void scrimRect(float x, float y, float w, float h, float a) {
    float m[4] = { 0,0,0, a * g_uiA };
    drawQuad(floorf(x+0.5f), floorf(y+0.5f), floorf(w+0.5f), floorf(h+0.5f), 0,0,1,1, SH_GRAD, m, nullptr);
}
static void circleDot(float cx, float cy, float r, COLORREF c, float a) {
    float m[4]  = { GetRValue(c)/255.f, GetGValue(c)/255.f, GetBValue(c)/255.f, a * g_uiA };
    float m2[4] = { r * 0.9f, 0, 0, 0 };
    drawQuad(cx - r, cy - r, r * 2, r * 2, 0,0,1,1, SH_CIRCLE, m, m2);
}
static void glowDot(float cx, float cy, float r, COLORREF c, float a) {
    float m[4] = { GetRValue(c)/255.f, GetGValue(c)/255.f, GetBValue(c)/255.f, a * g_uiA };
    drawQuad(cx - r, cy - r, r * 2, r * 2, 0,0,1,1, SH_GLOW, m, nullptr);
}
static void drawSrv(float x, float y, float w, float h, ID3D11ShaderResourceView* s, float a) {
    float m2[4] = { 0, a * g_uiA, 0, 0 };
    drawQuad(floorf(x+0.5f), floorf(y+0.5f), w, h, 0,0,1,1, SH_OVERLAY, nullptr, m2, s);
}

// ----------------------------------------------------------- GDI text baker --
enum { F_COND = 0, F_CONDB, F_MONO, F_SYM, F_MONOSP };
static HDC g_measDC = 0;
static std::map<long long, HFONT> g_fonts;
struct Baked { ID3D11ShaderResourceView* srv = nullptr; int w = 0, h = 0; };
static std::map<std::wstring, Baked> g_bake;

static HFONT fontFor(int id, int px) {
    long long key = (long long)id * 8192 + px;
    auto it = g_fonts.find(key); if (it != g_fonts.end()) return it->second;
    const wchar_t* face = (id == F_MONO || id == F_MONOSP) ? L"Consolas"
                        : id == F_SYM  ? L"Segoe UI Symbol"
                        : L"Bahnschrift Condensed";
    HFONT f = CreateFontW(-px, 0, 0, 0, id == F_CONDB ? FW_BOLD : FW_NORMAL,
                          0, 0, 0, DEFAULT_CHARSET, OUT_DEFAULT_PRECIS,
                          CLIP_DEFAULT_PRECIS, ANTIALIASED_QUALITY,
                          DEFAULT_PITCH, face);
    g_fonts[key] = f; return f;
}
static int textW(const std::wstring& t, int font, int px) {
    if (!g_measDC) g_measDC = CreateCompatibleDC(0);
    SelectObject(g_measDC, fontFor(font, px * 2));   // measure at bake scale
    SetTextCharacterExtra(g_measDC, font == F_MONOSP ? (px * 2) / 3 : 0);
    SIZE sz = {0,0};
    GetTextExtentPoint32W(g_measDC, t.c_str(), (int)t.size(), &sz);
    return (sz.cx + 1) / 2;
}
static Baked bakeText(const std::wstring& t, int font, int px, COLORREF col) {
    std::wstring key = wfmt(L"%d|%d|%06X|", font, px, (unsigned)col) + t;
    auto it = g_bake.find(key); if (it != g_bake.end()) return it->second;
    Baked bk;
    if (!g_measDC) g_measDC = CreateCompatibleDC(0);
    HFONT hf = fontFor(font, px * 2);                // bake at 2x, draw at 1x:
    SelectObject(g_measDC, hf);                      // linear downsample = smooth
    SetTextCharacterExtra(g_measDC, font == F_MONOSP ? (px * 2) / 3 : 0);
    SIZE sz = {0,0};
    GetTextExtentPoint32W(g_measDC, t.c_str(), (int)t.size(), &sz);
    int bw = sz.cx + 4, bh = sz.cy + 4;
    if (bw < 5 || bh < 5 || bw > 4096) { g_bake[key] = bk; return bk; }
    BITMAPINFO bi = {};
    bi.bmiHeader.biSize = sizeof(BITMAPINFOHEADER);
    bi.bmiHeader.biWidth = bw; bi.bmiHeader.biHeight = -bh;
    bi.bmiHeader.biPlanes = 1; bi.bmiHeader.biBitCount = 32;
    void* bits = nullptr;
    HDC dc = CreateCompatibleDC(0);
    HBITMAP bmp = CreateDIBSection(dc, &bi, DIB_RGB_COLORS, &bits, 0, 0);
    if (!bmp) { DeleteDC(dc); g_bake[key] = bk; return bk; }
    SelectObject(dc, bmp);
    memset(bits, 0, (size_t)bw * bh * 4);
    SetBkMode(dc, TRANSPARENT);
    SetTextColor(dc, RGB(255,255,255));
    SelectObject(dc, hf);
    SetTextCharacterExtra(dc, font == F_MONOSP ? (px * 2) / 3 : 0);
    TextOutW(dc, 2, 2, t.c_str(), (int)t.size());
    GdiFlush();
    static uint8_t lut[256]; static bool lutInit = false;
    if (!lutInit) {                                  // gamma lift: fuller strokes
        for (int i = 0; i < 256; i++)
            lut[i] = (uint8_t)(powf(i / 255.0f, 0.82f) * 255.0f + 0.5f);
        lutInit = true;
    }
    std::vector<uint8_t> px4((size_t)bw * bh * 4);
    const uint8_t* src = (const uint8_t*)bits;
    uint8_t cr = GetRValue(col), cg = GetGValue(col), cb = GetBValue(col);
    for (size_t i = 0; i < (size_t)bw * bh; i++) {
        uint8_t a = lut[src[i * 4 + 1]];             // grayscale AA -> alpha
        px4[i*4+0] = cb; px4[i*4+1] = cg; px4[i*4+2] = cr; px4[i*4+3] = a;
    }
    DeleteObject(bmp); DeleteDC(dc);
    D3D11_TEXTURE2D_DESC td = {};
    td.Width = bw; td.Height = bh; td.MipLevels = 1; td.ArraySize = 1;
    td.Format = DXGI_FORMAT_B8G8R8A8_UNORM; td.SampleDesc.Count = 1;
    td.Usage = D3D11_USAGE_IMMUTABLE; td.BindFlags = D3D11_BIND_SHADER_RESOURCE;
    D3D11_SUBRESOURCE_DATA sd = { px4.data(), (UINT)(bw * 4), 0 };
    ID3D11Texture2D* tex = nullptr;
    if (SUCCEEDED(g_dev->CreateTexture2D(&td, &sd, &tex))) {
        g_dev->CreateShaderResourceView(tex, nullptr, &bk.srv);
        tex->Release();
        bk.w = (bw + 1) / 2; bk.h = (bh + 1) / 2;    // display at half = smooth
    }
    g_bake[key] = bk; return bk;
}
static void drawText(float x, float y, const std::wstring& t, int font, int px, COLORREF col, float a = 1.0f) {
    Baked b = bakeText(t, font, px, col);
    if (b.srv) drawSrv(floorf(x + 0.5f), floorf(y + 0.5f), (float)b.w, (float)b.h, b.srv, a);
}
// centre by the baked bitmap itself — glyph boxes land dead-centre (Build 7)
static void drawTextC(float cx, float cy, const std::wstring& t, int font, int px, COLORREF col, float a = 1.0f) {
    Baked b = bakeText(t, font, px, col);
    if (b.srv) drawSrv(floorf(cx - b.w / 2.0f + 0.5f), floorf(cy - b.h / 2.0f + 0.5f),
                       (float)b.w, (float)b.h, b.srv, a);
}
// 5.3 stamp: black text-stroke + shadow, then the fill (§21 Build 2)
static void drawTextOutlined(float x, float y, const std::wstring& t, int font, int px, COLORREF col, float a = 1.0f) {
    Baked bb = bakeText(t, font, px, C_BLACK);
    if (bb.srv) {
        drawSrv(x + 1, y + 2, (float)bb.w, (float)bb.h, bb.srv, a * 0.55f);   // shadow
        static const int off[8][2] = {{-1,-1},{0,-1},{1,-1},{-1,0},{1,0},{-1,1},{0,1},{1,1}};
        for (auto& o : off) drawSrv(x + o[0], y + o[1], (float)bb.w, (float)bb.h, bb.srv, a * 0.85f);
    }
    drawText(x, y, t, font, px, col, a);
}
// --------------------------------------------------- per-cam video textures --
static void ensureCamTex(Cam* c, const VFrame& f) {
    if (c->texY && c->texW == f.w && c->texH == f.h && c->texP010 == f.p010) return;
    if (c->srvY) { c->srvY->Release(); c->srvY = nullptr; }
    if (c->srvUV){ c->srvUV->Release(); c->srvUV = nullptr; }
    if (c->texY) { c->texY->Release(); c->texY = nullptr; }
    if (c->texUV){ c->texUV->Release(); c->texUV = nullptr; }
    D3D11_TEXTURE2D_DESC td = {};
    td.MipLevels = 1; td.ArraySize = 1; td.SampleDesc.Count = 1;
    td.Usage = D3D11_USAGE_DEFAULT; td.BindFlags = D3D11_BIND_SHADER_RESOURCE;
    td.Width = f.w; td.Height = f.h;
    td.Format = f.p010 ? DXGI_FORMAT_R16_UNORM : DXGI_FORMAT_R8_UNORM;
    HRESULT h1 = g_dev->CreateTexture2D(&td, nullptr, &c->texY);
    td.Width = f.w / 2; td.Height = (f.h + 1) / 2;
    td.Format = f.p010 ? DXGI_FORMAT_R16G16_UNORM : DXGI_FORMAT_R8G8_UNORM;
    HRESULT h2 = g_dev->CreateTexture2D(&td, nullptr, &c->texUV);
    if (FAILED(h1) || FAILED(h2) || !c->texY || !c->texUV) {
        logf("[%s] texture create failed %dx%d", toUtf8(c->name).c_str(), f.w, f.h);
        return;
    }
    g_dev->CreateShaderResourceView(c->texY, nullptr, &c->srvY);
    g_dev->CreateShaderResourceView(c->texUV, nullptr, &c->srvUV);
    c->texW = f.w; c->texH = f.h; c->texP010 = f.p010;
}
static void uploadCamFrame(Cam* c) {
    bool fresh = false; int slot = -1;
    AcquireSRWLockExclusive(&c->fLock);
    if (c->fNew) { c->fFront = c->fPending; c->fPending = -1; c->fNew = false; fresh = true; }
    slot = c->fFront;
    ReleaseSRWLockExclusive(&c->fLock);
    if (slot < 0) return;
    VFrame& f = c->fr[slot];
    if (!f.valid) return;
    ensureCamTex(c, f);
    if (!fresh || !c->texY || !c->texUV) return;
    g_ctx->UpdateSubresource(c->texY, 0, nullptr, f.y.data(), f.strideY, 0);
    g_ctx->UpdateSubresource(c->texUV, 0, nullptr, f.uv.data(), f.strideUV, 0);
}

// ============================================================================
// SECTION 6 · wall UI — layout, panes, strip, popups (5.3 clone, §19-§21)
// ============================================================================

enum HitId {
    HT_NONE = 0, HT_PANE, HT_VOL, HT_MUTE, HT_RST, HT_FS, HT_PEN, HT_CLOSE, HT_GEAR, HT_ROTLK,
    HT_S_PANEL, HT_S_CHK, HT_S_GRIP, HT_S_HD, HT_S_EDIT, HT_S_DEL, HT_S_ADD,
    HT_S_CLR, HT_S_RESETW, HT_S_FIT, HT_S_SOFT, HT_S_MAIL, HT_S_BAR, HT_S_CLOSE, HT_S_MSUP,
    HT_S_ROT, HT_S_ROTS, HT_S_RCHK,
    HT_E_PANEL, HT_E_PICK, HT_E_ROW, HT_E_NAME, HT_E_ADDR, HT_E_HD,
    HT_E_APPLY, HT_E_CANCEL, HT_E_HIST
};
struct Hit { RECT r; int id; int a; };
static std::vector<Hit> g_hits;
static void pushHit(float x, float y, float w, float h, int id, int a = 0) {
    Hit t; t.r = { (LONG)x, (LONG)y, (LONG)(x + w), (LONG)(y + h) }; t.id = id; t.a = a;
    g_hits.push_back(t);
}
static const Hit* hitAt(int x, int y) {
    POINT p = { x, y };
    for (int i = (int)g_hits.size() - 1; i >= 0; i--)
        if (PtInRect(&g_hits[i].r, p)) return &g_hits[i];
    return nullptr;
}

enum Mode { M_WALL = 0, M_SHEET, M_EDIT };
static int      g_mode = M_WALL;
static uint64_t g_modeT0 = 0;
static int      g_editFrom = 0;                  // 0 = sheet-opened, 1 = ✎ pen
static int      g_mx = -100, g_my = -100;
static bool     g_inWin = false;
static float    g_gearA = 0;
static std::map<int, float> g_stripA;
static bool     g_diag = false;
static int      g_sureCam = -1; static uint64_t g_sureT0 = 0;
static float    g_scroll = 0, g_scrollMax = 0;

enum DragKind { DR_NONE = 0, DR_MAYBE, DR_VOL, DR_SOFT, DR_MSUP, DR_ROTS, DR_PANE, DR_ROW, DR_BAR, DR_TEXT };
static struct { int kind = DR_NONE; int cam = -1; RECT r = {}; POINT p0 = {}; int target = -1; float f0 = 0; } g_drag;

static struct { int cam = -1; std::wstring txt; uint64_t t0 = 0; } g_vpop;
static struct { std::wstring txt; uint64_t t0 = 0; } g_toast;
static void toast(const std::wstring& t) { g_toast.txt = t; g_toast.t0 = nowMs(); }
static void vpopShow(int cam, float vol) {
    g_vpop.cam = cam; g_vpop.t0 = nowMs();
    g_vpop.txt = vol > 0.004f ? wfmt(L"vol %d%%", (int)lroundf(vol * 100)) : L"muted";
}

struct PaneRect { int cam; RECT r; };
static std::vector<PaneRect> g_panes;            // rebuilt every frame

static void layoutWall(const std::vector<int>& vis) {
    g_panes.clear();
    int n = (int)vis.size(); if (!n) return;
    int cols = n <= 3 ? n : 3;
    int rows = (n + cols - 1) / cols;
    for (int i = 0; i < n; i++) {
        int cx = i % cols, cy = i / cols;
        RECT r;
        r.left   = cx * g_cw / cols;         r.top    = cy * g_ch / rows;
        r.right  = (cx + 1) * g_cw / cols;   r.bottom = (cy + 1) * g_ch / rows;
        if (cx < cols - 1) r.right  -= 2;    // 2 px seam between panes
        if (cy < rows - 1) r.bottom -= 2;
        g_panes.push_back({ vis[i], r });
    }
}
// fit math — cover crops via UV, contain letterboxes the dst, stretch fills (§19)
static void fitRects(const RECT& p, int vw, int vh, int mode,
                     float& dx, float& dy, float& dw, float& dh,
                     float& u0, float& v0, float& u1, float& v1) {
    float pw = float(p.right - p.left), ph = float(p.bottom - p.top);
    dx = (float)p.left; dy = (float)p.top; dw = pw; dh = ph;
    u0 = 0; v0 = 0; u1 = 1; v1 = 1;
    if (mode == FIT_STRETCH || vw <= 0 || vh <= 0) return;
    if (mode == FIT_CONTAIN) {
        float s = std::min(pw / vw, ph / vh);
        dw = floorf(vw * s + 0.5f); dh = floorf(vh * s + 0.5f);
        dx = floorf(p.left + (pw - dw) / 2); dy = floorf(p.top + (ph - dh) / 2);
    } else {                                       // cover
        float s = std::max(pw / vw, ph / vh);
        float cw2 = pw / s / vw, ch2 = ph / s / vh; // visible fraction
        u0 = (1 - cw2) / 2; u1 = u0 + cw2;
        v0 = (1 - ch2) / 2; v1 = v0 + ch2;
    }
}
static int effFit(bool fullscreen) {
    int m = g_fit;
    if (fullscreen && m == FIT_COVER) m = FIT_CONTAIN;  // fullscreen-follows-fit law
    return m;
}
static bool ptIn(const RECT& r, int x, int y) { POINT p = { x, y }; return PtInRect(&r, p) != 0; }

// glyphs (Segoe UI Symbol — recovered font)
static const wchar_t GL_RESET[] = L"\u21bb";
static const wchar_t GL_FS[]    = L"\u26f6";
static const wchar_t GL_PEN[]   = L"\u270e";
static const wchar_t GL_X[]     = L"\u2715";
static const wchar_t GL_GEAR[]  = L"\u2699";
static const wchar_t GL_GRIP[]  = L"\u22ee";
static const wchar_t GL_SPK[]   = L"\U0001F50A";
static const wchar_t GL_MUTE[]  = L"\U0001F507";
static const wchar_t GL_DROP[]  = L"\u25be";
static const wchar_t GL_LOCK[]  = L"\U0001F512";   // Build 10: pane pinned
static const wchar_t GL_UNLK[]  = L"\U0001F513";   // Build 10: pane rotates
static const wchar_t GL_ROT[]   = L"\u27f3";       // Build 10: pool checkbox glyph

static void drawStatusPane(Cam* c, const RECT& r) {
    float cxm = (r.left + r.right) / 2.0f, cym = (r.top + r.bottom) / 2.0f;
    int st = c->state;
    std::wstring big, small;
    if (st == ST_CONNECT) {
        big = L"CONNECTING";
        int at = c->attempt; if (at > 1) small = wfmt(L"attempt %d", at);
    } else if (st == ST_RETRY) {
        big = L"RETRYING";
        AcquireSRWLockShared(&c->errLock); std::wstring e = c->errText; ReleaseSRWLockShared(&c->errLock);
        small = e.empty() ? wfmt(L"attempt %d", c->attempt.load())
                          : e + wfmt(L" \u00b7 attempt %d", c->attempt.load());
    } else if (st == ST_RESET) {
        big = L"RESETTING";
        small = wfmt(L"letting the camera free its slot \u00b7 %ds", c->coolLeft.load());
    } else return;
    int bpx = (int)(20 * g_uiS), spx = (int)(12 * g_uiS);
    float bw = (float)textW(big, F_CONDB, bpx);
    drawText(cxm - bw / 2, cym - bpx, big, F_CONDB, bpx, C_DIM);
    if (!small.empty()) {
        float sw = (float)textW(small, F_MONO, spx);
        drawText(cxm - sw / 2, cym + 4 * g_uiS, small, F_MONO, spx, C_DIM, 0.85f);
    }
}

static void drawPane(Cam* c, const RECT& r, bool fullscreen) {
    float s = g_uiS;
    uploadCamFrame(c);
    bool live = c->state == ST_LIVE && c->srvY && c->srvUV;
    if (live) {
        float dx, dy, dw, dh, u0, v0, u1, v1;
        fitRects(r, c->texW, c->texH, effFit(fullscreen) , dx, dy, dw, dh, u0, v0, u1, v1);
        float soft = g_soft / 10.0f;
        float m[4] = { c->texP010 ? P010_SCALE : 1.0f,
                       soft > 0 ? soft / c->texW : 0,
                       soft > 0 ? soft / c->texH : 0, 0 };
        drawQuad(dx, dy, dw, dh, u0, v0, u1, v1, SH_VIDEO, m, nullptr, c->srvY, c->srvUV);
    } else {
        drawStatusPane(c, r);
    }
    // stamp — pinned 7 px / 11 px like the CSS (§21)
    {
        int px = (int)(12 * s);
        std::wstring nm = c->name;
        for (auto& wc2 : nm) wc2 = (wchar_t)towupper(wc2);
        float w = (float)textW(nm, F_MONOSP, px) - px / 3.0f;   // drop trailing gap
        drawTextOutlined(r.right - 11 * s - w, r.top + 7 * s, nm, F_MONOSP, px, C_WHITE, 0.95f);
    }
    // diagnostics overlay (D)
    if (g_diag && live) {
        std::wstring d = wfmt(L"%hs \u00b7 %dx%d \u00b7 %.1f fps \u00b7 dec %.1f ms \u00b7 %.0f kb/s \u00b7 %hs \u00b7 audio %hs",
                              c->codecName, c->vw.load(), c->vh.load(),
                              c->fps.load(), c->decMs.load(), c->kbps.load(),
                              c->decodeMode, c->audioDesc);
        int px = (int)(12 * s);
        float w = (float)textW(d, F_MONO, px);
        fillRect((float)r.left + 8 * s, (float)r.top + 8 * s, w + 12 * s, px + 10 * s, C_BLACK, 0.62f);
        drawText((float)r.left + 14 * s, (float)r.top + 12 * s, d, F_MONO, px, C_TEXT);
    }
    // whole pane hit (buttons pushed after -> win reverse scan)
    pushHit((float)r.left, (float)r.top, (float)(r.right - r.left), (float)(r.bottom - r.top), HT_PANE, c->idx);

    // 5.3 hover strip
    float a = 0;
    auto it = g_stripA.find(c->idx); if (it != g_stripA.end()) a = it->second;
    if (a > 0.02f && g_mode == M_WALL) {
        float sh = 34 * s;
        scrimRect((float)r.left, (float)r.bottom - 46 * s, (float)(r.right - r.left), 46 * s, a);  // B10: hugs the buttons
        float cy = r.bottom - sh / 2;
        float x = r.left + 14 * s;
        bool up = c->state == ST_LIVE;
        glowDot(x, cy, 11 * s, up ? C_LED : C_RED, a * 0.4f);
        circleDot(x, cy, 4.5f * s, up ? C_LED : C_RED, a);
        x += 16 * s;
        // volume slider
        float vol = c->vol;
        float tw = 110 * s, th = 3 * s;
        fillRect(x, cy - th / 2, tw, th, C_SEAM, a);
        fillRect(x, cy - th / 2, tw * vol, th, C_LED, a);
        circleDot(x + tw * vol, cy, 5.0f * s, C_LED, a);
        pushHit(x - 6 * s, cy - 10 * s, tw + 12 * s, 20 * s, HT_VOL, c->idx);
        x += tw + 12 * s;
        std::wstring pct = vol > 0.004f ? wfmt(L"%d%%", (int)lroundf(vol * 100)) : L"off";
        drawText(x, cy - 7 * s, pct, F_MONO, (int)(12 * s), C_TEXT, a);
        x += 38 * s;
        // mute toggle (Build 2)
        {
            float bx = x, bw2 = 22 * s;
            bool hov = ptIn({ (LONG)bx, (LONG)(cy - 11 * s), (LONG)(bx + bw2), (LONG)(cy + 11 * s) }, g_mx, g_my);
            if (hov) fillRect(bx, cy - 11 * s, bw2, 22 * s, C_WHITE, a * 0.09f);
            borderRect(bx, cy - 11 * s, bw2, 22 * s, C_SEAM, a * 0.9f);
            std::wstring gl = vol > 0.004f ? GL_SPK : GL_MUTE;
            drawTextC(bx + bw2 / 2, cy, gl, F_SYM, (int)(13 * s), C_TEXT, a);
            pushHit(bx, cy - 11 * s, bw2, 22 * s, HT_MUTE, c->idx);
        }
        // right-side buttons: ↻ ⛶ ✎ ✕
        struct Btn { const wchar_t* g; int id; } btns[4] = {
            { GL_X, HT_CLOSE }, { GL_PEN, HT_PEN }, { GL_FS, HT_FS }, { GL_RESET, HT_RST }
        };
        float bx = (float)r.right - 10 * s;
        for (auto& b : btns) {
            float bw2 = 24 * s; bx -= bw2 + 4 * s;
            bool hov = ptIn({ (LONG)bx, (LONG)(cy - 12 * s), (LONG)(bx + bw2), (LONG)(cy + 12 * s) }, g_mx, g_my);
            if (hov) fillRect(bx, cy - 12 * s, bw2, 24 * s, C_WHITE, a * 0.10f);
            borderRect(bx, cy - 12 * s, bw2, 24 * s, C_SEAM, a * 0.9f);
            drawTextC(bx + bw2 / 2, cy, b.g, F_SYM, (int)(13 * s), C_TEXT, a);
            pushHit(bx, cy - 12 * s, bw2, 24 * s, b.id, c->idx);
        }
        if (g_rotOn) {                       // Build 10: per-pane rotation lock
            bool lk = !c->rot;               // locked = pinned, never rotates out
            float bw2 = 24 * s; bx -= bw2 + 4 * s;
            bool hov = ptIn({ (LONG)bx, (LONG)(cy - 12 * s), (LONG)(bx + bw2), (LONG)(cy + 12 * s) }, g_mx, g_my);
            if (hov) fillRect(bx, cy - 12 * s, bw2, 24 * s, C_WHITE, a * 0.10f);
            borderRect(bx, cy - 12 * s, bw2, 24 * s, lk ? C_LED : C_SEAM, a * 0.9f);
            drawTextC(bx + bw2 / 2, cy, lk ? GL_LOCK : GL_UNLK, F_SYM, (int)(12 * s),
                      lk ? C_LED : C_TEXT, a);
            pushHit(bx, cy - 12 * s, bw2, 24 * s, HT_ROTLK, c->idx);
        }
        if (c->state == ST_LIVE) {                   // "H264   21ms" beside ↻ (Build 3)
            std::wstring cod = toWide(c->codecName);
            for (auto& wc2 : cod) wc2 = (wchar_t)towupper(wc2);
            uint64_t nt3 = nowMs(), lf = c->lastFrame.load();
            int gap = c->frameGap.load();
            int since = lf ? (int)(nt3 - lf) : 0;
            bool stall = since > gap + 150;
            int msv = stall ? since : gap;                // stalls always climb live
            int hold = g_msUpd * 100;                     // MS UPDATE (0.0-3.0 s)
            if (stall || hold == 0 || !c->uiMsTick || nt3 - c->uiMsTick >= (uint64_t)hold) {
                c->uiMsShown = msv; c->uiMsTick = nt3;
            }
            std::wstring lat = wfmt(L"%dms", c->uiMsShown);
            float lw = (float)textW(lat, F_MONO, (int)(11 * s));
            float cw2 = (float)textW(cod, F_MONO, (int)(11 * s));
            drawText(bx - lw - 12 * s, cy - 7 * s, lat, F_MONO, (int)(11 * s), C_DIM, a);
            drawText(bx - lw - 12 * s - cw2 - 14 * s, cy - 7 * s, cod, F_MONO, (int)(11 * s), C_DIM, a);
        }
    }
    // volume popup
    if (g_vpop.cam == c->idx) {
        uint64_t age = nowMs() - g_vpop.t0;
        if (age < 900) {
            float va = age > 700 ? 1.0f - (age - 700) / 200.0f : 1.0f;
            int px = (int)(12 * s);
            float w = (float)textW(g_vpop.txt, F_MONO, px) + 22 * s;
            float x = (r.left + r.right) / 2.0f - w / 2, y = (float)r.top + 10 * s;
            fillRect(x, y, w, 24 * s, C_FACE, 0.9f * va);
            borderRect(x, y, w, 24 * s, C_SEAM, va);
            drawText(x + 11 * s, y + 5 * s, g_vpop.txt, F_MONO, px, C_TEXT, va);
        }
    }
}

static void drawEmptyWall() {
    float s = g_uiS;
    int bpx = (int)(26 * s), spx = (int)(13 * s);
    std::wstring big = L"WALL EMPTY";
    std::wstring small = L"all panes closed \u00b7 press R to restore them";
    float bw = (float)textW(big, F_CONDB, bpx), sw = (float)textW(small, F_MONO, spx);
    drawText(g_cw / 2.0f - bw / 2, g_ch / 2.0f - bpx - 4 * s, big, F_CONDB, bpx, C_DIM);
    drawText(g_cw / 2.0f - sw / 2, g_ch / 2.0f + 6 * s, small, F_MONO, spx, C_DIM, 0.85f);
}
static void drawGear() {
    if (g_mode != M_WALL || g_gearA < 0.02f) return;
    float s = g_uiS, bw = 30 * s;
    float x = g_cw - bw - 10 * s, y = 38 * s;      // sits below the stamp line
    bool hov = ptIn({ (LONG)x, (LONG)y, (LONG)(x + bw), (LONG)(y + bw) }, g_mx, g_my);
    fillRect(x, y, bw, bw, C_BLACK, 0.55f * g_gearA);          // always a plate
    if (hov) fillRect(x, y, bw, bw, C_WHITE, 0.12f * g_gearA); // hover highlight
    borderRect(x, y, bw, bw, hov ? C_LED : C_SEAM, 0.9f * g_gearA);
    drawTextC(x + bw / 2, y + bw / 2, GL_GEAR, F_SYM, (int)(17 * s), C_TEXT, 0.95f * g_gearA);
    pushHit(x, y, bw, bw, HT_GEAR);
}
static void drawToast() {
    if (g_toast.txt.empty()) return;
    uint64_t age = nowMs() - g_toast.t0;
    if (age > 2400) return;
    float a = 1;
    if (age < 150) a = age / 150.0f;
    else if (age > 2000) a = 1.0f - (age - 2000) / 400.0f;
    float s = g_uiS; int px = (int)(14 * s);
    float w = (float)textW(g_toast.txt, F_COND, px) + 28 * s;
    float x = g_cw / 2.0f - w / 2, y = (float)g_ch - 52 * s;
    fillRect(x, y, w, 30 * s, C_FACE, 0.92f * a);
    borderRect(x, y, w, 30 * s, C_SEAM, a);
    drawText(x + 14 * s, y + 7 * s, g_toast.txt, F_COND, px, C_TEXT, a);
}
static void drawDragGhost() {
    if (g_drag.kind != DR_PANE) return;
    float s = g_uiS;
    for (auto& p : g_panes) {
        if (p.cam == g_drag.cam)
            fillRect((float)p.r.left, (float)p.r.top, (float)(p.r.right - p.r.left),
                     (float)(p.r.bottom - p.r.top), C_BLACK, 0.55f);
        if (p.cam == g_drag.target && g_drag.target != g_drag.cam)
            borderRect((float)p.r.left + 1, (float)p.r.top + 1,
                       (float)(p.r.right - p.r.left) - 2, (float)(p.r.bottom - p.r.top) - 2,
                       C_LED, 0.95f, 2 * s);
    }
    Cam* c = g_cams[g_drag.cam];
    int px = (int)(13 * s);
    float w = (float)textW(c->name, F_CONDB, px) + 20 * s;
    float x = g_mx + 14.0f, y = g_my + 12.0f;
    fillRect(x, y, w, 24 * s, C_FACE, 0.94f);
    borderRect(x, y, w, 24 * s, C_LED, 0.8f);
    drawText(x + 10 * s, y + 5 * s, c->name, F_CONDB, px, C_TEXT);
}

// ============================================================================
// SECTION 7 · modals — ⚙ settings sheet + ✎ editor (pen popup / sheet-centred)
// ============================================================================

struct Field { std::wstring t; int caret = 0; int i0 = 0; int sel = -1; };
static Field g_fName, g_fAddr;
static int   g_focus = 0;                    // 0 none · 1 name · 2 addr
static bool  g_pickOpen = false;
static int   g_pickSel = -1;                 // cam idx, or -2 = "+ NEW ADDRESS"
static int   g_editAnchor = -1;              // ✎: the pane that opened the popup
static bool  g_editSD = false;
static std::wstring g_editErr;
static RECT  g_fldName = {}, g_fldAddr = {};

// scissor support for the scrolling sheet
static ID3D11RasterizerState* g_rastSc = nullptr;
static void pushScissor(const RECT& r) {
    if (!g_rastSc) {
        D3D11_RASTERIZER_DESC rs = {};
        rs.FillMode = D3D11_FILL_SOLID; rs.CullMode = D3D11_CULL_NONE;
        rs.DepthClipEnable = TRUE; rs.ScissorEnable = TRUE;
        g_dev->CreateRasterizerState(&rs, &g_rastSc);
    }
    D3D11_RECT sr = { r.left, r.top, r.right, r.bottom };
    g_ctx->RSSetScissorRects(1, &sr);
    g_ctx->RSSetState(g_rastSc);
}
static void popScissor() { g_ctx->RSSetState(g_rast); }

// ------------------------------------------------------------ field widget --
// Build 6: selection (mouse drag, Shift+arrows, Ctrl+A/C/X/V), 2x-baked text
static void fieldEnsureCaret(Field& f, int px, float wAvail) {
    if (f.caret < f.i0) f.i0 = f.caret;
    while (f.i0 < f.caret &&
           textW(f.t.substr(f.i0, f.caret - f.i0), F_MONO, px) > wAvail - 10)
        f.i0++;
    if (f.i0 > (int)f.t.size()) f.i0 = (int)f.t.size();
}
static bool fieldHasSel(const Field& f) { return f.sel >= 0 && f.sel != f.caret; }
static void selErase(Field& f) {
    if (!fieldHasSel(f)) { f.sel = -1; return; }
    int a = std::min(f.sel, f.caret), b = std::max(f.sel, f.caret);
    f.t.erase(a, b - a); f.caret = a; f.sel = -1;
}
static void clipSetText(const std::wstring& t) {
    if (!OpenClipboard(g_hwnd)) return;
    EmptyClipboard();
    size_t n = (t.size() + 1) * sizeof(wchar_t);
    HGLOBAL h = GlobalAlloc(GMEM_MOVEABLE, n);
    if (h) { memcpy(GlobalLock(h), t.c_str(), n); GlobalUnlock(h); SetClipboardData(CF_UNICODETEXT, h); }
    CloseClipboard();
}
static void fieldCopy(const Field& f) {              // selection, else the lot
    if (fieldHasSel(f)) {
        int a = std::min(f.sel, f.caret), b = std::max(f.sel, f.caret);
        clipSetText(f.t.substr(a, b - a));
    } else clipSetText(f.t);
}
static void drawField(float x, float y, float w, float h, Field& f, int hid, RECT& store) {
    float s = g_uiS; int px = (int)(12 * s);
    bool foc = (g_focus == 1 && hid == HT_E_NAME) || (g_focus == 2 && hid == HT_E_ADDR);
    fillRect(x, y, w, h, C_FACE, 0.96f);
    borderRect(x, y, w, h, foc ? C_LED : C_SEAM, foc ? 0.9f : 0.8f);
    fieldEnsureCaret(f, px, w - 16 * s);
    if (fieldHasSel(f)) {                            // selection highlight
        int a = std::max(std::min(f.sel, f.caret), f.i0);
        int b = std::max(f.sel, f.caret);
        if (b > a) {
            float x0 = x + 8*s + textW(f.t.substr(f.i0, a - f.i0), F_MONO, px);
            float x1 = x + 8*s + textW(f.t.substr(f.i0, b - f.i0), F_MONO, px);
            x1 = std::min(x1, x + w - 8*s);
            if (x1 > x0) fillRect(x0, y + 4*s, x1 - x0, h - 8*s, C_LED, 0.30f);
        }
    }
    std::wstring vis = f.t.substr(f.i0);
    while (!vis.empty() && textW(vis, F_MONO, px) > w - 16 * s) vis.pop_back();
    drawText(x + 8 * s, y + (h - px) / 2 - 2, vis, F_MONO, px, C_TEXT);
    if (foc && (nowMs() / 530) % 2 == 0) {           // blinking LED caret (§23.3)
        float cx = x + 8 * s + textW(f.t.substr(f.i0, f.caret - f.i0), F_MONO, px);
        fillRect(cx, y + 5 * s, 1.5f * s, h - 10 * s, C_LED, 0.95f);
    }
    store = { (LONG)x, (LONG)y, (LONG)(x + w), (LONG)(y + h) };
    pushHit(x, y, w, h, hid);
}
static int fieldPosFromX(Field& f, const RECT& r, int mx) {
    float s = g_uiS; int px = (int)(12 * s);
    int rel = mx - r.left - (int)(8 * s);
    int best = f.i0; int acc = 0;
    for (int i = f.i0; i <= (int)f.t.size(); i++) {
        acc = textW(f.t.substr(f.i0, i - f.i0), F_MONO, px);
        best = i;
        if (acc >= rel) {
            if (i > f.i0 && acc - rel > rel - textW(f.t.substr(f.i0, i - 1 - f.i0), F_MONO, px))
                best = i - 1;
            break;
        }
    }
    return best;
}
static void fieldChar(Field& f, wchar_t c, int maxLen) {
    if (c < 32) return;
    selErase(f);
    if ((int)f.t.size() >= maxLen) return;
    f.t.insert(f.t.begin() + f.caret, c); f.caret++;
}
static void fieldKey(Field& f, WPARAM vk) {
    bool shift = GetKeyState(VK_SHIFT) < 0;
    bool moving = vk == VK_LEFT || vk == VK_RIGHT || vk == VK_HOME || vk == VK_END;
    if (moving) {
        if (shift) { if (f.sel < 0) f.sel = f.caret; }
        else if (fieldHasSel(f)) {                    // collapse to an edge
            int a = std::min(f.sel, f.caret), b = std::max(f.sel, f.caret);
            f.caret = (vk == VK_LEFT || vk == VK_HOME) ? a : b;
            f.sel = -1;
            if (vk == VK_HOME) f.caret = 0;
            if (vk == VK_END)  f.caret = (int)f.t.size();
            return;
        } else f.sel = -1;
    }
    switch (vk) {
    case VK_LEFT:  if (f.caret > 0) f.caret--; break;
    case VK_RIGHT: if (f.caret < (int)f.t.size()) f.caret++; break;
    case VK_HOME:  f.caret = 0; break;
    case VK_END:   f.caret = (int)f.t.size(); break;
    case VK_BACK:
        if (fieldHasSel(f)) selErase(f);
        else if (f.caret > 0) { f.t.erase(f.caret - 1, 1); f.caret--; }
        break;
    case VK_DELETE:
        if (fieldHasSel(f)) selErase(f);
        else if (f.caret < (int)f.t.size()) f.t.erase(f.caret, 1);
        break;
    }
    if (moving && !shift) f.sel = -1;
}
static void fieldPaste(Field& f, int maxLen) {
    if (!OpenClipboard(g_hwnd)) return;
    HANDLE h = GetClipboardData(CF_UNICODETEXT);
    if (h) {
        wchar_t* p = (wchar_t*)GlobalLock(h);
        if (p) {
            selErase(f);
            for (int i = 0; p[i] && (int)f.t.size() < maxLen; i++)
                if (p[i] >= 32) { f.t.insert(f.t.begin() + f.caret, p[i]); f.caret++; }
            GlobalUnlock(h);
        }
    }
    CloseClipboard();
}

// --------------------------------------------------------------- actions ----
static void rotKick();                       // Build 10: reset the rotation clock
static void spawnWorker(Cam* c) { c->th = CreateThread(0, 0, camWorker, c, 0, 0); }
static void copyEmail() {
    if (OpenClipboard(g_hwnd)) {
        EmptyClipboard();
        size_t n = (wcslen(kEmail) + 1) * 2;
        HGLOBAL h = GlobalAlloc(GMEM_MOVEABLE, n);
        if (h) { memcpy(GlobalLock(h), kEmail, n); GlobalUnlock(h); SetClipboardData(CF_UNICODETEXT, h); }
        CloseClipboard();
    }
    toast(std::wstring(L"email copied \u00b7 ") + kEmail);
}
static void takeover(int a, int x) {         // caller holds exclusive g_dataLock
    if (a == x || a < 0 || x < 0) return;
    int ia = -1, ix = -1;
    for (size_t i = 0; i < g_order.size(); i++) {
        if (g_order[i] == a) ia = (int)i;
        if (g_order[i] == x) ix = (int)i;
    }
    if (ia >= 0 && ix >= 0) std::swap(g_order[ia], g_order[ix]);
    g_cams[x]->on = true; g_cams[a]->on = false;
    rotKick();                               // manual takeover resets the clock (B10)
    logf("pane takeover: %s -> %s", toUtf8(g_cams[a]->name).c_str(), toUtf8(g_cams[x]->name).c_str());
}
static void closeEditor(bool backToSheet) {
    g_mode = (backToSheet && g_editFrom == 0) ? M_SHEET : M_WALL;
    g_modeT0 = nowMs(); g_focus = 0; g_pickOpen = false; g_editErr.clear();
}
static void loadEditorFrom(int sel) {
    g_pickSel = sel; g_editErr.clear(); g_focus = 0;
    if (sel == -2) { g_fName = Field(); g_fAddr = Field(); g_fAddr.t = L"rtsp://"; g_fAddr.caret = 7; g_editSD = false; return; }
    AcquireSRWLockShared(&g_dataLock);
    Cam* c = g_cams[sel];
    g_fName = Field(); g_fName.t = c->name;      // caret at 0: full text shows
    g_fAddr = Field(); g_fAddr.t = toWide(c->url);   // from rtsp:// onward
    g_editSD = c->sd;
    ReleaseSRWLockShared(&g_dataLock);
}
static void openEditor(int cam, int fromPen) {
    g_mode = M_EDIT; g_editFrom = fromPen; g_editAnchor = fromPen ? cam : -1;
    g_modeT0 = nowMs(); g_pickOpen = false;
    loadEditorFrom(cam);
}
static void applyEditor() {
    std::wstring nm = g_fName.t;
    while (!nm.empty() && nm.back() == L' ') nm.pop_back();
    while (!nm.empty() && nm.front() == L' ') nm.erase(nm.begin());
    std::string url = toUtf8(g_fAddr.t);
    while (!url.empty() && url.back() == ' ') url.pop_back();
    if (nm.empty())                 { g_editErr = L"name required"; return; }
    if (url.rfind("rtsp://", 0) != 0) { g_editErr = L"address must start with rtsp://"; return; }

    AcquireSRWLockExclusive(&g_dataLock);
    if (g_pickSel == -2) {                             // + NEW ADDRESS
        int alive = 0; for (auto c : g_cams) if (!c->dead) alive++;
        if (alive >= MAX_PANES) {                    // Build 3 law: list caps at 9
            ReleaseSRWLockExclusive(&g_dataLock);
            g_editErr = L"wall is full (9 panes)"; return;
        }
        Cam* c = addCamRaw(nm, url, g_editSD, true);
        c->stag = 0;
        histPush(url);
        logf("camera added: %s | %s%s", toUtf8(nm).c_str(), url.c_str(), g_editSD ? " \u00b7 sd" : "");
        if (g_editFrom == 1 && g_editAnchor >= 0) takeover(g_editAnchor, c->idx);
        sanitizeOrder();
        ReleaseSRWLockExclusive(&g_dataLock);
        spawnWorker(c);
    } else {
        Cam* c = g_cams[g_pickSel];
        bool urlCh = (c->url != url) || (c->sd != g_editSD);
        c->name = nm; c->url = url; c->sd = g_editSD;
        logf("camera edited: %s | %s%s", toUtf8(nm).c_str(), url.c_str(), g_editSD ? " \u00b7 sd" : "");
        if (urlCh) { histPush(url); c->reconn = true; }
        if (g_editFrom == 1 && g_editAnchor >= 0 && g_pickSel != g_editAnchor)
            takeover(g_editAnchor, g_pickSel);
        sanitizeOrder();
        ReleaseSRWLockExclusive(&g_dataLock);
    }
    saveSettings();
    closeEditor(true);
}
static void deleteCam(int idx) {
    AcquireSRWLockExclusive(&g_dataLock);
    Cam* c = g_cams[idx];
    std::string nm = toUtf8(c->name);
    c->dead = true; c->on = false;
    sanitizeOrder();
    ReleaseSRWLockExclusive(&g_dataLock);
    rotKick();
    logf("camera removed: %s", nm.c_str());
    saveSettings();
    if (g_mode == M_EDIT && g_pickSel == idx) closeEditor(true);
}
static void toggleOn(int idx) {
    AcquireSRWLockExclusive(&g_dataLock);
    Cam* c = g_cams[idx];
    if (!c->on && onCount() >= MAX_PANES) {
        ReleaseSRWLockExclusive(&g_dataLock);
        toast(L"wall is full (9 panes)"); return;
    }
    c->on = !c->on;
    bool nowOn = c->on;
    std::string nm = toUtf8(c->name);
    ReleaseSRWLockExclusive(&g_dataLock);
    rotKick();
    if (!nowOn) logf("[%s] pane closed \u00b7 remembered in settings.json (R restores)", nm.c_str());
    saveSettings();
}
static void setQuality(int idx, bool sd) {
    AcquireSRWLockExclusive(&g_dataLock);
    Cam* c = g_cams[idx];
    if (c->sd == sd) { ReleaseSRWLockExclusive(&g_dataLock); return; }
    c->sd = sd; c->reconn = true;
    std::string nm = toUtf8(c->name);
    ReleaseSRWLockExclusive(&g_dataLock);
    logf("[%s] quality -> %s", nm.c_str(), sd ? "SD (stream2)" : "HD (stream1)");
    saveSettings();
}
static void toggleRot(int idx) {             // Build 10: pool membership / pane lock
    AcquireSRWLockExclusive(&g_dataLock);
    Cam* c = g_cams[idx];
    c->rot = !c->rot;
    bool r = c->rot; std::wstring nm = c->name;
    ReleaseSRWLockExclusive(&g_dataLock);
    rotKick();
    logf("[%s] %s", toUtf8(nm).c_str(), r ? "in rotation" : "locked \u00b7 won't rotate");
    toast(nm + (r ? L" \u00b7 rotating" : L" \u00b7 locked"));
    saveSettings();
}
static void restoreAll() {
    int n = 0;
    AcquireSRWLockExclusive(&g_dataLock);
    for (auto c : g_cams)
        if (!c->dead && !c->on && onCount() < MAX_PANES) { c->on = true; n++; }
    ReleaseSRWLockExclusive(&g_dataLock);
    rotKick();
    if (n) { logf("restore: %d pane(s) reopened", n); toast(L"panes restored"); saveSettings(); }
}
static void resetWall() {
    int n = 0;
    AcquireSRWLockExclusive(&g_dataLock);
    for (auto c : g_cams) if (!c->dead) { c->on = true; n++; }
    ReleaseSRWLockExclusive(&g_dataLock);
    rotKick();
    logf("wall reset via settings (%d cameras on)", n);
    toast(wfmt(L"wall reset \u00b7 %d cameras on", n));
    saveSettings();
}
static void clearHist() {
    AcquireSRWLockExclusive(&g_dataLock);
    g_hist.clear();
    ReleaseSRWLockExclusive(&g_dataLock);
    logf("address history cleared");
    toast(L"address history cleared");
    saveSettings();
}
static void swapPanesDrag(int a, int b) {
    AcquireSRWLockExclusive(&g_dataLock);
    int ia = -1, ib = -1;
    for (size_t i = 0; i < g_order.size(); i++) {
        if (g_order[i] == a) ia = (int)i;
        if (g_order[i] == b) ib = (int)i;
    }
    if (ia >= 0 && ib >= 0) std::swap(g_order[ia], g_order[ib]);
    std::string nm = toUtf8(g_cams[a]->name);
    ReleaseSRWLockExclusive(&g_dataLock);
    logf("order: %s moved (drag)", nm.c_str());
    saveSettings();
}
static void moveRow(int fromPos, int toPos) {
    AcquireSRWLockExclusive(&g_dataLock);
    if (fromPos < 0 || fromPos >= (int)g_order.size()) { ReleaseSRWLockExclusive(&g_dataLock); return; }
    int id = g_order[fromPos];
    g_order.erase(g_order.begin() + fromPos);
    if (toPos > fromPos) toPos--;
    toPos = std::max(0, std::min((int)g_order.size(), toPos));
    g_order.insert(g_order.begin() + toPos, id);
    std::string nm = toUtf8(g_cams[id]->name);
    ReleaseSRWLockExclusive(&g_dataLock);
    logf("order: %s moved (settings list)", nm.c_str());
    saveSettings();
}

// ----------------------------------------------- camera rotation (Build 10) -
// All unlocked panes advance together every g_rotSec seconds. Incoming
// cameras PREROLL: their workers connect hidden a few seconds before the
// tick, and the swap fires only once every incoming feed is LIVE (or after
// a 6 s grace — honest CONNECTING then). Fair round-robin via a FIFO of
// parked pool cameras; outgoing cameras rejoin at the back of the queue.
// Paused whenever the wall isn't the plain grid; every pause or manual
// wall change re-arms the clock from zero. UI thread only.
#define ROT_GRACE_MS 6000
static std::vector<int> g_rotQ;              // FIFO: parked pool cams, next-up first
static uint64_t g_rotNext  = 0;              // scheduled swap time · 0 = re-arm
static uint64_t g_rotForce = 0;              // preroll give-up deadline
static bool     g_rotPre   = false;          // preroll in flight
static std::vector<int> g_rotIn, g_rotOut;   // planned swap, parallel lists

static void rotCancelPre() {
    for (int id : g_rotIn)
        if (id >= 0 && id < (int)g_cams.size()) g_cams[id]->pre = false;
    g_rotIn.clear(); g_rotOut.clear(); g_rotPre = false;
}
static void rotKick() { rotCancelPre(); g_rotNext = 0; }
static bool rotPaused() {
    return g_mode != M_WALL || g_fsPane >= 0 || g_monFS || g_drag.kind == DR_PANE;
}
static void rotPlan() {                      // pick who leaves and who enters
    AcquireSRWLockExclusive(&g_dataLock);
    std::vector<int> vis = computeVis();
    auto onWall = [&](int id) { for (int v : vis) if (v == id) return true; return false; };
    std::vector<int> q;                      // refresh queue: drop dead/locked/visible
    for (int id : g_rotQ) {
        if (id < 0 || id >= (int)g_cams.size()) continue;
        Cam* c = g_cams[id];
        if (c->dead || !c->rot || onWall(id)) continue;
        bool dup = false; for (int e : q) if (e == id) { dup = true; break; }
        if (!dup) q.push_back(id);
    }
    for (int id : g_order) {                 // append parked pool cams we don't hold
        Cam* c = g_cams[id];
        if (c->dead || !c->rot || onWall(id)) continue;
        bool have = false; for (int e : q) if (e == id) { have = true; break; }
        if (!have) q.push_back(id);
    }
    g_rotQ.swap(q);
    std::vector<int> panes;                  // rotating (unlocked) panes, wall order
    for (int v : vis) if (g_cams[v]->rot) panes.push_back(v);
    size_t n = std::min(g_rotQ.size(), panes.size());
    g_rotIn.clear(); g_rotOut.clear();
    for (size_t k = 0; k < n; k++) { g_rotIn.push_back(g_rotQ[k]); g_rotOut.push_back(panes[k]); }
    for (int id : g_rotIn) g_cams[id]->pre = true;     // wake workers, connect hidden
    ReleaseSRWLockExclusive(&g_dataLock);
    g_rotPre = !g_rotIn.empty();
}
static void rotSwap() {                      // the all-at-once advance
    int done = 0; std::string names;
    AcquireSRWLockExclusive(&g_dataLock);
    for (size_t k = 0; k < g_rotIn.size(); k++) {
        int in = g_rotIn[k], out = g_rotOut[k];
        Cam *ci = g_cams[in], *co = g_cams[out];
        if (ci->dead || co->dead || !co->on || !ci->rot) { ci->pre = false; continue; }
        int ia = -1, ib = -1;
        for (size_t i = 0; i < g_order.size(); i++) {
            if (g_order[i] == in)  ia = (int)i;
            if (g_order[i] == out) ib = (int)i;
        }
        if (ia >= 0 && ib >= 0) std::swap(g_order[ia], g_order[ib]);
        ci->on = true; ci->pre = false; co->on = false;
        for (auto it = g_rotQ.begin(); it != g_rotQ.end(); )
            it = (*it == in) ? g_rotQ.erase(it) : it + 1;
        g_rotQ.push_back(out);               // outgoing rejoins at the back
        if (done) names += ", ";
        names += toUtf8(co->name) + " -> " + toUtf8(ci->name);
        done++;
    }
    sanitizeOrder();
    ReleaseSRWLockExclusive(&g_dataLock);
    g_rotIn.clear(); g_rotOut.clear(); g_rotPre = false;
    if (done) { logf("rotate: %s", names.c_str()); saveSettings(); }
}
static void rotTick() {                      // called once per rendered frame
    if (!g_rotOn || rotPaused()) { if (g_rotPre) rotCancelPre(); g_rotNext = 0; return; }
    uint64_t t  = nowMs();
    uint64_t iv = (uint64_t)std::max(3, std::min(60, g_rotSec.load())) * 1000;
    if (!g_rotNext) { g_rotNext = t + iv; return; }    // (re)armed fresh
    uint64_t lead = std::min<uint64_t>(4000, iv > 1500 ? iv - 1000 : 500);
    if (!g_rotPre && t + lead >= g_rotNext) {
        rotPlan();
        if (!g_rotPre) { g_rotNext = t + iv; return; } // nothing parked to rotate in
        g_rotForce = g_rotNext + ROT_GRACE_MS;
    }
    if (g_rotPre && t >= g_rotNext) {
        bool ready = true;
        for (int id : g_rotIn) if (g_cams[id]->state != ST_LIVE) { ready = false; break; }
        if (ready || t >= g_rotForce) { rotSwap(); g_rotNext = nowMs() + iv; }
    }
}

// ------------------------------------------------------------- sheet draw ---
static float g_sheetX = 0, g_sheetY = 0, g_sheetW = 0, g_sheetH = 0;
static float g_rowY0 = 0, g_rowH = 0; static int g_rowsN = 0, g_rowInsert = -1;

static void drawSheet() {
    // Build 6: rebuilt to the owner's Build 3 screenshot — full-window overlay,
    // version + contact under the title, CLOSE button, DISPLAY before CAMERAS,
    // mono styling throughout, HD/SD twin boxes, checkmark checkboxes.
    float s = g_uiS;
    float f = std::min(1.0f, (nowMs() - g_modeT0) / (float)FADE_MS);
    g_uiA = f;
    fillRect(0, 0, (float)g_cw, (float)g_ch, C_BLACK, 0.86f);

    struct Row { int id; std::wstring name; bool on, sd, rot; };
    std::vector<Row> rows;
    AcquireSRWLockShared(&g_dataLock);
    for (int id : g_order) { Cam* c = g_cams[id]; if (!c->dead) rows.push_back({ id, c->name, c->on, c->sd, c->rot }); }
    ReleaseSRWLockShared(&g_dataLock);

    float W = std::min(560.0f * s, g_cw - 60.0f);
    float X = (g_cw - W) / 2;
    float rowH = 34 * s;
    float contentH = (34 + 24 + 30 + 26 + 34 + 36 + 36 + 36 + 36 + 26) * s
                   + rows.size() * rowH + (14 + 30 + 24) * s;
    float rise = (1 - f) * 8 * s;
    float panX = X - 24*s, panW = W + 48*s;
    float panY = 28*s + rise;
    float panH = std::min((float)g_ch - 56*s, 20*s + contentH + 16*s);
    g_sheetX = X; g_sheetY = panY; g_sheetW = W; g_sheetH = panH;
    g_scrollMax = std::max(0.0f, 20*s + contentH + 16*s - panH);
    g_scroll = std::max(0.0f, std::min(g_scroll, g_scrollMax));
    fillRect(panX, panY, panW, panH, C_PANEL, 0.60f);   // Build 8: framed panel
    borderRect(panX, panY, panW, panH, C_SEAM, 1);
    pushHit(panX, panY, panW, panH, HT_S_PANEL);
    RECT clip = { (LONG)panX, (LONG)panY, (LONG)(panX + panW), (LONG)(panY + panH) };
    pushScissor(clip);
    float y = panY + 20*s - g_scroll;

    drawText(X, y, L"SETTINGS", F_CONDB, (int)(19*s), C_TEXT);
    { std::wstring ct = L"CLOSE";                                // Esc still works
      float cw2 = textW(ct, F_MONO, (int)(11*s)) + 22*s, chh = 24*s;
      float bx = X + W - cw2, by = y;
      bool hov = ptIn({(LONG)bx,(LONG)by,(LONG)(bx+cw2),(LONG)(by+chh)}, g_mx, g_my);
      if (hov) fillRect(bx, by, cw2, chh, C_WHITE, 0.08f);
      borderRect(bx, by, cw2, chh, C_SEAM, 0.95f);
      drawText(bx + 11*s, by + 6*s, ct, F_MONO, (int)(11*s), C_TEXT);
      pushHit(bx, by, cw2, chh, HT_S_CLOSE); }
    y += 34 * s;
    { std::wstring bl = wfmt(L"%s \u00b7 %s \u00b7 d3d11 \u00b7 %s \u00b7 audio %s",
                             kMilestone, kBuild, g_gpuLine, g_audioLine);
      while (!bl.empty() && textW(bl, F_MONO, (int)(11*s)) > W) bl.pop_back();
      drawText(X, y, bl, F_MONO, (int)(11*s), C_DIM); }
    y += 24 * s;
    { std::wstring sup = L"For support, contact: ";
      drawText(X, y, sup, F_MONO, (int)(11*s), C_DIM);
      float ex = X + textW(sup, F_MONO, (int)(11*s));
      float ew = (float)textW(kEmail, F_MONO, (int)(11*s));
      bool hov = ptIn({(LONG)ex,(LONG)(y-2*s),(LONG)(ex+ew),(LONG)(y+15*s)}, g_mx, g_my);
      drawText(ex, y, kEmail, F_MONO, (int)(11*s), C_LED);
      if (hov) fillRect(ex, y + 13*s, ew, 1, C_LED, 0.9f);
      pushHit(ex, y - 2*s, ew, 17*s, HT_S_MAIL); }
    y += 30 * s;

    drawText(X, y, L"DISPLAY", F_MONO, (int)(11*s), C_DIM);
    y += 26 * s;
    drawText(X, y + 7*s, L"FIT", F_MONO, (int)(11*s), C_DIM);
    { const wchar_t* fl[3] = { L"COVER", L"CONTAIN", L"STRETCH" };
      float fx = X + 92*s;
      for (int i = 0; i < 3; i++) {
          float segW = 88*s, segH = 26*s;
          bool sel = g_fit == i;
          bool hov = ptIn({(LONG)fx,(LONG)y,(LONG)(fx+segW),(LONG)(y+segH)}, g_mx, g_my);
          if (sel) fillRect(fx, y, segW, segH, C_LED, 0.92f);
          else { if (hov) fillRect(fx, y, segW, segH, C_WHITE, 0.07f);
                 borderRect(fx, y, segW, segH, C_SEAM, 0.9f); }
          drawText(fx + (segW - textW(fl[i], F_MONO, (int)(11*s)))/2, y + 7*s, fl[i],
                   F_MONO, (int)(11*s), sel ? C_FACE : C_DIM);
          pushHit(fx, y, segW, segH, HT_S_FIT, i);
          fx += segW + 6*s;
      } }
    y += 34 * s;
    drawText(X, y + 1*s, L"SOFTNESS", F_MONO, (int)(11*s), C_DIM);
    { float tx = X + 92*s, tw2 = 130*s, th = 3*s;
      float frac = g_soft / 30.0f;
      fillRect(tx, y + 5*s, tw2, th, C_SEAM, 1);
      fillRect(tx, y + 5*s, tw2 * frac, th, C_LED, 1);
      circleDot(tx + tw2 * frac, y + 5*s + th/2, 5*s, C_LED, 1);
      pushHit(tx - 6*s, y - 4*s, tw2 + 12*s, 20*s, HT_S_SOFT);
      drawText(tx + tw2 + 16*s, y, wfmt(L"%.1f px", g_soft / 10.0f), F_MONO, (int)(11*s), C_TEXT); }
    y += 36 * s;
    drawText(X, y + 1*s, L"MS UPDATE", F_MONO, (int)(11*s), C_DIM);
    { float tx = X + 92*s, tw2 = 130*s, th = 3*s;      // readout refresh (Build 9)
      float frac = g_msUpd / 30.0f;
      fillRect(tx, y + 5*s, tw2, th, C_SEAM, 1);
      fillRect(tx, y + 5*s, tw2 * frac, th, C_LED, 1);
      circleDot(tx + tw2 * frac, y + 5*s + th/2, 5*s, C_LED, 1);
      pushHit(tx - 6*s, y - 4*s, tw2 + 12*s, 20*s, HT_S_MSUP);
      drawText(tx + tw2 + 16*s, y, wfmt(L"%.1f s", g_msUpd / 10.0f), F_MONO, (int)(11*s), C_TEXT); }
    y += 36 * s;
    drawText(X, y + 7*s, L"ROTATION", F_MONO, (int)(11*s), C_DIM);       // Build 10
    { const wchar_t* rl[2] = { L"OFF", L"ON" };
      float fx = X + 92*s;
      for (int i = 0; i < 2; i++) {
          float segW = 88*s, segH = 26*s;
          bool sel = g_rotOn == i;
          bool hov = ptIn({(LONG)fx,(LONG)y,(LONG)(fx+segW),(LONG)(y+segH)}, g_mx, g_my);
          if (sel) fillRect(fx, y, segW, segH, C_LED, 0.92f);
          else { if (hov) fillRect(fx, y, segW, segH, C_WHITE, 0.07f);
                 borderRect(fx, y, segW, segH, C_SEAM, 0.9f); }
          drawText(fx + (segW - textW(rl[i], F_MONO, (int)(11*s)))/2, y + 7*s, rl[i],
                   F_MONO, (int)(11*s), sel ? C_FACE : C_DIM);
          pushHit(fx, y, segW, segH, HT_S_ROT, i);
          fx += segW + 6*s;
      } }
    y += 34 * s;
    drawText(X, y + 1*s, L"ROTATE EVERY", F_MONO, (int)(11*s), C_DIM);   // Build 10
    { float tx = X + 92*s, tw2 = 130*s, th = 3*s;
      float ta = g_rotOn ? 1.0f : 0.45f;               // dims while rotation is off
      float frac = (g_rotSec - 3) / 57.0f;
      fillRect(tx, y + 5*s, tw2, th, C_SEAM, ta);
      fillRect(tx, y + 5*s, tw2 * frac, th, C_LED, ta);
      circleDot(tx + tw2 * frac, y + 5*s + th/2, 5*s, C_LED, ta);
      pushHit(tx - 6*s, y - 4*s, tw2 + 12*s, 20*s, HT_S_ROTS);
      drawText(tx + tw2 + 16*s, y, wfmt(L"%d s", g_rotSec.load()), F_MONO, (int)(11*s), C_TEXT, ta); }
    y += 38 * s;

    drawText(X, y, L"CAMERAS", F_MONO, (int)(11*s), C_DIM);
    { std::wstring cnt = wfmt(L"%d / 9", (int)rows.size());
      drawText(X + W - textW(cnt, F_MONO, (int)(11*s)), y, cnt, F_MONO, (int)(11*s), C_DIM); }
    y += 26 * s;
    g_rowY0 = y; g_rowH = rowH; g_rowsN = (int)rows.size();
    for (size_t i = 0; i < rows.size(); i++) {
        Row& R = rows[i]; float ry = y + i * rowH;
        if (ry + rowH < panY || ry > panY + panH) continue;
        bool dragged = g_drag.kind == DR_ROW && g_drag.cam == R.id;
        float ra = dragged ? 0.35f : 1.0f;
        drawTextC(X + 8*s, ry + rowH / 2, L"\u2630", F_SYM, (int)(11*s), C_DIM, 0.75f * ra);
        pushHit(X, ry, 20*s, rowH, HT_S_GRIP, (int)i);
        float cbx = X + 26*s, cby = ry + (rowH - 15*s)/2;
        if (R.on) {
            fillRect(cbx, cby, 15*s, 15*s, C_LED, 0.92f * ra);
            drawTextC(cbx + 7.5f*s, cby + 7.5f*s, L"\u2713", F_MONO, (int)(11*s), C_FACE, ra);
        } else borderRect(cbx, cby, 15*s, 15*s, C_SEAM, 0.9f * ra);
        pushHit(cbx - 4*s, cby - 4*s, 23*s, 23*s, HT_S_CHK, R.id);
        { float rbx = X + 52*s;                          // Build 10: ⟳ pool checkbox
          if (R.rot) {
              fillRect(rbx, cby, 15*s, 15*s, C_LED, 0.92f * ra);
              drawTextC(rbx + 7.5f*s, cby + 7.5f*s, GL_ROT, F_MONO, (int)(11*s), C_FACE, ra);
          } else {
              borderRect(rbx, cby, 15*s, 15*s, C_SEAM, 0.9f * ra);
              drawTextC(rbx + 7.5f*s, cby + 7.5f*s, GL_ROT, F_MONO, (int)(10*s), C_SEAM, 0.8f * ra);
          }
          pushHit(rbx - 4*s, cby - 4*s, 23*s, 23*s, HT_S_RCHK, R.id); }
        { std::wstring nm = R.name;
          while (!nm.empty() && textW(nm, F_MONO, (int)(13*s)) > W - 260*s) nm.pop_back();
          drawText(X + 78*s, ry + (rowH - 15*s)/2, nm, F_MONO, (int)(13*s),
                   R.on ? C_TEXT : C_DIM, ra); }
        pushHit(X + 74*s, ry, W - 284*s, rowH, HT_S_GRIP, (int)i);   // name drags too
        float qh = 20*s, qy = ry + (rowH - qh)/2;
        float hx = X + W - 132*s;
        for (int q = 0; q < 2; q++) {
            const wchar_t* qt = q ? L"SD" : L"HD";
            float qw = 28*s;
            bool sel = (R.sd == (q == 1));
            if (sel) fillRect(hx, qy, qw, qh, C_LED, 0.92f * ra);
            else borderRect(hx, qy, qw, qh, C_SEAM, 0.9f * ra);
            drawText(hx + (qw - textW(qt, F_MONO, (int)(10*s)))/2, qy + 4*s, qt,
                     F_MONO, (int)(10*s), sel ? C_FACE : C_DIM, ra);
            pushHit(hx, qy, qw, qh, HT_S_HD, R.id * 2 + q);
            hx += qw + 5*s;
        }
        float ex = X + W - 58*s, ey = ry + (rowH - 24*s)/2;
        bool hovE = ptIn({(LONG)ex,(LONG)ey,(LONG)(ex+24*s),(LONG)(ey+24*s)}, g_mx, g_my);
        if (hovE) fillRect(ex, ey, 24*s, 24*s, C_WHITE, 0.09f);
        borderRect(ex, ey, 24*s, 24*s, C_SEAM, 0.9f * ra);
        drawTextC(ex + 12*s, ey + 12*s, GL_PEN, F_SYM, (int)(12*s), C_TEXT, ra);
        pushHit(ex, ey, 24*s, 24*s, HT_S_EDIT, R.id);
        float dx = X + W - 28*s;
        bool armed = g_sureCam == R.id && nowMs() - g_sureT0 < (uint64_t)SURE_MS;
        if (armed) {
            float sw2 = textW(L"SURE?", F_MONO, (int)(11*s)) + 14*s;
            float sx = X + W - sw2;
            fillRect(sx, ey, sw2, 24*s, C_RED, 0.20f);
            borderRect(sx, ey, sw2, 24*s, C_RED, 0.9f);
            drawText(sx + 7*s, ey + 6*s, L"SURE?", F_MONO, (int)(11*s), C_RED);
            pushHit(sx, ey - 3*s, sw2, 30*s, HT_S_DEL, R.id);
        } else {
            bool hovD = ptIn({(LONG)dx,(LONG)ey,(LONG)(dx+24*s),(LONG)(ey+24*s)}, g_mx, g_my);
            if (hovD) fillRect(dx, ey, 24*s, 24*s, C_WHITE, 0.09f);
            borderRect(dx, ey, 24*s, 24*s, C_SEAM, 0.9f * ra);
            drawTextC(dx + 12*s, ey + 12*s, GL_X, F_SYM, (int)(12*s), C_TEXT, ra);
            pushHit(dx, ey, 24*s, 24*s, HT_S_DEL, R.id);
        }
    }
    y += rows.size() * rowH;
    if (g_drag.kind == DR_ROW && g_rowInsert >= 0 &&
        g_rowInsert != (int)g_drag.f0 && g_rowInsert != (int)g_drag.f0 + 1) {
        float ly = g_rowY0 + g_rowInsert * rowH;
        fillRect(X, ly - 1, W, 2*s, C_LED, 0.95f);
    }
    y += 14 * s;
    { float bh = 28*s;
      std::wstring at = L"+ ADD CAMERA";
      float aw = textW(at, F_MONO, (int)(11*s)) + 24*s;
      bool hovA = ptIn({(LONG)X,(LONG)y,(LONG)(X+aw),(LONG)(y+bh)}, g_mx, g_my);
      fillRect(X, y, aw, bh, C_LED, hovA ? 1.0f : 0.92f);
      drawText(X + 12*s, y + 7*s, at, F_MONO, (int)(11*s), C_FACE);
      pushHit(X, y, aw, bh, HT_S_ADD);
      std::wstring ht2 = L"CLEAR ADDRESS HISTORY";
      float hw = textW(ht2, F_MONO, (int)(11*s)) + 24*s;
      float hx2 = X + W - hw;
      bool hovH = ptIn({(LONG)hx2,(LONG)y,(LONG)(hx2+hw),(LONG)(y+bh)}, g_mx, g_my);
      if (hovH) fillRect(hx2, y, hw, bh, C_WHITE, 0.08f);
      borderRect(hx2, y, hw, bh, C_SEAM, 0.95f);
      drawText(hx2 + 12*s, y + 7*s, ht2, F_MONO, (int)(11*s), C_TEXT);
      pushHit(hx2, y, hw, bh, HT_S_CLR);
      std::wstring rt = L"RESET WALL";
      float rw2 = textW(rt, F_MONO, (int)(11*s)) + 24*s;
      float rx = hx2 - 14*s - rw2;
      bool hovR = ptIn({(LONG)rx,(LONG)y,(LONG)(rx+rw2),(LONG)(y+bh)}, g_mx, g_my);
      if (hovR) fillRect(rx, y, rw2, bh, C_WHITE, 0.08f);
      borderRect(rx, y, rw2, bh, C_SEAM, 0.95f);
      drawText(rx + 12*s, y + 7*s, rt, F_MONO, (int)(11*s), C_TEXT);
      pushHit(rx, y, rw2, bh, HT_S_RESETW); }
    popScissor();
    if (g_scrollMax > 0) {
        float trY = panY + 6*s, trH = panH - 12*s;
        float bh = std::max(24.0f * s, trH * trH / (trH + g_scrollMax));
        float by = trY + (trH - bh) * (g_scroll / g_scrollMax);
        fillRect(panX + panW - 7*s, trY, 3*s, trH, C_SEAM, 0.35f);
        fillRect(panX + panW - 7*s, by, 3*s, bh, C_LED, 0.55f);
        pushHit(panX + panW - 12*s, trY, 12*s, trH, HT_S_BAR);
    }
    g_uiA = 1;
}

// ------------------------------------------------------------ editor draw ---
static void drawEditor() {
    float s = g_uiS;
    float f = std::min(1.0f, (nowMs() - g_modeT0) / (float)FADE_MS);
    struct P { int id; std::wstring nm; };
    std::vector<P> list; std::vector<std::wstring> histW;
    AcquireSRWLockShared(&g_dataLock);
    for (int id : g_order) if (!g_cams[id]->dead) list.push_back({ id, g_cams[id]->name });
    if (g_editFrom == 0) for (auto& h : g_hist) histW.push_back(toWide(h));
    ReleaseSRWLockShared(&g_dataLock);

    float W = 344 * s;
    int histShow = (int)std::min<size_t>(5, histW.size());
    float histH = histShow ? (14 + 18 + histShow * 22.0f) * s : 0;
    float errH = g_editErr.empty() ? 0 : 22 * s;
    float H = (12 + 16 + 26 + 10 + 14 + 26 + 10 + 14 + 26 + 10 + 14 + 26) * s
            + errH + (16 + 28 + 14) * s + histH;
    float X, Y;
    if (g_editFrom == 1) {      // pen: lower-right of ITS OWN pane (Build 6)
        RECT pr = { 0, 0, g_cw, g_ch };
        for (auto& p : g_panes) if (p.cam == g_editAnchor) pr = p.r;
        X = pr.right - W - 10 * s;                   // beside the ✎ button,
        Y = pr.bottom - H - 44 * s;                  // just above the strip
        X = std::max((float)pr.left + 6 * s, X);
        Y = std::max((float)pr.top + 6 * s, Y);
        X = std::max(6.0f * s, std::min(X, g_cw - W - 6 * s));
        Y = std::max(6.0f * s, std::min(Y, g_ch - H - 6 * s));
    } else {                                     // sheet-opened: centred over dim
        fillRect(0, 0, (float)g_cw, (float)g_ch, C_BLACK, 0.72f * f);
        X = (g_cw - W) / 2; Y = (g_ch - H) / 2;
    }
    Y += (1 - f) * 8 * s;                        // fade-and-rise (~120 ms)
    g_uiA = f;
    fillRect(X, Y, W, H, C_PANEL, 0.97f);
    borderRect(X, Y, W, H, C_SEAM, 1);
    pushHit(X, Y, W, H, HT_E_PANEL);
    float x = X + 14*s, w = W - 28*s, y = Y + 12*s;
    drawText(x, y, L"CAMERA", F_COND, (int)(12*s), C_DIM);
    y += 16 * s;
    float pickY = y;
    fillRect(x, y, w, 26*s, C_FACE, 0.96f);
    borderRect(x, y, w, 26*s, g_pickOpen ? C_LED : C_SEAM, 0.9f);
    { std::wstring pt = L"";
      if (g_pickSel == -2) pt = L"+ NEW ADDRESS";
      else for (auto& p : list) if (p.id == g_pickSel) pt = p.nm;
      drawText(x + 8*s, y + 6*s, pt, F_COND, (int)(13*s), C_TEXT);
      drawText(x + w - 16*s, y + 6*s, GL_DROP, F_SYM, (int)(12*s), C_DIM); }
    pushHit(x, y, w, 26*s, HT_E_PICK);
    y += 26*s + 10*s;
    drawText(x, y, L"NAME", F_COND, (int)(12*s), C_DIM);
    y += 14 * s;
    drawField(x, y, w, 26*s, g_fName, HT_E_NAME, g_fldName);
    y += 26*s + 10*s;
    drawText(x, y, L"RTSP ADDRESS", F_COND, (int)(12*s), C_DIM);
    y += 14 * s;
    drawField(x, y, w, 26*s, g_fAddr, HT_E_ADDR, g_fldAddr);
    y += 26*s + 10*s;
    drawText(x, y, L"QUALITY", F_COND, (int)(12*s), C_DIM);
    y += 14 * s;
    { const wchar_t* qs[2] = { L"HD \u00b7 STREAM1", L"SD \u00b7 STREAM2" };
      float segW = (w - 6*s) / 2;
      for (int i = 0; i < 2; i++) {
          float sx = x + i * (segW + 6*s);
          bool sel = (g_editSD == (i == 1));
          if (sel) { fillRect(sx, y, segW, 26*s, C_LED, 0.14f); borderRect(sx, y, segW, 26*s, C_LED, 0.9f); }
          else borderRect(sx, y, segW, 26*s, C_SEAM, 0.9f);
          drawText(sx + (segW - textW(qs[i], F_COND, (int)(12*s)))/2, y + 6*s, qs[i], F_COND, (int)(12*s),
                   sel ? C_LED : C_DIM);
          pushHit(sx, y, segW, 26*s, HT_E_HD, i);
      } }
    y += 26 * s;
    if (!g_editErr.empty()) { drawText(x, y + 6*s, g_editErr, F_MONO, (int)(12*s), C_RED); y += errH; }
    y += 16 * s;
    { float bw = 76*s, bh = 28*s;
      bool hc = ptIn({ (LONG)x, (LONG)y, (LONG)(x + bw), (LONG)(y + bh) }, g_mx, g_my);
      borderRect(x, y, bw, bh, C_SEAM, 0.9f);
      drawText(x + (bw - textW(L"CANCEL", F_COND, (int)(12*s)))/2, y + 7*s, L"CANCEL", F_COND, (int)(12*s),
               hc ? C_TEXT : C_DIM);
      pushHit(x, y, bw, bh, HT_E_CANCEL);
      float ax = x + w - bw;
      bool ha = ptIn({ (LONG)ax, (LONG)y, (LONG)(ax + bw), (LONG)(y + bh) }, g_mx, g_my);
      fillRect(ax, y, bw, bh, C_LED, ha ? 0.22f : 0.15f);
      borderRect(ax, y, bw, bh, C_LED, 0.95f);
      drawText(ax + (bw - textW(L"APPLY", F_CONDB, (int)(12*s)))/2, y + 7*s, L"APPLY", F_CONDB, (int)(12*s), C_LED);
      pushHit(ax, y, bw, bh, HT_E_APPLY);
      y += bh; }
    if (histShow) {
        y += 14 * s;
        drawText(x, y, L"RECENT", F_COND, (int)(12*s), C_DIM);
        y += 18 * s;
        for (int i = 0; i < histShow; i++) {
            std::wstring t = histW[i];
            while (!t.empty() && textW(t, F_MONO, (int)(12*s)) > w) t.pop_back();
            bool hov = ptIn({ (LONG)x, (LONG)y, (LONG)(x + w), (LONG)(y + 20*s) }, g_mx, g_my);
            drawText(x, y, t, F_MONO, (int)(12*s), hov ? C_LED : C_DIM);
            pushHit(x, y - 1*s, w, 22*s, HT_E_HIST, i);
            y += 22 * s;
        }
    }
    if (g_pickOpen) {                            // dropdown last -> topmost hits
        float rh = 24*s, dh = (list.size() + 1) * rh + 2;
        float dy = pickY + 26*s + 2;
        if (dy + dh > g_ch - 8*s) dy = pickY - dh - 2;
        dy = std::max(4.0f * s, dy);
        fillRect(x, dy, w, dh, C_PANEL2, 0.98f);
        borderRect(x, dy, w, dh, C_SEAM, 1);
        float ry = dy + 1;
        for (auto& p : list) {
            bool hov = ptIn({ (LONG)x, (LONG)ry, (LONG)(x + w), (LONG)(ry + rh) }, g_mx, g_my);
            if (hov) fillRect(x + 1, ry, w - 2, rh, C_WHITE, 0.07f);
            drawText(x + 8*s, ry + 4*s, p.nm, F_COND, (int)(13*s), p.id == g_pickSel ? C_LED : C_TEXT);
            pushHit(x, ry, w, rh, HT_E_ROW, p.id);
            ry += rh;
        }
        bool hov = ptIn({ (LONG)x, (LONG)ry, (LONG)(x + w), (LONG)(ry + rh) }, g_mx, g_my);
        if (hov) fillRect(x + 1, ry, w - 2, rh, C_WHITE, 0.07f);
        drawText(x + 8*s, ry + 4*s, L"+ NEW ADDRESS", F_COND, (int)(13*s), C_LED);
        pushHit(x, ry, w, rh, HT_E_ROW, -2);
    }
    g_uiA = 1;
}

// ============================================================================
// SECTION 8 · input, window, WinMain
// ============================================================================

static bool g_resize = false, g_wasMax = false;

// -------------------------------------------- Build 4: monitor fullscreen ---
// Owner law: ⛶ always means window · double-click always means monitor.
// Exiting monitor fullscreen (Esc or double-click) returns to the normal
// window with ALL panes showing. settings.json never stores these bounds.
static void enterMonFS(int cam) {
    if (g_monFS) { g_fsPane = cam; return; }
    g_preFS.length = sizeof(WINDOWPLACEMENT);
    GetWindowPlacement(g_hwnd, &g_preFS);
    g_preStyle = GetWindowLongPtrW(g_hwnd, GWL_STYLE);
    g_preEx    = GetWindowLongPtrW(g_hwnd, GWL_EXSTYLE);
    HMONITOR mon = MonitorFromWindow(g_hwnd, MONITOR_DEFAULTTONEAREST);
    MONITORINFO mi = { sizeof(MONITORINFO) };
    GetMonitorInfoW(mon, &mi);
    SetWindowLongPtrW(g_hwnd, GWL_STYLE, WS_POPUP | WS_VISIBLE);
    SetWindowPos(g_hwnd, HWND_TOP, mi.rcMonitor.left, mi.rcMonitor.top,
                 mi.rcMonitor.right - mi.rcMonitor.left,
                 mi.rcMonitor.bottom - mi.rcMonitor.top, SWP_FRAMECHANGED);
    g_monFS = true; g_fsPane = cam;
    logf("[%s] monitor fullscreen (double-click)", toUtf8(g_cams[cam]->name).c_str());
}
static void exitMonFS(bool toWindowPane) {
    if (!g_monFS) return;
    SetWindowLongPtrW(g_hwnd, GWL_STYLE, g_preStyle);
    SetWindowLongPtrW(g_hwnd, GWL_EXSTYLE, g_preEx);
    SetWindowPlacement(g_hwnd, &g_preFS);
    SetWindowPos(g_hwnd, 0, 0, 0, 0, 0,
                 SWP_NOMOVE | SWP_NOSIZE | SWP_NOZORDER | SWP_FRAMECHANGED);
    g_monFS = false;
    if (!toWindowPane) g_fsPane = -1;                 // default: whole wall back
    logf("monitor fullscreen exit%s", toWindowPane ? " \u00b7 window pane" : "");
}

// ----------------------------------------------------------------- render ---
static uint64_t g_lastT = 0;
static void render() {
    uint64_t t = nowMs();
    float dt = (t - g_lastT) / 1000.0f; if (dt > 0.1f) dt = 0.1f;
    g_lastT = t;
    g_ctx->OMSetRenderTargets(1, &g_rtv, nullptr);
    D3D11_VIEWPORT vp = { 0, 0, (float)g_cw, (float)g_ch, 0, 1 };
    g_ctx->RSSetViewports(1, &vp);
    float bf[4] = { 0,0,0,0 };
    g_ctx->OMSetBlendState(g_blend, bf, 0xffffffff);
    g_ctx->RSSetState(g_rast);
    float cc[4] = { 0,0,0,1 };
    g_ctx->ClearRenderTargetView(g_rtv, cc);
    g_hits.clear();
    rotTick();                                  // Build 10: rotation scheduler

    AcquireSRWLockShared(&g_dataLock);
    std::vector<int> vis = computeVis();
    ReleaseSRWLockShared(&g_dataLock);

    int fs = g_fsPane;
    if (fs >= 0 && (g_cams[fs]->dead || !g_cams[fs]->on)) {
        if (g_monFS) exitMonFS(false);
        fs = g_fsPane = -1;
    }
    if (fs >= 0) { g_panes.clear(); g_panes.push_back({ fs, { 0, 0, g_cw, g_ch } }); }
    else layoutWall(vis);

    int hov = -1;
    if (g_mode == M_WALL && g_drag.kind != DR_PANE && g_inWin)
        for (auto& p : g_panes) if (ptIn(p.r, g_mx, g_my)) hov = p.cam;
    for (auto& p : g_panes) {
        float& a = g_stripA[p.cam];
        a += ((p.cam == hov ? 1.0f : 0.0f) - a) * std::min(1.0f, dt * 9.0f);
    }
    g_gearA += (((g_mode == M_WALL && g_inWin) ? 1.0f : 0.0f) - g_gearA) * std::min(1.0f, dt * 9.0f);

    if (g_panes.empty()) drawEmptyWall();
    else for (auto& p : g_panes) drawPane(g_cams[p.cam], p.r, fs >= 0 || g_monFS);
    drawDragGhost();
    drawGear();
    if (g_mode == M_SHEET) drawSheet();
    else if (g_mode == M_EDIT) drawEditor();
    drawToast();
    g_swap->Present(1, 0);
}

// ------------------------------------------------------------------ input ---
static int camAtRow(int pos) {
    int r = -1, i = 0;
    AcquireSRWLockShared(&g_dataLock);
    for (int id : g_order) { if (g_cams[id]->dead) continue; if (i == pos) { r = id; break; } i++; }
    ReleaseSRWLockShared(&g_dataLock);
    return r;
}
static void volFromX(int cam, const RECT& r, int mx) {
    float pad = 6 * g_uiS;
    float f = (mx - (r.left + pad)) / std::max(1.0f, (r.right - pad) - (r.left + pad));
    f = std::max(0.0f, std::min(1.0f, f));
    Cam* c = g_cams[cam];
    c->vol = f < 0.02f ? 0.0f : f;
    if (c->vol > 0) c->volPre = c->vol;
    vpopShow(cam, c->vol);
}
static void onMouseMove(int mx, int my) {
    switch (g_drag.kind) {
    case DR_VOL:  volFromX(g_drag.cam, g_drag.r, mx); break;
    case DR_SOFT: {
        float pad = 6 * g_uiS;
        float f = (mx - (g_drag.r.left + pad)) / std::max(1.0f, (g_drag.r.right - pad) - (g_drag.r.left + pad));
        g_soft = (int)lroundf(std::max(0.0f, std::min(1.0f, f)) * 30);
        break; }
    case DR_MSUP: {
        float pad = 6 * g_uiS;
        float f = (mx - (g_drag.r.left + pad)) / std::max(1.0f, (g_drag.r.right - pad) - (g_drag.r.left + pad));
        g_msUpd = (int)lroundf(std::max(0.0f, std::min(1.0f, f)) * 30);
        break; }
    case DR_ROTS: {
        float pad = 6 * g_uiS;
        float f = (mx - (g_drag.r.left + pad)) / std::max(1.0f, (g_drag.r.right - pad) - (g_drag.r.left + pad));
        g_rotSec = 3 + (int)lroundf(std::max(0.0f, std::min(1.0f, f)) * 57);
        break; }
    case DR_BAR:
        if (g_scrollMax > 0)
            g_scroll = g_drag.f0 + (my - g_drag.p0.y) * (g_scrollMax / std::max(40.0f, g_sheetH - 60 * g_uiS));
        break;
    case DR_MAYBE:
        if (abs(mx - g_drag.p0.x) > 6 || abs(my - g_drag.p0.y) > 6) g_drag.kind = DR_PANE;
        break;
    case DR_PANE:
        g_drag.target = -1;
        for (auto& p : g_panes) if (ptIn(p.r, mx, my)) g_drag.target = p.cam;
        break;
    case DR_ROW: {
        int ins = (int)floorf((my - g_rowY0) / std::max(1.0f, g_rowH) + 0.5f);
        g_rowInsert = std::max(0, std::min(g_rowsN, ins));
        break; }
    case DR_TEXT: {
        Field& f = g_drag.cam == 1 ? g_fName : g_fAddr;
        RECT&  r = g_drag.cam == 1 ? g_fldName : g_fldAddr;
        f.caret = fieldPosFromX(f, r, mx);
        break; }
    }
}
static void onLButtonDown(int mx, int my) {
    const Hit* h = hitAt(mx, my);
    uint64_t t = nowMs();
    if (g_mode == M_EDIT) {
        if (!h || h->id < HT_E_PANEL) { closeEditor(true); return; }   // outside-click
        int a = h->a, id = h->id;
        switch (id) {
        case HT_E_PICK:  g_pickOpen = !g_pickOpen; g_focus = 0; break;
        case HT_E_ROW:   g_pickOpen = false; loadEditorFrom(a); break;
        case HT_E_NAME: {
            g_focus = 1; g_pickOpen = false;
            int p = fieldPosFromX(g_fName, g_fldName, mx);
            g_fName.caret = p; g_fName.sel = p;
            g_drag.kind = DR_TEXT; g_drag.cam = 1; break; }
        case HT_E_ADDR: {
            g_focus = 2; g_pickOpen = false;
            int p = fieldPosFromX(g_fAddr, g_fldAddr, mx);
            g_fAddr.caret = p; g_fAddr.sel = p;
            g_drag.kind = DR_TEXT; g_drag.cam = 2; break; }
        case HT_E_HD:    g_editSD = (a == 1); break;
        case HT_E_APPLY: applyEditor(); break;
        case HT_E_CANCEL: closeEditor(true); break;
        case HT_E_HIST: {
            AcquireSRWLockShared(&g_dataLock);
            if (a >= 0 && a < (int)g_hist.size()) {
                g_fAddr = Field(); g_fAddr.t = toWide(g_hist[a]);
                g_fAddr.caret = (int)g_fAddr.t.size();
            }
            ReleaseSRWLockShared(&g_dataLock);
            g_focus = 2; break; }
        default: g_pickOpen = false; g_focus = 0; break;               // panel body
        }
        return;
    }
    if (g_mode == M_SHEET) {
        if (!h) { g_mode = M_WALL; g_modeT0 = t; g_sureCam = -1; return; }  // dim click
        int a = h->a;
        switch (h->id) {
        case HT_S_CHK:    toggleOn(a); break;
        case HT_S_HD:     setQuality(a >> 1, (a & 1) == 1); break;
        case HT_S_EDIT:   openEditor(a, 0); break;
        case HT_S_DEL:
            if (g_sureCam == a && t - g_sureT0 < (uint64_t)SURE_MS) { g_sureCam = -1; deleteCam(a); }
            else { g_sureCam = a; g_sureT0 = t; }                      // two-click SURE?
            break;
        case HT_S_ADD:
            g_mode = M_EDIT; g_editFrom = 0; g_editAnchor = -1;
            g_modeT0 = t; g_pickOpen = false; loadEditorFrom(-2);
            break;
        case HT_S_CLOSE:  g_mode = M_WALL; g_modeT0 = t; g_sureCam = -1; break;
        case HT_S_CLR:    clearHist(); break;
        case HT_S_RESETW: resetWall(); break;
        case HT_S_FIT:
            g_fit = a;
            logf("fit -> %s", a == FIT_CONTAIN ? "contain" : a == FIT_STRETCH ? "stretch" : "cover");
            saveSettings(); break;
        case HT_S_SOFT:   g_drag.kind = DR_SOFT; g_drag.r = h->r; onMouseMove(mx, my); break;
        case HT_S_MSUP:   g_drag.kind = DR_MSUP; g_drag.r = h->r; onMouseMove(mx, my); break;
        case HT_S_ROT:
            if (g_rotOn.load() != a) {
                g_rotOn = a; rotKick();
                logf("rotation -> %s", a ? "on" : "off");
                toast(a ? wfmt(L"rotation on \u00b7 every %d s", g_rotSec.load())
                        : L"rotation off");
                saveSettings();
            }
            break;
        case HT_S_ROTS:   g_drag.kind = DR_ROTS; g_drag.r = h->r; onMouseMove(mx, my); break;
        case HT_S_RCHK:   toggleRot(a); break;
        case HT_S_BAR:    g_drag.kind = DR_BAR; g_drag.p0 = { mx, my }; g_drag.f0 = g_scroll; break;
        case HT_S_MAIL:   copyEmail(); break;
        case HT_S_GRIP:
            g_drag.kind = DR_ROW; g_drag.f0 = (float)a; g_drag.cam = camAtRow(a);
            g_rowInsert = a; break;
        default: g_sureCam = -1; break;                                // panel body
        }
        return;
    }
    if (!h) return;                                                    // WALL mode
    int a = h->a;
    switch (h->id) {
    case HT_GEAR:
        g_mode = M_SHEET; g_modeT0 = t; g_scroll = 0; g_sureCam = -1;
        logf("settings sheet opened"); break;
    case HT_VOL:  g_drag.kind = DR_VOL; g_drag.cam = a; g_drag.r = h->r; volFromX(a, h->r, mx); break;
    case HT_MUTE: {
        Cam* c = g_cams[a]; float v = c->vol;
        if (v > 0.004f) { c->volPre = v; c->vol = 0; }
        else c->vol = c->volPre > 0.05f ? c->volPre : 0.6f;
        vpopShow(a, c->vol); break; }
    case HT_RST:  g_cams[a]->reconn = true; break;
    case HT_FS:
        if (g_monFS) { exitMonFS(true); break; }        // ⛶ always means window
        g_fsPane = (g_fsPane == a) ? -1 : a; break;
    case HT_PEN:  openEditor(a, 1); break;
    case HT_ROTLK: toggleRot(a); break;
    case HT_CLOSE: toggleOn(a); break;
    case HT_PANE:
        if (g_fsPane < 0 && g_panes.size() > 1) {
            g_drag.kind = DR_MAYBE; g_drag.cam = a; g_drag.p0 = { mx, my }; g_drag.target = -1;
        }
        break;
    }
}
static void onLButtonUp() {
    if (g_drag.kind == DR_SOFT || g_drag.kind == DR_MSUP) saveSettings();
    if (g_drag.kind == DR_ROTS) { rotKick(); saveSettings(); }   // fresh clock at the new pace
    if (g_drag.kind == DR_TEXT) {
        Field& f = g_drag.cam == 1 ? g_fName : g_fAddr;
        if (f.sel == f.caret) f.sel = -1;
    }
    if (g_drag.kind == DR_PANE && g_drag.target >= 0 && g_drag.target != g_drag.cam)
        swapPanesDrag(g_drag.cam, g_drag.target);
    if (g_drag.kind == DR_ROW && g_rowInsert >= 0) {
        int from = (int)g_drag.f0;
        if (g_rowInsert != from && g_rowInsert != from + 1) moveRow(from, g_rowInsert);
    }
    g_drag.kind = DR_NONE; g_drag.target = -1; g_rowInsert = -1;
}
static void onDblClick(int mx, int my) {
    const Hit* h = hitAt(mx, my);
    if (g_mode != M_WALL) { onLButtonDown(mx, my); return; }
    if (h && h->id == HT_PANE) {
        g_drag.kind = DR_NONE;
        if (g_monFS) exitMonFS(false);                  // back to the whole wall
        else enterMonFS(h->a);                          // Build 4 monitor fullscreen
        return;
    }
    if (h) onLButtonDown(mx, my);                       // dblclick on a button = click
}
static void onWheel(int delta, int mx, int my) {
    if (g_mode == M_SHEET) { g_scroll -= delta / 120.0f * 40 * g_uiS; return; }
    if (g_mode == M_EDIT) return;
    for (auto& p : g_panes)
        if (ptIn(p.r, mx, my)) {
            Cam* c = g_cams[p.cam];
            float v = c->vol + (delta > 0 ? 0.1f : -0.1f);
            v = std::max(0.0f, std::min(1.0f, v));
            if (v < 0.02f) v = 0;
            c->vol = v; if (v > 0) c->volPre = v;
            vpopShow(p.cam, v);
            return;
        }
}
static void onKeyDown(WPARAM vk) {
    bool ctrl = GetKeyState(VK_CONTROL) < 0;
    if (g_mode == M_EDIT) {
        if (vk == VK_ESCAPE) { if (g_pickOpen) g_pickOpen = false; else closeEditor(true); return; }
        if (vk == VK_RETURN) { applyEditor(); return; }
        if (vk == VK_TAB)    { g_focus = g_focus == 1 ? 2 : 1; return; }
        if (ctrl && (vk == 'A' || vk == 'C' || vk == 'X' || vk == 'V')) {
            Field* f = g_focus == 1 ? &g_fName : g_focus == 2 ? &g_fAddr : nullptr;
            int cap = g_focus == 1 ? NAME_MAX : 300;
            if (f) {
                if (vk == 'A')      { f->sel = 0; f->caret = (int)f->t.size(); }
                else if (vk == 'C') fieldCopy(*f);
                else if (vk == 'X') { fieldCopy(*f); selErase(*f); }
                else                fieldPaste(*f, cap);
            }
            return;
        }
        if (g_focus == 1) fieldKey(g_fName, vk);
        else if (g_focus == 2) fieldKey(g_fAddr, vk);
        return;
    }
    if (vk == VK_ESCAPE) {                              // the Esc law (Build 4)
        if (g_mode == M_SHEET) { g_mode = M_WALL; g_modeT0 = nowMs(); return; }
        if (g_monFS)   { exitMonFS(false); return; }    // monitor FS -> whole wall
        if (g_fsPane >= 0) { g_fsPane = -1; return; }   // window pane -> wall
        PostMessageW(g_hwnd, WM_CLOSE, 0, 0);           // wall -> quit (locked §12)
        return;
    }
    if (g_mode != M_WALL) return;
    if (vk == 'R') restoreAll();
    else if (vk == 'D') g_diag = !g_diag;
}
static void onChar(wchar_t wc) {
    if (g_mode != M_EDIT || wc == 9 || wc == 13 || wc == 27) return;
    if (GetKeyState(VK_CONTROL) < 0) return;
    if (g_focus == 1) fieldChar(g_fName, wc, NAME_MAX);
    else if (g_focus == 2) fieldChar(g_fAddr, wc, 300);
}
static void snapPlacement() {
    if (g_monFS) return;                                // Build 4: never store FS
    WINDOWPLACEMENT wp = { sizeof(WINDOWPLACEMENT) };
    if (!GetWindowPlacement(g_hwnd, &wp)) return;
    g_win.show = wp.showCmd == SW_SHOWMAXIMIZED ? 3 : 1;
    g_win.x = wp.rcNormalPosition.left;
    g_win.y = wp.rcNormalPosition.top;
    g_win.w = wp.rcNormalPosition.right - wp.rcNormalPosition.left;
    g_win.h = wp.rcNormalPosition.bottom - wp.rcNormalPosition.top;
    g_win.have = true;
}
static LRESULT CALLBACK wndProc(HWND h, UINT m, WPARAM w, LPARAM l) {
    switch (m) {
    case WM_MOUSEMOVE:
        g_mx = GET_X_LPARAM(l); g_my = GET_Y_LPARAM(l);
        if (!g_inWin) {
            g_inWin = true;
            TRACKMOUSEEVENT tm = { sizeof(TRACKMOUSEEVENT), TME_LEAVE, h, 0 };
            TrackMouseEvent(&tm);
        }
        onMouseMove(g_mx, g_my);
        return 0;
    case WM_MOUSELEAVE: g_inWin = false; g_mx = g_my = -1000; return 0;
    case WM_LBUTTONDOWN: SetCapture(h); onLButtonDown(GET_X_LPARAM(l), GET_Y_LPARAM(l)); return 0;
    case WM_LBUTTONUP:   ReleaseCapture(); onLButtonUp(); return 0;
    case WM_LBUTTONDBLCLK: onDblClick(GET_X_LPARAM(l), GET_Y_LPARAM(l)); return 0;
    case WM_MOUSEWHEEL: {
        POINT p = { GET_X_LPARAM(l), GET_Y_LPARAM(l) };
        ScreenToClient(h, &p);
        onWheel(GET_WHEEL_DELTA_WPARAM(w), p.x, p.y);
        return 0; }
    case WM_KEYDOWN: onKeyDown(w); return 0;
    case WM_CHAR:    onChar((wchar_t)w); return 0;
    case WM_SIZE:
        if (w == SIZE_MINIMIZED) return 0;
        g_cw = std::max(8, (int)LOWORD(l)); g_ch = std::max(8, (int)HIWORD(l));
        g_resize = true;
        if (!g_monFS) {
            snapPlacement();
            bool mx2 = (w == SIZE_MAXIMIZED);
            if (mx2 != g_wasMax) { g_wasMax = mx2; saveSettings(); }
        }
        return 0;
    case WM_EXITSIZEMOVE: snapPlacement(); saveSettings(); return 0;
    case WM_DPICHANGED: {
        g_uiS = HIWORD(w) / 96.0f;
        RECT* r = (RECT*)l;
        SetWindowPos(h, 0, r->left, r->top, r->right - r->left, r->bottom - r->top,
                     SWP_NOZORDER | SWP_NOACTIVATE);
        logf("dpi scale %.2f \u00b7 client %dx%d", g_uiS, g_cw, g_ch);
        return 0; }
    case WM_ERASEBKGND: return 1;
    case WM_CLOSE: DestroyWindow(h); return 0;
    case WM_DESTROY: PostQuitMessage(0); return 0;
    }
    return DefWindowProcW(h, m, w, l);
}

// ----------------------------------------------------------------- WinMain --
int WINAPI WinMain(HINSTANCE hi, HINSTANCE, LPSTR, int) {
    QueryPerformanceFrequency(&g_qpcF); QueryPerformanceCounter(&g_qpc0);
    InitializeCriticalSection(&g_logCs);
    CreateMutexW(0, TRUE, kMutexName);                 // single instance (§23.4)
    if (GetLastError() == ERROR_ALREADY_EXISTS) {
        HWND w = FindWindowW(kWndClass, nullptr);
        if (w) { if (IsIconic(w)) ShowWindow(w, SW_RESTORE); SetForegroundWindow(w); }
        return 0;
    }
    openLog();
    logf("TAPO/RTSP CCTV Streamer \u2014 Native M3 \u00b7 Build 10 \u00b7 pid %lu",
         (unsigned long)GetCurrentProcessId());
    HMODULE u32 = LoadLibraryW(L"user32.dll");
    typedef BOOL (WINAPI *SPDAC)(HANDLE);
    SPDAC sp = u32 ? (SPDAC)GetProcAddress(u32, "SetProcessDpiAwarenessContext") : nullptr;
    if (sp) { sp((HANDLE)-4 /* PER_MONITOR_AWARE_V2 */); logf("SetProcessDpiAwarenessContext"); }

    av_log_set_callback(ffLogCb);
    logf("ffmpeg: %s", av_version_info());
    avformat_network_init();

    loadSettings();
    if (g_cams.empty()) seedWall();
    sanitizeOrder();
    { int slot = 0;
      for (int id : g_order) {
          Cam* c = g_cams[id];
          logf("camera: %s | %s%s", toUtf8(c->name).c_str(), c->url.c_str(), c->sd ? " \u00b7 sd" : "");
          c->stag = c->on ? slot++ : 0;
      } }

    WNDCLASSW wc = {};
    wc.style = CS_DBLCLKS;
    wc.lpfnWndProc = wndProc;
    wc.hInstance = hi;
    wc.hCursor = LoadCursorW(0, MAKEINTRESOURCEW(32512));
    wc.hIcon = LoadIconW(hi, MAKEINTRESOURCEW(1));
    wc.hbrBackground = (HBRUSH)GetStockObject(BLACK_BRUSH);
    wc.lpszClassName = kWndClass;
    RegisterClassW(&wc);

    int X = CW_USEDEFAULT, Yp = CW_USEDEFAULT, Wd = 1280, Ht = 720;
    if (g_win.have) {
        RECT r = { g_win.x, g_win.y, g_win.x + g_win.w, g_win.y + g_win.h };
        if (MonitorFromRect(&r, MONITOR_DEFAULTTONULL)) { X = g_win.x; Yp = g_win.y; Wd = g_win.w; Ht = g_win.h; }
        else { logf("settings: saved window is off-screen \u00b7 ignoring placement"); g_win.have = false; }
    }
    g_hwnd = CreateWindowExW(0, kWndClass, kTitle, WS_OVERLAPPEDWINDOW,
                             X, Yp, Wd, Ht, 0, 0, hi, 0);
    if (!g_hwnd) { logf("CreateWindow failed"); return 1; }
    SendMessageW(g_hwnd, WM_SETICON, ICON_BIG,   (LPARAM)wc.hIcon);
    SendMessageW(g_hwnd, WM_SETICON, ICON_SMALL, (LPARAM)wc.hIcon);
    HMODULE dwm = LoadLibraryW(L"dwmapi.dll");
    if (dwm) {
        typedef HRESULT (WINAPI *DSWA)(HWND, DWORD, LPCVOID, DWORD);
        DSWA ds = (DSWA)GetProcAddress(dwm, "DwmSetWindowAttribute");
        BOOL dark = TRUE;
        if (ds && (SUCCEEDED(ds(g_hwnd, 20, &dark, 4)) || SUCCEEDED(ds(g_hwnd, 19, &dark, 4))))
            logf("dark title bar applied");
    }
    typedef UINT (WINAPI *GDFW)(HWND);
    GDFW gd = u32 ? (GDFW)GetProcAddress(u32, "GetDpiForWindow") : nullptr;
    if (gd) { g_uiS = gd(g_hwnd) / 96.0f; logf("GetDpiForWindow"); }
    ShowWindow(g_hwnd, g_win.have && g_win.show == 3 ? SW_SHOWMAXIMIZED : SW_SHOWNORMAL);
    if (g_win.have) logf("window placement restored (show=%u)", g_win.show);
    RECT cr; GetClientRect(g_hwnd, &cr);
    g_cw = std::max(8L, cr.right); g_ch = std::max(8L, cr.bottom);
    logf("dpi scale %.2f \u00b7 client %dx%d", g_uiS, g_cw, g_ch);

    initD3D();
    HANDLE ath = CreateThread(0, 0, audioThread, 0, 0, 0);
    for (auto c : g_cams) spawnWorker(c);

    g_lastT = nowMs();
    bool run = true;
    while (run) {
        MSG m;
        while (PeekMessageW(&m, 0, 0, 0, PM_REMOVE)) {
            if (m.message == WM_QUIT) { run = false; break; }
            TranslateMessage(&m);
            DispatchMessageW(&m);
        }
        if (!run) break;
        if (IsIconic(g_hwnd)) { Sleep(40); continue; }
        if (g_resize) { g_resize = false; resizeD3D(); }
        render();                                       // Present(1,0) paces 60 Hz
    }

    logf("shutting down");
    saveSettings();
    g_quitAll = true;
    for (auto c : g_cams) c->quit = true;
    uint64_t t0 = nowMs(); bool late = false;
    std::vector<HANDLE> hs;
    for (auto c : g_cams) if (c->th) hs.push_back(c->th);
    if (ath) hs.push_back(ath);
    for (HANDLE hh : hs) {
        uint64_t used = nowMs() - t0;
        DWORD left = used < 1500 ? (DWORD)(1500 - used) : 0;
        if (WaitForSingleObject(hh, left) != WAIT_OBJECT_0) late = true;
    }
    if (late) logf("worker join timeout (continuing shutdown)");
    logf("clean exit");
    if (g_log) fclose(g_log);
    return 0;
}
