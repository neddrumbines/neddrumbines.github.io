# Tapo Camera Wall — Complete Project Documentation

**Status:** ✅ WORKING — build 5.3, confirmed by owner on 31 July 2026 · one-click launcher **CameraWall.exe build 1** adopted 30 July 2026 · silent service scripts (.vbs) added 31 July 2026
**Native track:** 🚧 IN PROGRESS — **M3 Build 10 shipped 29 Aug 2026** as **CCTV-Streamer-M3-Build10.exe** (CAMERA ROTATION: parked cameras cycle through the open panes — all unlocked panes advance together, seamless preroll swaps, per-camera ⟳ pool flag with a strip 🔒 lock, ROTATION toggle + 3–60 s slider, persisted; plus the owner's strip-scrim cut 84→46 px, same opacity). Awaiting owner test. Build 9 shipped 1 Aug 2026 as CCTV-Streamer-M3-Build9.exe. Build 8 owner-approved ("This time you nailed it") — live-delay readout + framed settings both pass. Build 9 adds the owner's two refinements: an **MS UPDATE** slider under SOFTNESS (0.0 s live → 3.0 s hold, default 1.0 s; stall climbs always live; persisted as settings.json `"msup"`) and a **☰ grip** before each camera row's checkbox as the visible drag-to-reorder handle. Awaiting owner look. Build 5 (the corrected rebuild) passed the owner's **full retest — every item**, fullscreen law included; Build 6 is the owner's post-retest polish list, rebuilt against two owner-supplied Build 3 screenshots: strip codec/latency readouts restored, settings sheet returned to the Build 3 layout (version+contact on top, CLOSE button, DISPLAY before CAMERAS, mono styling), 2x-supersampled text everywhere, pen popup anchored to its own pane, full rtsp:// visible, and text selection with Ctrl+A/C/X/V. Awaiting owner test of the polish items. Build 4/5 is a **full from-the-record rebuild** (§24: the Build 1–3 source never left its incognito build sessions; Build 4's `camerawall_m3.cpp` was rewritten from this document plus everything recoverable from the Build 3 exe, and **the source now ships with every build — keep it next to the exe**). Build 3 retest 1 Aug 2026: pane takeover, email clipboard-copy, right-anchored pen popup, RESET WALL, decluttered popup **all owner-approved** ("everything is working to my liking"). Build 4 adds the owner's fullscreen law — **⛶ always means window · double-click always means monitor**: double-click a pane for borderless fullscreen on the current monitor; Esc or double-click again returns to the normal windowed wall with all panes. Because Build 4 is a rebuild, a **full retest is required**, not a spot check. The gear is real: settings sheet (fit cover/contain/stretch · softness blur · full camera management), per-pane editor with a native text widget, drag-to-reorder, HD/SD per camera, settings.json v2 as source of truth, title-bar icon fixed, single-instance guard. M2 Build 2 fully owner-approved. Chrome wall stays the daily driver until parity.
**Environment pins:** go2rtc **v1.9.14** (revision b5948cf), Windows, Chrome app mode, launcher CameraWall.exe **build 1** (Go, source `main.go`), install folder `C:\Users\USER\Downloads\CCTV\` (referred to as `C:\go2rtc\` below)

A local, browser-based multi-camera wall for TP-Link Tapo cameras. Runs entirely on one Windows PC over `127.0.0.1` — no cloud, no port forwarding, invisible to the rest of the LAN. This document is the project's complete memory: what it is, how it works, every bug found along the way and why, and where to take it next.

---

## 1. What This Is — Final Architecture

Browsers cannot play `rtsp://` directly (VLC can because it's a media player, not a browser). So a relay converts:

```
Tapo cameras ──RTSP──▶ go2rtc (relay, 127.0.0.1 only) ──MSE over WebSocket──▶ Chrome app window
                                                       (WebRTC available but
                                                        broken on this PC — see §9)
```

- **go2rtc**: single .exe, no install, no dependencies, no ffmpeg needed (Tapo's PCMA audio passes through WebRTC natively and is auto-repacked to FLAC for MSE — sound works on both transports).
- **The page**: one HTML file, no build step, no libraries. Served by go2rtc itself (`static_dir`), so one process serves both page and streams — no CORS, no second server.
- **Transport**: MSE (fMP4 chunks over WebSocket) — learned automatically because WebRTC's ICE layer is dead on this machine (§9). Latency ~0.5–1.5s. WebRTC (~0.3–0.5s) remains selectable in settings and auto-re-learns if it ever starts working again.
- **Camera credentials** live only in the page's localStorage; `go2rtc.yaml` contains zero camera details. The page registers streams with go2rtc's HTTP API at runtime.

---

## 2. Folder Layout & Install From Scratch

```
C:\go2rtc\
    go2rtc.exe             <- go2rtc GitHub releases, go2rtc_win64.zip (pin: 1.9.14 — see §13 before upgrading)
    go2rtc.yaml            <- relay config (no camera details)
    CameraWall.exe         <- THE launcher (build 1) — the double-click target; desktop shortcut points here
    main.go                <- launcher source (Go) — audit / rebuild, see §14
    cameras.bat            <- legacy launcher, superseded by CameraWall.exe (kept as fallback)
    restart-go2rtc.bat     <- one-click relay restart (kills all camera sessions instantly) — unchanged
    restart-go2rtc-silent.vbs  <- silent twin of the restart bat: no windows at all (see §3)
    stop-background-silent.vbs <- silently stops every hidden piece: go2rtc.exe + CameraWall.exe (see §3)
    go2rtc.log             <- generated: relay log, fresh file each time the launcher starts go2rtc
    wall-window.json       <- generated: remembered window size/position/maximized state (delete to reset)
    wall-window.hwnd       <- generated while the wall is open; auto-removed on close
    chrome-path.txt        <- optional: full path to chrome.exe, only if auto-detect fails
    www\
        wall.html          <- PERMANENT loader stub — never edit, never changes
        app.html           <- THE APP (build 5.1) — the only file that ever gets updated
```

Fresh install: create the folder + `www` subfolder, drop the files in, double-click `CameraWall.exe`. First run only: SmartScreen may warn about an unsigned exe — More info → Run anyway, once. go2rtc starts hidden, Chrome opens in app mode (no tabs/address bar) at `http://127.0.0.1:1984/wall.html`, and the seven cameras are pre-loaded (first three shown by default). Desktop shortcut: right-click `CameraWall.exe` → Send to → Desktop.

**Camera-side prerequisites (done for all 7):** RTSP-capable wired Tapo model; a **Camera Account** created in the Tapo app (Device Settings → Advanced Settings → Camera Account — separate from the TP-Link cloud login); reserved IPs in the router; URL form `rtsp://user:pass@<ip>/stream1` (HD) or `/stream2` (SD), port 554 implied. Always verify a new camera in VLC first.

---

## 3. File-by-File Reference

### wall.html — the loader (permanent, ~30 lines)
Fetches `app.html?ts=<Date.now()>` with `cache:'no-store'` and `document.write`s it. Exists because Chrome HTTP-caches go2rtc's static files and app-mode windows silently ran stale code through **three** debugging rounds (§8). The stub never changes, so caching it is harmless; the app is fetched fresh from disk on every launch, guaranteed. The URL stays `wall.html`, so Chrome's remembered window size/position (keyed per URL) survives updates.

### app.html — the entire application (build 5.1)
UI, connection engine, settings, persistence. Update procedure: replace the file, bump the `const BUILD='x.y'` string near the top, close the camera window fully, relaunch, and confirm the new number in the settings footer (`127.0.0.1:1984 · build x.y`). **The footer build number is ground truth** — any screenshot showing the wrong number means the window predates the file.

### go2rtc.yaml — currently in DEBUG mode (see §11 to quiet it)
```yaml
api:
  listen: "127.0.0.1:1984"
  static_dir: "www"
  origin: "*"
rtsp:
  listen: "127.0.0.1:8554"   # go2rtc defaults this to ALL interfaces; pinned to loopback
webrtc:
  listen: "127.0.0.1:8555"
  candidates:
    - 127.0.0.1:8555
log:                          # debug block — replace with `level: warn` when stable
  format: text
  level: info
  rtsp: debug
  streams: debug
  webrtc: debug
```
go2rtc only reads this at startup — apply changes with `restart-go2rtc.bat`.

### CameraWall.exe — the launcher (build 1, Go — source `main.go`)
One double-click does, in order: **(1)** if a launcher is already tracking an open wall (named mutex `TapoCameraWallLauncher` + `wall-window.hwnd`), just focus that window and exit — **a second wall can never open**; **(2)** if `127.0.0.1:1984` doesn't answer, start `go2rtc.exe` **hidden** (no console) with stdout/stderr → `go2rtc.log`, and wait up to 10s for the API — if the port already answers, **nothing new is started**, so open/close cycles can never stack relay processes; **(3)** open Chrome `--app=http://127.0.0.1:1984/wall.html` with **no** size/position flags (§14 rule); **(4)** identify the new wall window (before/after diff of visible `Chrome_WidgetWin_1` top-levels), restore the last placement from `wall-window.json` — skipped if that spot is now off-screen (unplugged-monitor guard); minimized is never restored — then poll every 1s and re-save on any move/resize, so position survives even a killed launcher. DPI-aware (per-monitor v2), so coordinates mean the same thing at any display scaling.

**Lifecycle (deliberate, owner's choice):** closing the wall (✕) saves the position and exits the launcher; **go2rtc stays running.** Idle go2rtc drops its RTSP connections to the cameras once the last viewer detaches, so between sessions it holds **zero camera sessions**, ~0% CPU, a few tens of MB RAM — and the next open attaches to the warm relay in ~1–3s. The launcher never touches `chrome.exe` by process name, so the daily browser and its tabs are always untouched. Only `restart-go2rtc.bat` (or Task Manager) stops the relay.

### cameras.bat — legacy launcher (superseded)
The old debug launcher: go2rtc in a **visible** console teed to `go2rtc.log` via PowerShell, then `chrome --app=...` with no size flags (the flags were why the window never remembered its size early on — Chrome remembers app-window bounds per URL by itself; the exe now adds its own memory on top). Kept only as a fallback.

### restart-go2rtc.bat
`taskkill /IM go2rtc.exe /F`, wait 2s, relaunch with logging. Killing the process closes every camera session instantly — the guaranteed unwedge, and the correct way to apply yaml changes. The wall reconnects on its own.

### restart-go2rtc-silent.vbs · stop-background-silent.vbs — silent service control (added 31 Jul 2026)
Windowless twins for day-to-day use; the bat above stays as the visible/debug variant. A `.bat` can never run without flashing a console (cmd.exe hosts it), so these are VBScript — Windows Script Host runs them with no window at all.

- **restart-go2rtc-silent.vbs** — hidden `taskkill /IM go2rtc.exe /F`, 2s settle (Tapo slot release, §9 item 3), then relaunch go2rtc hidden with output to a fresh `go2rtc.log`. Safe with the wall open: panes knock "go2rtc not answering" and reconnect unaided.
- **stop-background-silent.vbs** — hidden `taskkill` of `go2rtc.exe` and `CameraWall.exe`. Never touches `chrome.exe` (launcher rule). Best run after closing the wall's ✕; if the wall is still open its panes just sit on "go2rtc not answering" until closed — harmless.

**Process hygiene (verified 31 Jul 2026):** the script process itself (`wscript.exe`) exits the moment its last line runs — ~2s for restart (the settle sleep), <1s for stop. Neither installs anything, schedules anything, or stays resident. After **stop**, Task Manager holds *nothing* from the camera setup. After **restart**, exactly two things remain *on purpose*: `go2rtc.exe` (the point of a restart) and one hidden idle `cmd.exe` (~1–2 MB) hosting it purely as the log pipe (`cmd /c go2rtc.exe > go2rtc.log 2>&1`; visible in Task Manager → Details with the Command line column). That cmd dies automatically the instant go2rtc dies — any later stop/restart clears it. Launcher-started go2rtc has no cmd host (the Go exe redirects handles itself), so a lone hidden cmd next to go2rtc simply means the current relay session came from the silent restart script. First run of a downloaded `.vbs` may need right-click → Properties → Unblock, and the file must actually end in `.vbs` (extension can be lost on download).

---

## 4. Features (Build 5.1)

**The wall.** Black page, video panes, nothing else. 1–3 cameras = one row; 4–6 = two rows of three; up to 12 saved (grid grows in rows of 3). Outlined camera name top-right of each pane (black text-stroke + shadow, survives bright skies). Last-used layout, order, names, quality, and picture settings restore on every open with no prompts.

**Hover strip per pane** (bottom, only on hover): status dot (cyan live / red down) · volume slider 0–100% per camera, all muted by default · live-delay readout in seconds · transport tag (`rtc`/`mse`) · **↻** hard reset · **⛶** fullscreen (double-clicking the video works too; Esc exits) · **✎** in-place editor · **✕** close pane (camera stays in library, Show unticked). Since 5.2 the strip sits on a stronger scrim with shadowed, button-faced controls — readable over bright skies, geometry unchanged — and the **scroll wheel over a pane drives that pane's volume**: 10% per notch, up = louder, clamped 0–100, volume 0 = mute, with a brief % pill top-centre (`.vpop`); Ctrl+wheel (browser zoom) and scrolling over an open ✎ editor are left alone. Until the page's first click Chrome keeps audio locked (§9 item 8): the pill reads "N% · click once for sound", the stream never pauses, and the first click anywhere applies the queued volume on every pane.

**✎ mini editor on the pane:** camera dropdown listing the whole library (name — IP) with **"+ Add new camera…"** at the bottom, plus Name / RTSP address (with history suggestions) / HD-SD. Apply saves to the main settings in the background and reconnects **only that pane** — the diff renderer guarantees untouched cameras never blink, not even one frame.

**Settings (gear, top-right, appears on window hover):** up to 12 rows, each with ⋮⋮ drag-reorder grip (arrow keys work too), Show tick, Name, address (datalist history of every URL ever used), HD/SD (auto-rewrites `/stream1`↔`/stream2`), delete. Plus: + Add camera · Clear address history (URLs contain passwords — that's why it exists) · **Fill the pane** (Crop = default, kills black bars / Stretch / Fit) · **Transport** (Auto = learned, WebRTC, MSE) · **Softness** 0–2.0px live blur for crunchy downscaled panes (real fix is SD on small panes — a 2K stream in a ~500px pane discards 4 of 5 pixels).

**Seeded content:** all 7 cameras pre-loaded with names, and all 7 URLs in the suggestion history. Merge-by-IP on load, so user edits are never overwritten.

---

## 5. Connection Engine Internals

The heart of the project — everything here was forced by a measured failure (§8–9).

**Transport memory.** `store.tpt` = user choice (`auto`/`rtc`/`mse`); `store.tptAuto` = what Auto learned. Auto probes WebRTC once (6s leash), and on failure writes `mse` and never wastes time on WebRTC again — across launches. Any WebRTC success re-learns `rtc`. Within a session, any pane's failure makes its retries use MSE regardless. Changing the Transport setting reconnects all panes immediately (fast, via attach).

**Attach-first.** Before touching anything, a connect asks go2rtc `GET /api/streams?src=<name>` — if the stream already exists with exactly the right single source, the pane just attaches a consumer. Attaching touches the camera **zero** times → zero cooldown → ~1–2s to picture. Only when the stream is absent/wrong, on a hard reset, or after **two consecutive failures** (something genuinely wedged) does it take the reset path: DELETE → settle 500–700ms → PUT.

**Cooldown ledger** (`cool` map, keyed by camera IP) gates only the reset path: 6s after closing a healthy session (`CLEAN_COOL` — Tapo firmware needs it; 1.5s provably wasn't enough), 35s after a stalled *WebRTC* attempt that reset the camera (`ZOMBIE_LIFE` — outlives go2rtc's 30s grip, §9). Pane shows an honest countdown while waiting. A successful connect clears the entry.

**Watchdogs & self-healing:** WebRTC leash 6s, MSE 12s; frozen-feed detection every 2s (WebRTC: byte counter stalls; MSE: `currentTime` stalls); MSE latency chase (jump to live if >2.5s behind) and buffer trim (keep ≤30s). **Retry-forever guarantee:** every failure path re-schedules a connect — camera power loss, go2rtc death (`restart-go2rtc.bat` brings it back; panes reconnect unaided), Wi-Fi blips, router restarts all recover automatically. The only things that stop a pane are deliberate: ✕, unticking Show, closing the window.

**Diff rendering.** `renderWall()` keeps any pane whose camera (id + url + res) is unchanged — its `<video>` element is never recreated, so saves/edits/reorders can't black out the wall (DOM moves preserve playing streams; a defensive `play()` follows).

**Stream naming:** `<cameraId>_<res>`, e.g. `cam1_hd`, `c7j9xp1_hd` (`cam1..3` are legacy ids from early builds; later cameras get random uids). In go2rtc's model the camera is the *producer*, the browser a *consumer* — `[webrtc] new consumer src=X` in the log is one viewing attempt, and only the WebRTC module logs consumers at debug (MSE attaches are visible only as producer starts/stops).

---

## 6. localStorage Schema (`tapo.wall.v4`, origin `http://127.0.0.1:1984`)

```json
{
  "cams": [ { "id":"c7j9xp1", "label":"Indoor", "url":"rtsp://...", "on":true, "res":"hd" } ],
  "fit": "cover",
  "soft": 0,
  "hist": [ "rtsp://..." ],
  "tpt": "auto",
  "tptAuto": "mse"
}
```
`fit`: cover | fill | contain. `soft`: 0–20 → 0.0–2.0 px blur. `hist`: address suggestions, max 30, newest first. `tpt`: auto | rtc | mse (user choice). `tptAuto`: what Auto learned on this PC. Older keys `tapo.wall.v1/v2/v3` migrate automatically on first load. Settings survive app.html updates and even the wall.html rename (localStorage is origin-scoped, not path-scoped).

---

## 7. Camera Inventory

| # | Name | RTSP address | Notes |
|---|---|---|---|
| 1 | Gate | `rtsp://itsnedd:ad45yk0m@192.168.0.153/stream1` | default shown |
| 2 | Balcony | `rtsp://itsnedd:ad45yk0m@192.168.0.150/stream1` | default shown |
| 3 | Back | `rtsp://itsnedd:ad45yk0m@192.168.0.151/stream1` | default shown |
| 4 | K_Back | `rtsp://itsnedd:ad45yk0m@192.168.0.154/stream1` | |
| 5 | K_Side | `rtsp://itsnedd:ad45yk0m@192.168.0.155/stream1` | |
| 6 | Driveway | `rtsp://itsnedd2:ad45yk0m@192.168.0.152/stream1` | ⚠ different username: `itsnedd2` |
| 7 | Indoor | `rtsp://itsnedd:ad45yk0m@192.168.0.140/stream1` | |

⚠ **Plain-text passwords** live in this document and in localStorage — keep both private.

---

## 8. The Debugging Saga — Build History

The path here matters as much as the destination; every mechanism in §5 exists because of a specific failure below.

| Build | What it was | What killed it |
|---|---|---|
| v1 `cams.html` | Multi-device: WebRTC + HLS fallback, LAN-exposed | Scope changed to this-PC-only; rewritten |
| v2 | Localhost 3-cam wall, settings panel, `PUT /api/streams` per connect | **PUT on an existing name ADDS a source instead of replacing** → duplicate sources stacked on every save/refresh → multiple RTSP sessions per camera → Tapo session cap → "No picture"; page reload masked it |
| v3 | DELETE→PUT before every connect, infinite retries, stagger | DELETE races + still churned camera sessions; **and Chrome silently kept running v2 from HTTP cache** — first stale-code incident |
| v4.0 `wall.html` | Renamed file (cache escape), self-version check, diff render, ✎ mini editor, 7 seeded cams, 12-cam cap, drag reorder, history | Log revealed the **30.1s zombie** (below) and retries spaced 16–33s that could never outlive it — a mathematically self-sustaining failure loop |
| v4.1 | Cooldown ledger (6s clean / 35s zombie) with countdown UI | Never actually ran: the sessionStorage guard in the self-check let stale 4.0 keep executing — **second/third stale-code incident** (diagnosed from the screenshot's message wording) |
| v5.0 | **Loader-stub pattern** (permanent wall.html fetches app.html no-store) + **MSE transport fallback** | Worked — but every add/refresh still paid ~34s: a doomed 12s WebRTC attempt + the ~22s zombie cooldown it caused |
| v5.1 | **Transport memory** (learns MSE, skips WebRTC forever), **attach-first** (reuse healthy streams, no cooldown), 6s WebRTC leash, Transport setting | Engine still current, unchanged since — superseded only by the UI/sound work below. Add/swap ~1–2s, ↻ ~7s, retry-forever |
| v5.2 | Hover-strip restyle (stronger scrim, shadowed button faces, brighter readouts; zero geometry change) + **wheel-over-pane volume** (10%/notch, `.vpop` % pill, Ctrl+wheel spared) | First-ever scroll: no sound and a frozen, jumping picture — Chrome pauses a video unmuted without user activation, and a wheel scroll is not an activation (§9 item 8) |
| **v5.3** | **Autoplay-lock fix**: a blocked unmute recovers instantly (re-mute + keep playing → stream never pauses), the volume wish is queued, and the **first click anywhere arms sound** on every pane ("N% · click once for sound") | ✅ Current. Root cause was Chrome policy, not the app; one activation is sticky for the page's lifetime |

**Launcher history (30 Jul 2026)** — separate track from the app builds above:

| Attempt | What it was | Outcome |
|---|---|---|
| PowerToys Workspaces | restore window layout (size/position) at one click | ❌ Workspaces restores *programs, not their command lines* → blank Chrome (no `--app=` arg) + an empty console (no bat inside). Patchable via each app's "Command line arguments" box in the workspace editor, but superseded instead |
| **CameraWall.exe build 1** | hidden go2rtc + `chrome --app` + launcher-owned placement memory (`wall-window.json`), single-instance mutex, off-screen guard, per-monitor-v2 DPI | ✅ **Adopted.** ✕ closes wall + launcher; relay stays warm by design (idle = zero camera sessions) |
| build 2 | build 1 + hidden `taskkill /IM go2rtc.exe /F` when the wall closes (opt-out via `keep-go2rtc.txt`) | Built, **shelved** — owner prefers the relay warm and nothing extra running at close time. exe not kept; behavior documented here if ever wanted again |

**The decisive log analyses:**
- *14:40 log:* every reconnected producer died at exactly **30.1s** with overlapping starts → go2rtc's pion WebRTC session timeout holding the camera slot for a browser that never connected; an EOF burst on Driveway when the pile-up hit the camera's hard session cap. Also: DELETE demonstrably does **not** stop a stalled producer.
- *14:54 log + screenshot:* screenshot wording ("Retrying in 15s · attempt 15") proved build 4.0 was still running — the stale-cache smoking gun. And the reload at 14:56:51 attached to producers started by "failed" attempts and got **instant video** → producers were healthy all along → the real fault is the **Chrome↔go2rtc WebRTC leg**, not the camera side.
- *15:11 log (build 5.0):* WebRTC failed on **every** attempt including fresh-restart firsts; MSE succeeded on **every** attempt and held for minutes. Each add/refresh = failed rtc (12s) + zombie cool (~22s) + instant MSE → hence 5.1.

---

## 9. Measured Facts About This Environment

These were observed, not assumed — re-verify before relying on them after any upgrade:

1. **go2rtc 1.9.14 `PUT /api/streams` on an existing name appends a source** (multi-source feature); it does not replace. `PATCH` replaces; `DELETE /api/streams?src=` removes the entry but does **not** tear down an active/stalled producer or consumer.
2. **go2rtc's WebRTC consumer waits ~30.1s** for a browser that never completes ICE, holding the camera's RTSP slot the whole time.
3. **Tapo slot release needs ~a few seconds** after even a clean close — 1.5s reconnects reliably produced no-media sessions; 6s works. Tapo tolerates ~2 overlapping sessions on stream1, sometimes; past that it EOFs new connections instantly.
4. **WebRTC over loopback is broken on this Windows box** (0% success in final logs, even fresh page + fresh go2rtc), cause unidentified — suspects: Windows Firewall rule for go2rtc.exe UDP, security software, or a Chrome/network change, since it *did* work once on 30 Jul ~14:40. **MSE over WebSocket: 100% success.**
5. go2rtc serves `static_dir` files with cacheable headers; Chrome app windows will run stale HTML indefinitely. Hence the loader stub.
6. go2rtc's RTSP server defaults to **all interfaces** (`:8554`) — must be pinned to `127.0.0.1` explicitly.
7. Tapo PCMA audio: WebRTC-native passthrough; auto-repacked to FLAC for MSE. ffmpeg never required.
8. **Chrome refuses audible playback until the page has seen a real user activation** (click / tap / key press) — **a wheel scroll does not count** — and unmuting a muted autoplaying video without activation makes Chrome **pause it**. On this wall that pause plus the 2s latency-chaser (yanking `currentTime` to the live edge while paused) looked like a frozen, jumping "lagging" stream. One activation is sticky for the page's whole lifetime. Measured 31 Jul 2026; fixed app-side in 5.3 (recover-and-queue). Lift-able only at Chrome level (flag/policy) if ever wanted — owner declined, first-click unlock is fine.

---

## 10. Expected Timings & Behavior (Build 5.1, MSE learned)

| Action | Time to picture | Why |
|---|---|---|
| Launch (3 panes) | ~1–3s, staggered 600ms | attach or fresh PUT, no cooldowns |
| Add / show / swap camera | ~1–2s | new stream, camera has no cooldown entry |
| ✎ edit, name only | instant | no reconnect at all |
| ✎ edit, address/quality | ~1–2s (that pane only) | diff render; others untouched |
| ↻ on a live pane | ~7s with countdown | 6s Tapo slot release + reset — firmware-bound |
| Retry after a failure | ~1s (attach) → full reset from 2nd failure | attach-first ladder |
| Camera power cut | auto-recovers when camera boots | frozen-detect → endless attach/reset cycle |
| go2rtc killed | auto-recovers on restart | "go2rtc not answering" knocks every ~7s |
| First launch ever / after re-enabling Auto | one-time +6s | WebRTC probe, then learned away |
| Close wall → reopen | ~1–3s | launcher exited, relay stayed warm; attach-first, no cooldown; port check means never a second go2rtc |

---

## 11. Pending Cleanup (debug logging is still ON)

The quiet-launcher half is **done** — CameraWall.exe runs go2rtc with no console at all (output still lands in `go2rtc.log`). Remaining:
1. `go2rtc.yaml` → replace the whole `log:` block with:
   ```yaml
   log:
     level: warn
   ```
2. Run `restart-go2rtc.bat` once. (Keep restart-go2rtc.bat's tee version as-is — having a console during a manual restart is useful.)

To re-enable debugging later: restore the debug `log:` block (§3), restart. Log readable in `C:\go2rtc\go2rtc.log` or at `http://127.0.0.1:1984/api/log` — there is no console window anymore. Stream state JSON: `http://127.0.0.1:1984/api/streams`.

---

## 12. Troubleshooting Quick Reference

| Symptom | Meaning / fix |
|---|---|
| Footer shows old build number | The window predates the file — close it fully and relaunch. (Post-5.0 this should be impossible; if it happens, wall.html was overwritten — restore the stub.) |
| "go2rtc not answering" | Relay not running → cameras.bat or restart-go2rtc.bat |
| "Stream error: <text>" | go2rtc's own words. 401 = bad Camera Account (Driveway is `itsnedd2`); dial timeout/refused = wrong IP or camera offline; EOF = camera slamming door (slot cap — close VLC/Tapo-app viewers or restart-go2rtc.bat) |
| "No picture" repeating on `rtc` tag | WebRTC broken again — set Transport to MSE (or Auto re-learns after one failure) |
| "Cooling down · Ns" | Working as designed — camera slot releasing; only reset-path attempts pay this |
| Pane crunchy/shimmery when small | Downscaling artifact → switch that camera to SD and/or Softness ~0.3–0.5px |
| Everything dead, retries not catching | Nuclear: restart-go2rtc.bat (kills every camera session instantly) |
| Settings vanish | localStorage blocked (the panel warns) — don't run the wall itself in Incognito |
| Chrome doesn't open | auto-detect failed → put the full path to chrome.exe in `chrome-path.txt` next to CameraWall.exe |
| "Windows protected your PC" on first launcher run | SmartScreen on an unsigned exe → More info → Run anyway, once |
| Wall opens at a weird place / want a fresh position | delete `wall-window.json` (next open uses Chrome's default, then re-remembers) |
| Double-clicked the icon, "nothing" happened | wall was already open → the launcher focused the existing window (by design, never a second wall) |
| go2rtc.exe still in Task Manager after closing the wall | **by design** (build 1) — idle relay, zero camera sessions, ~0% CPU; stop it with stop-background-silent.vbs (silent) or restart-go2rtc.bat's taskkill / Task Manager if ever needed |
| Scrolled volume up but silent; pill says "click once for sound" | By design (5.3): Chrome audio-locks the page until its first click — click anything once and the queued volume kicks in on every pane (§9 item 8) |
| Double-clicked a silent .vbs, "nothing" happened | Usually working as designed — no windows ever. Verify: go2rtc.exe PID changes / go2rtc.log timestamp refreshes (restart), or both processes vanish (stop). If truly inert: the file lost its `.vbs` extension on download, or needs right-click → Properties → Unblock (§3) |
| A hidden idle cmd.exe sits next to go2rtc.exe in Task Manager | The current relay session was started by restart-go2rtc-silent.vbs — that cmd is only the go2rtc.log pipe and dies with go2rtc (§3) |

---

## 13. Future Improvement Ideas

- **Get WebRTC back (~0.4s latency vs MSE's ~1s):** after any Windows update, firewall change, or reinstall, flip Transport → WebRTC and press ↻ on one pane. One success and Auto re-learns it permanently. To hunt the current breakage: Windows Firewall → check inbound/outbound rules for `go2rtc.exe` (UDP 8555 loopback), try temporarily disabling third-party AV, and watch `chrome://webrtc-internals` during a connect attempt.
- **Auto-start on boot:** shortcut to CameraWall.exe in `shell:startup`, or a Task Scheduler job at log-on.
- **Recording / motion events:** out of scope for go2rtc alone — Frigate (which embeds go2rtc) is the natural next step; this project's stream URLs and yaml port straight over.
- **Snapshots:** go2rtc exposes `GET /api/frame.jpeg?src=<name>` — a per-pane "still" button existed in v1 and could return in ~15 lines of app.html.
- **Remote viewing:** never port-forward (go2rtc's API on localhost skips auth and its `exec` source is remote-code-execution if exposed). Tailscale on the PC + phone, then browse `http://<tailscale-ip>:1984/wall.html` — requires widening `api.listen` to the Tailscale interface only and adding `username/password` + `local_auth: true` in the yaml.
- **PTZ:** go2rtc has ONVIF support; Tapo pan/tilt models could get arrow controls in the mini editor.
- **go2rtc upgrades:** pin 1.9.14 until there's a reason. Before adopting a new version, re-verify §9 items 1–2 (PUT/DELETE semantics, 30s consumer timeout) — the cooldown ledger's constants depend on them. A future go2rtc that fixes DELETE teardown would let the ledger shrink.

---

## 14. How to Modify the App Safely

1. Edit `www\app.html` only. Bump `const BUILD='5.2'` (or whatever) near the top.
2. Close the camera window fully, relaunch, confirm the footer shows the new number.
3. Never edit `wall.html` — it is the freshness guarantee. Never re-add `--window-size` flags to any launcher — window bounds belong to the launcher's `wall-window.json` (with Chrome's own per-URL memory underneath).
4. If a change touches connection logic, turn debug logging back on (§11 reversed) for the first test and watch producer start/stop pairs in the log — the 30.1s signature returning means orphaned WebRTC consumers again.
5. localStorage schema changes: introduce a new key version and migrate from the old one (the `tapo.wall.v3/v2/v1` migration chain in app.html is the pattern to copy).
6. Launcher changes: edit `main.go`, bump the build number in its header comment, then on any machine with Go ≥1.21: `go mod init camerawall` (first time only), then `GOOS=windows GOARCH=amd64 go build -trimpath -ldflags "-s -w -H windowsgui" -o CameraWall.exe .` — `-H windowsgui` is what prevents any console window from appearing.

---

## 15. Security Posture

- Everything binds `127.0.0.1`: api :1984, rtsp :8554, webrtc :8555. Nothing on the LAN can reach any of it; Windows Firewall never even prompts.
- CameraWall.exe listens on nothing; its only network act is dialing `127.0.0.1:1984` to check whether the relay is up.
- **Never** expose port 1984 to the internet — go2rtc skips auth for local requests and its API can execute commands (`exec` source). Exposure = cameras and PC compromised.
- Passwords exist in three places: the Tapo Camera Accounts, this document, and the page's localStorage (camera list + address history — "Clear address history" purges the latter).
- Remote access, if ever wanted, goes through Tailscale (§13), never port forwarding.

---

# PART 2 — THE NATIVE REWRITE (CCTV Streamer)

Everything below is the second life of this project: the same wall, rebuilt as **one native Windows exe** — no Chrome, no go2rtc, no relay, no browser rules. The Chrome system above (Part 1) remains installed, untouched, and is the fallback until the native app reaches feature parity. This document is the project's only memory (conversations are incognito), so every milestone, measurement, and decision lands here the moment it happens.

---

## 16. Why Native, and the Plan

Chrome imposed the three annoyances the wall ever had: the user-activation audio lock ("click once for sound"), MSE buffering latency, and a relay process (go2rtc) that had to be babysat by launchers and silent scripts. Going native removes all three and the answer to "how many processes?" becomes **one**.

**Frozen decisions (agreed before M1):**
- Single portable exe, statically linked, nothing extracted at runtime. LGPL build (ffmpeg n7.1, `--disable-everything` + explicit enables), no GPL parts.
- RTSP over TCP → ffmpeg libavcodec with **D3D11VA hardware decode** (H.264 + HEVC — dodges the Microsoft Store HEVC codec trap entirely), copy-back to system memory, software fallback.
- Direct3D 11 flip-model presentation; PCMA audio via **WASAPI** shared mode.
- The 5.3 dark UI cloned pixel-for-pixel from `app.html`'s CSS (fonts Bahnschrift Condensed / Consolas / Segoe UI all ship with Windows).
- Cooldown ledger + retry-forever engine ported (Tapo ~2 sessions/stream, ~6 s slot release — §9 still rules).

**Milestones:** M1 two-pane proof ✅ → M2 full wall + audio + strip ✅ (in test) → M3 settings sheet, per-pane editor, `settings.json` → M4 watchdogs & frozen-feed detection → M5 polish (true fullscreen, softness shader, single-instance, installer-grade naming).

## 17. Native Architecture

```
7× worker threads ──RTSP/TCP──▶ libavformat ─▶ libavcodec (D3D11VA hw, copy-back)
      │                                            │ video: NV12/P010 planes → per-pane D3D11 textures
      │ audio pkts ─▶ pcm_alaw decode ─▶ s16 ring  │
      ▼                                            ▼
 WASAPI thread ◀── per-pane volume ──── render loop (main thread, 60 Hz, flip-model swapchain)
 (mix + linear resample 8k→mix rate)     UI: baked GDI text/plates + procedural shaders
```

- **One process.** Workers own their sockets and decoders; the render thread never blocks on the network; the audio thread only ever touches lock-guarded rings and atomic volumes. No lock is ever held across a decode, upload, or device call.
- Frame handoff is triple-buffer pointer swaps (worker → shared → render scratch) — the 4K HEVC pane costs ~1 ms of lock time, not 12 MB of copying under contention.
- ffmpeg log spam from Tapo's malformed SEI is deduplicated: first occurrence + "×N more" summaries every 30 s.

## 18. Build Recipe (exact, reproducible)

- Toolchain: `x86_64-w64-mingw32-g++` 13 (win32 threads) + nasm + `x86_64-w64-mingw32-windres`.
- ffmpeg **n7.1** configured minimal (Build 4 exact): `--enable-cross-compile --arch=x86_64 --target-os=mingw32 --enable-static --disable-shared --disable-programs --disable-doc --disable-debug --disable-avdevice --disable-swscale --disable-swresample --disable-avfilter --disable-postproc --disable-everything --enable-network --enable-protocol=tcp --enable-protocol=udp --enable-protocol=rtp --enable-demuxer=rtsp --enable-demuxer=sdp --enable-decoder=h264 --enable-decoder=hevc --enable-decoder=pcm_alaw --enable-decoder=pcm_mulaw --enable-decoder=aac --enable-parser=h264 --enable-parser=hevc --enable-parser=aac --enable-d3d11va --enable-hwaccel=h264_d3d11va --enable-hwaccel=hevc_d3d11va --enable-hwaccel=h264_d3d11va2 --enable-hwaccel=hevc_d3d11va2`. **The `*_d3d11va2` hwaccels are mandatory** — they are the modern `AV_PIX_FMT_D3D11` device-context path the app uses; without them hardware decode silently degrades to software. Static libs ~6.6 MB. LGPL.
- Resources: `x86_64-w64-mingw32-windres camerawall.rc -O coff -o camerawall.res` — icon id 1 (`camerawall.ico`, 9 sizes) + VERSIONINFO ("Native M3 Build N", bump per build).
- One compile line (M3 Build 4): `x86_64-w64-mingw32-g++ -O2 -std=c++17 -mwindows camerawall_m3.cpp camerawall.res -I<ffbuild>/include -L<ffbuild>/lib -lavformat -lavcodec -lavutil -ld3d11 -ldxgi -ldxguid -luuid -ld3dcompiler -lgdi32 -luser32 -lole32 -lws2_32 -lbcrypt -liphlpapi -static -static-libgcc -static-libstdc++ -o CCTV-Streamer-M3-Build9.exe` then `x86_64-w64-mingw32-strip` (Build 9 stripped: 4,799,488 bytes).
- Result imports **only** Windows system DLLs (bcrypt, d3d11, D3DCOMPILER_47, GDI32, KERNEL32, msvcrt, ole32, USER32, WS2_32). dwmapi and the per-monitor-DPI APIs are loaded dynamically; Build 2's SHELL32 import left with the mailto: removal in Build 3. If the import list ever grows past system DLLs, something is wrong.

## 19. Milestone Log — measured, owner-confirmed

**M1 (2 panes, proof)** — 31 Jul 2026, first compile ran first try. GPU NVIDIA RTX 2000 Ada Laptop. Indoor HEVC 3840×2160 + Gate H.264 2688×1520 both hw-decoded (`d3d11va(copy)`): pipe 56 ms, decode 7.3 ms on the 4K stream. Clean exit. Verdict: "runs well".

**M2 build 1 (full wall)** — 31 Jul 2026. All 7 cameras live on the 3-column grid, WASAPI audio mixing multiple unmuted panes simultaneously, hover strip cloned from 5.3, dark title bar, ↻/✕/⛶ all functional.
- **Task Manager, owner-measured:** 7 streams = **3.4% CPU · 24.1% GPU · 587.8 MB · 11.1 Mbps**. 3 streams = 1.2% CPU · 9.9% GPU · 324.2 MB · 4.4 Mbps.
- Owner verdict: *"Everything is streaming and running correctly… sound works alright no issues found even with all of them open… overall i like how it looks."*
- Punch list from the same test → **M2 Build 2** (§21).

**M2 Build 2 (identity + fixes)** — 31 Jul 2026, shipped **and owner-approved same day**: reset blackout "normal and working like before", stamps "to my liking", close-two-quit-relaunch memory "all good", window placement "all good". Two carry-overs found in the same test → §23: (a) icon shows in taskbar/Task Manager/file properties but **not the title bar** — the window class never got an HICON (taskbar reads the exe resource, the caption reads the class/WM_SETICON; fix is two SendMessage lines); (b) grid panes still crop — expected, that is the cover fit the owner chose, and the real fit control (cover/contain/stretch) is M3's settings sheet. Originally shipped as: Everything in §21 delivered: blackout on reset/drop, fullscreen = contain (OSD always visible), stamps pinned 7/11 px, `settings.json` (window placement + closed panes, **R** restores, delete = reset), exe renamed **CCTV-Streamer-M2-Build2.exe** with VERSIONINFO + embedded bullet-cam icon. Owner choices recorded: title exactly *"TAPO/RTSP CCTV Streamer by @neddscape — Native M2 · Build 2"*, icon **A (bullet cam)**, grid fit stays **cover** until the M3 setting.

## 20. Native Controls (M2)

| input | action |
|---|---|
| hover pane | 5.3 strip fades in (scrim, LED, slider, readouts, buttons) |
| wheel over pane | volume ±10 %/notch, "35 % / off" popup — no click-to-arm, that was Chrome's rule |
| slider drag/click | set volume, 0 = muted (all panes start muted, like 5.3) |
| ↻ | hard reset; 6 s slot-release countdown if it was live |
| ⛶ | pane fills the **window** only · ⛶ again or Esc back to the wall — "⛶ always means window" |
| double-click pane | **Build 4:** borderless fullscreen on the **current monitor** (covers the taskbar) · double-click again or Esc → the normal windowed wall, all panes — "double-click always means monitor" |
| ✕ | close pane (frees the Tapo slot) |
| Esc | peels one layer: editor → back · sheet → wall · **monitor fullscreen → windowed wall** · window pane-fullscreen → wall · plain wall → **quit** (locked) |
| D | diagnostics overlay (codec · res · fps · decode ms · kb/s · hw/sw · audio) |
| ✎ · ⚙ | stubs until M3 (show "arrives in M3" note) |

## 21. M2 Build 2 — Owner's Test Punch List (31 Jul 2026) — ✅ ALL SHIPPED IN BUILD 2

1. **Blackout on reset** — ↻ currently leaves the last frame visible under the countdown; build 2 blacks the pane the moment it isn't live (Chrome behaviour, owner preference).
2. **Stamp position** — baked texture has internal slack, so GATE/BALCONY sit ~15 px too far from the corner; build 2 trims to ink and pins at exactly 7 px / 11 px like the CSS.
3. **Pane-fullscreen shows the whole frame** — switches to *contain* (letterbox) so Tapo's burned-in OSD is never cropped. Grid fit: owner chose **cover** (5.3 default) until the M3 settings sheet.
4. **`settings.json` v1** — remembers window size/position/maximized **and which panes are open** (Chrome-app parity the owner asked for). New **R** key restores all closed panes; deleting the file resets everything. Volumes intentionally not persisted (5.3 never did).
5. **Identity** — exe renamed **CCTV-Streamer-M2-Build2.exe**, VERSIONINFO resource (Task Manager shows the friendly name), embedded multi-size icon. Owner chose the full title verbatim and icon A (bullet cam). Version scheme: builds count within a milestone; M3 opens as "Native M3 · Build 1".
6. Known-accepted for now: 3-pane grid ratio (fit setting comes with M3), audio device switch needs an app restart.

## 22. Native Files

| file | role |
|---|---|
| `camerawall_m3.cpp` | **the entire application — Build 4 rebuild, ~2,540 lines, 8 sections** (utils/log → data model + settings → decode workers → WASAPI mixer → D3D11 renderer + GDI baker → wall UI → modals → input/window/WinMain). **KEEP THIS FILE — it ships with every build from Build 4 on (§24)** |
| `camerawall.rc` + `camerawall.ico` | icon (9 sizes, recovered from the Build 3 exe) + VERSIONINFO; version string bumped per build |
| `CCTV-Streamer-M3-Build9.exe` | current build (4,799,488 bytes) — icon + VERSIONINFO embedded |
| `README-M3-Build9.txt` | what changed + the retest list, shipped alongside the exe |
| `cameras.txt` (optional) | `Name\|rtsp://…` per line, up to 9 panes; absent = the 7 built-ins from §7 |
| `camerawall.log` | written fresh next to the exe every run; dedupe + ffmpeg-spam summaries keep it readable |
| `settings.json` | **v2 — the source of truth** (§23): window/fit/soft/hist/cams in wall order · **fullscreen bounds are never written** (Build 4 law) · delete = factory reset |

## 23. M3 — Scope Locked Before Build (1 Aug 2026 session)

The owner's brief: *"make sure this is final build for now"* — M3 must be a parking spot the wall can live on. Scope:

1. **⚙ Settings sheet** (the gear becomes real) — modal over the wall, 5.3 `#setup` styling: camera list (on/off · name · HD/SD · edit · delete · add), **wall fit segment: cover / contain / stretch** (grid only — pane-fullscreen stays locked to contain, that decision is settled), softness slider (pending owner choice below), build/GPU/audio ground-truth line.
2. **✎ Per-pane editor** — the 5.3 `.mini` clone: camera picker, name (≤22), RTSP address with remembered-URL history, HD/SD (stream1/stream2), Apply reconnects the pane. Requires a native text-edit widget (caret, arrows, backspace, paste) — built in the same baked-UI style, no Win32 EDIT controls breaking the look.
3. **settings.json v2** — full camera list becomes the source of truth (name/url/res/on + fit/soft + window). First run seeds from `cameras.txt` if present, else the 7 built-ins, then the file owns it. Volumes stay unsaved (settled).
4. **Title-bar icon fix** — class HICON + WM_SETICON big/small.
5. **Single-instance guard** — named mutex; second launch focuses the first instead of fighting it for Tapo slots (pulled forward from M5; a real footgun for a daily-driver build).
6. Already inherent, no work needed: M4's frozen-feed watchdog is effectively covered by the 8 s read deadline → any stalled stream lands in the retry engine.

**Owner choices — locked 31 Jul 2026:** softness **ships in M3** (live slider, in-shader 9-tap tent blur, cost only when > 0) · reorder = **drag panes on the wall** (origin dims, target gets a LED frame, name pill rides the cursor, Esc cancels) · Esc on the plain wall **keeps quitting instantly**.

**M3 Build 1 — shipped 31 Jul 2026** (`CCTV-Streamer-M3-Build1.exe`, 4,829,696 bytes, source `camerawall_m3.cpp` ≈ 3,050 lines). Everything above landed, plus:

- **settings.json v2 schema** — `window{show,x,y,w,h}` · `fit` (`"cover"|"contain"|"stretch"`) · `soft` (0–30 → 0.0–3.0 px) · `hist[]` (≤ 12 remembered RTSP addresses) · `cams[]` of `{name,url,res:"hd"|"sd",on:0|1}` **in wall order**. If `cams` exists it is the whole truth — `cameras.txt` and the built-in seven are first-run seeds only. A v1 file (window + `closed[]`) migrates automatically. Deleting the file is a factory reset.
- **Editable Cam under an SRWLOCK** — the worker snapshots name/url/res at each connect cycle, so the editor can rewrite a camera while its thread streams; APPLY flips the existing `reconnect` flag and the pane rebuilds through the normal RESETTING path. HD/SD works by swapping the `streamN` digit in the address at connect time (no-op if the address has no `stream1/2`).
- **Delete is honest** — a deleted camera trips the ffmpeg interrupt immediately (same path as ✕), its worker thread exits for good, and the Tapo slot frees; the two-click **SURE?** arm (2.5 s) guards against slips. Added cameras spawn their worker instantly with no stagger.
- **Native text widget** — caret, click-to-place, arrows/Home/End, Backspace/Delete, Ctrl+V, Tab/Enter/Esc, horizontal scroll keeping the caret in view — drawn entirely in the baked-UI style (dark face, seam border, LED focus ring, blinking LED caret). No stock Win32 EDIT boxes anywhere near the wall.
- **Modal architecture** — `UM_WALL / UM_SHEET / UM_EDIT` state machine; the render loop emits per-frame hit rectangles (`g_hits`) and a dedicated modal proc consumes them, so the sheet and editor are pure paint + data like everything else.
- Title-bar caption icon via class `HICON` + `WM_SETICON` big/small; **single-instance** named mutex checked before the log opens — a second launch focuses the running window.

---

### M3 Build 1 — owner test, same day

Passed: fit switch + persistence · softness ("not much of a difference with the GPU load") · wall drag-reorder + persistence · pen rename/reconnect · SD flip · single instance · caption icon. **Failed: adding cameras.** Symptoms: added camera lands as a grey, un-deletable duplicate of pane #1; a deleted camera can't be re-added; deleting the visible duplicate deletes its twin.

**Root cause** — the Build 1 "no stagger for runtime adds" patch set `c->index = 0`, but `g_order.push_back(c->index)` uses that field as the camera's *identity*. Every add therefore pushed camera #0 into the wall order again, while the real new `Cam` (and its already-running worker/stream) became an unreachable orphan. One wrong line, four owner-visible symptoms — and a save during that state wrote the duplicate into settings.json.

### M3 Build 2 — 31 Jul 2026 (`CCTV-Streamer-M3-Build2.exe`, 4,844,032 bytes)

**The fix:** identity and stagger are now separate fields (`index` = position, new `stag` = connect-stagger slot, 0 for runtime adds). `sanitizeOrder()` runs inside every `computeVis()` — dedupes, drops out-of-range/deleted entries, appends any orphaned live camera — and `loadSettings` skips exact name+url duplicate rows, so a settings.json corrupted by Build 1 heals itself on first launch (logged).

**Owner observations shipped in the same build:**
1. Pen editor is a **mini popup anchored on its pane** again (web-build style, wall visible, no full dim, outside-click dismisses); sheet-opened editor stays centered over the dim.
2. **CAMERA ▾ picker restored** in the editor (all cameras + "+ NEW ADDRESS", 5.3's `mpick`), address-history rows unchanged. Modal hit-dispatch flipped to topmost-last so the dropdown floats above the fields.
3. **Sheet scrolls** (wheel + slim scrollbar) when the window is short; window is **resizable while modal** — the modal WM_SETCURSOR was swallowing non-client hit codes, so Windows never showed the resize arrows; now passed through.
4. Support line under the build line: "For support, contact: **neddscape@gmail.com**" in LED, hover-underline, click → `mailto:` via ShellExecuteW (adds SHELL32 to imports — now ten system DLLs).
5. Section header **WALL → DISPLAY** (owner found "WALL" opaque; it heads FIT + SOFTNESS).
6. **Row drag-reorder in the sheet** too — LED insertion line + name pill; on-wall drag unchanged.
7. **Mute toggle** on every strip after the volume % (Segoe speaker glyphs U+1F50A/U+1F507, icon slots 4/5); remembers the pre-mute level per pane in `PaneUI.volPre`; session-only, volumes still never persisted.
8. **Fullscreen follows fit** — stretch stays stretch, contain stays contain, cover falls back to contain (the "whole broadcast always visible in fullscreen" law survives; only the letterboxing is now optional).
9. **Crisp modal text** — draw positions snapped to whole pixels in `drawTex`/`drawTexPart`/border; centered layouts at odd client widths were landing on half-pixels and bilinear-blurring every glyph.

### M3 Build 2 — owner retest, same day

Passed: add/delete/re-add cycle · settings memory · fullscreen-follows-fit ("stretched double click… confirmed") · sheet scroll + resize + readable text · mute + volume "fully working to my liking". Two misses: (a) the pen's CAMERA picker changed nothing on the wall — it only selected which camera's *settings* were being edited, while the owner (and 5.3) expect it to switch what the pane shows; (b) clicking the support email opened a browser with a blank address bar — the machine has no mail app registered for `mailto:`, which no exe can repair.

### M3 Build 3 — 31 Jul 2026 (`CCTV-Streamer-M3-Build3.exe`, 4,843,520 bytes)

1. **Pane takeover** — `paneTakeover(anchor, x)`: from a pen-opened editor, picking camera X and applying swaps X into the anchor pane's order slot, switches X on, and parks the anchor camera off in X's old slot (recoverable — nothing deleted). "+ NEW ADDRESS" from a pane behaves identically with the freshly created camera. Sheet-opened edits still never touch the wall.
2. **Support email → clipboard** — click copies `neddscape@gmail.com` + toast, replacing the unreliable `mailto:` ShellExecute (owner's machine has no mail handler; the browser fallback showed a blank page).
3. **Pen popup right-anchored** to its pane with a 120 ms fade-and-rise, driven by a `uiA` draw-alpha multiplier threaded through all four base draw lambdas (zero per-widget changes).
4. **RESET WALL** button in the sheet — every camera on, order/addresses/fit/softness untouched; toast + log.
5. **Pen popup decluttered** — address-history rows suppressed when `g_editFrom == 1` (they stay in the sheet-opened editor).

### M3 Build 3 — owner retest, 1 Aug 2026 — ✅ APPROVED

All five Build 3 items pass — pane takeover, "+ NEW ADDRESS" takeover, RESET WALL, email clipboard-copy, right-anchored decluttered pen popup: *"everything is working to my liking."* Build 3 is the behavioural reference for everything that follows.

## 24. The Source-Loss Incident — and the Law It Created (1 Aug 2026)

Preparing Build 4 surfaced a hole in the process: **no `camerawall_m3.cpp` (or `_m2.cpp`) was ever delivered to the owner.** Builds 1–3 shipped exe + README only; every build session is incognito, so each session's source died with it. Confirmed with the owner: "Never downloaded a .cpp file." The Build 3 exe is stripped — no source inside — and a 4.8 MB statically-linked optimized binary cannot be decompiled back into maintainable source.

**Recovered from the Build 3 exe** and folded into the Build 4 source: the complete HLSL shader suite verbatim (incl. the 5.3 scrim ramp with its original comment), every UI label and toast, every log-format string, the byte-exact settings.json writer, the RTSP option set, the WASAPI failure-stage strings, the mutex name (`CCTVStreamer_neddscape_single`), the window class (`CCTVStreamerWall`), all VERSIONINFO fields, and the 9-size bullet-cam icon.

**Build 4 is therefore a full rebuild:** `camerawall_m3.cpp` was rewritten from this document (written to be exactly this spec) plus the recovered material. Behaviour is intended to be Build-3-faithful; pixel geometry and small timings are reconstructions — hence the full-retest requirement.

**THE LAW:** from Build 4 onward, **every build's deliverables include the current `camerawall_m3.cpp` + `camerawall.rc` + `camerawall.ico`**, and the owner keeps them next to the exe in `C:\Users\USER\Downloads\CCTV\`. Any future session must ask for the source before changing anything; if it is ever missing again, this section is the recovery manual.

### M3 Build 4 — 1 Aug 2026 (`CCTV-Streamer-M3-Build4.exe`, 4,805,120 bytes, source `camerawall_m3.cpp` ≈ 2,540 lines — full rebuild, see §24)

**The feature (owner-specced verbatim):** *"⛶ always means window, double-click always means monitor."*

1. **Double-click a pane → true fullscreen on the current monitor** — borderless (`WS_POPUP`), covers the taskbar, sized to `MonitorFromWindow(MONITOR_DEFAULTTONEAREST)` so it lands on whichever monitor the wall lives on (the owner's wall sits on a secondary monitor at x = −1925), showing only that pane. The Build 2 fullscreen-follows-fit law applies (stretch stays stretch, contain stays contain, cover → contain). Works from the grid *and* from windowed pane-fullscreen.
2. **Exit = default, always** — Esc or double-click again restores the pre-fullscreen window style + placement and shows the **whole windowed wall** (owner: back to default *"with all the panes showing"*, never the single-pane window view). ⛶ pressed *while in* monitor fullscreen drops to the windowed pane view instead — ⛶ always means window.
3. **⛶ unchanged** — pane fills the window only; ⛶ again or Esc back to the wall.
4. **The Esc law, one layer per press:** editor → back · sheet → wall · monitor FS → windowed wall · window pane-FS → wall · plain wall → **quit** (the locked owner choice survives).
5. **settings.json never stores fullscreen bounds** — placement snapshots freeze while monitor fullscreen is active; the pre-fullscreen `WINDOWPLACEMENT` is what gets written.

Implementation: `enterMonFS()` snapshots `GetWindowPlacement` + `GWL_STYLE/GWL_EXSTYLE`, swaps to `WS_POPUP|WS_VISIBLE`, `SetWindowPos(HWND_TOP, monitor rect, SWP_FRAMECHANGED)`; `exitMonFS(toWindowPane)` restores both and clears the fullscreen pane unless ⛶ asked for the windowed pane view. `WM_LBUTTONDBLCLK` (window class has `CS_DBLCLKS`) fullscreens only on pane-body hits — double-clicking a strip button still acts as a click.

**Retest scope: everything** (rebuild) — the README-M3-Build4 list starts with the new fullscreen law, then walks the entire Build 1–3 surface. Known intentional touch-ups over recovered behaviour: RESET WALL/restore honour the 9-pane cap consistently.

### M3 Build 4 — owner test, 1 Aug 2026 — ❌ DOA

Died at startup on the owner's machine: *"Direct3D 11 could not start"*, log ending `GetBuffer 0x80004002` (E_NOINTERFACE). Root cause: the rebuild defines its COM GUIDs by hand to keep the import table lean, and two of the eight were each **one digit off** — `IID_ID3D11Texture2D` (real value `6f15aaf2-d208-4e89-9ab4-489535d34f9c`) broke the swapchain's GetBuffer, and `IID_IAudioClient` (real Data3 `0x4C32`, not `0x4C31`) would have failed audio at its `activate` stage on the first successful launch. Both had been written from memory; the fix pass verified **all eight** GUIDs against the mingw-w64 platform headers. **Lesson recorded: hand-defined GUIDs must be header-verified, never recalled.** Silver lining: the DOA log already proves settings load, DPI path, window placement restore, dark title bar, and NVIDIA adapter enumeration all work on the owner's machine.

### M3 Build 5 — 1 Aug 2026 (`CCTV-Streamer-M3-Build5.exe`, 4,805,120 bytes)

The two GUID corrections above — zero other changes. **The Build 4 feature set and full-retest requirement carry over unchanged** (README-M3-Build5).

### M3 Build 5 — owner full retest, 1 Aug 2026 — ✅ ALL PASSED

Every item passed: the Build 4 fullscreen law (all 7 checks — grid↔monitor, Esc peeling, ⛶-from-monitor-FS, second-monitor targeting, placement never polluted: *"the full screen feature is what i intended all check"*) **and** the entire rebuilt Build 1–3 surface (connect/stagger/audio/volume/mute, ↻/✕/R/D, wall drag-reorder, the whole sheet, pen takeover, settings persistence). The rebuild is owner-validated. Confirmations recorded in the same test: **zero background on close** (one process, no tray/service — confirmed by design), **performance = Build 3's measured architecture** (§19 numbers remain the reference), **retry-forever on brownouts** unchanged (8 s watchdog · 6 s cooldown · never gives up).

### M3 Build 6 — 1 Aug 2026 (`CCTV-Streamer-M3-Build6.exe`, 4,797,952 bytes) — owner polish list

Driven by two owner-supplied **Build 3 screenshots** (wall strip + settings sheet), which are now the styling reference for both surfaces:

1. **Strip readouts restored** — codec + decode latency beside ↻, Build 3 format `H264  21ms` (uppercase codec, `%dms`); strip buttons and the mute toggle always carry their thin seam borders; slider knob back to LED cyan.
2. **Settings sheet = Build 3 layout** — full-window dim overlay (no panel box), top-anchored column (~560 px, centred): `SETTINGS` + **CLOSE** button (Esc still works) → version line (`Native M3 · Build N · d3d11 · <GPU> · audio ok|starting|unavailable`) → support/email line → **DISPLAY** (FIT segment, filled-cyan selection with dark text · SOFTNESS short slider with `%.1f px` value beside it) → **CAMERAS** with `list-count / 9` → rows (✓-marked cyan checkboxes · mono names, dim when off, **the name area is the drag handle** — no grip glyph, matching the screenshot · HD/SD **twin boxes** · ✎ · ✕/SURE?) → `+ ADD CAMERA` (primary filled) · `RESET WALL` · `CLEAR ADDRESS HISTORY`. Camera-list cap clarified from the screenshot: **the list itself caps at 9** ("wall is full (9 panes)" fires on the 10th add).
3. **Text smoothed system-wide** — every string is baked at 2× and linearly downsampled with a gamma-lifted alpha (0.82) — kills the harsh/jaggy rendering at any window size; editor font sizes unified (12 px labels/fields); **stamps are letter-spaced uppercase Consolas** again (`SetTextCharacterExtra` at bake scale), pinned 7/11 px as before.
4. **Pen popup anchors to its own pane** — lower-right, just above the strip (Build 5 clamped rightmost-pane popups onto the neighbour; that heuristic is gone).
5. **Full address visible** — fields open with the caret at the start so `rtsp://…` shows from character one; popup widened to 344 px with 12 px mono.
6. **Text selection** in the native widget — mouse-drag highlight (LED, 30 %), Shift+arrows/Home/End, **Ctrl+A / C / X / V** (copy takes the selection, or the whole field when nothing is selected); typing/Backspace/Delete/paste replace the selection.

### M3 Build 6 — owner retest, 1 Aug 2026 — ✅ 7 of 8

Passed: strip codec readout, Build 3 sheet layout ("to my liking"), smoothed fonts, popup-on-own-pane, full address + highlighting, selection/copy-paste, HD/SD twin boxes, row drag. **Miss: latency read 0 ms** — plus three fresh polish items → Build 7.

### M3 Build 7 — 1 Aug 2026 (`CCTV-Streamer-M3-Build7.exe`, 4,797,952 bytes)

1. **Latency stopwatch fixed** — the rebuild timed only `avcodec_receive_frame`, but on the d3d11va path the dominant cost is `av_hwframe_transfer_data` (GPU→CPU copy-back) which ran *after* the timer stopped, so hardware panes measured ~0.4 ms → displayed `0ms`. The window now spans decode **+ copy-back** (what Build 3 evidently measured — the owner's 21 ms style numbers); the strip readout and the D-overlay `dec %.1f ms` share the fixed figure.
2. **Sheet dim deepened** to 0.86 (editor-over-dim 0.72) — the owner read the previous 0.74 as "totally transparent" on bright feeds.
3. **Gear visibility** — always-on dark plate (black 0.55) + seam border with a hover highlight (white overlay + LED border), and moved from y=8 to **y=38 px so it clears the third pane's stamp**.
4. **Glyph centring** — new `drawTextC()` centres boxed glyphs by their *baked bitmap* rather than font-metric math; applied to strip buttons, mute, gear, sheet ✎/✕, and the checkbox ✓ (the mute speaker had been hugging its box edge).

### M3 Build 7 — owner retest, 1 Aug 2026 — ✅ APPROVED (two follow-ups)

*"now i like this on build 7 everything is working to my liking"* — dim, gear, centred glyphs all pass; no further checklist requested. Two follow-ups spotted: the ms readout sat pinned at ~4 ms (decode time is nearly constant on hw decode — wrong metric, see Build 8), and the owner wants a border framing the settings area.

### M3 Build 8 — 1 Aug 2026 (`CCTV-Streamer-M3-Build8.exe`, 4,798,464 bytes)

1. **The strip ms is the 5.3 LIVE-DELAY, definitively** — the owner's Build 3 description settled the semantics: bouncing 5/15/42 ms in real time, climbing to ~800 ms during a blackout reconnect. That is the **inter-frame arrival gap**, not decode time. Implementation: worker stamps `lastFrame`/`frameGap` per decoded frame; the strip shows `frameGap`, switching to the live-growing `now − lastFrame` once it exceeds `gap + 150 ms` (so stalls climb on screen in real time and recover instantly). Decode time (`decMs`) remains on the D overlay as `dec %.1f ms`. **Doc correction:** Builds 6–7 assumed the readout was decode time; that assumption is retired.
2. **Settings framed** — the column sits on a panel (C_PANEL 0.60 face + seam border) over the 0.86 dim; content scrolls clipped inside the frame and the slim scrollbar rides the panel's right edge.

### M3 Build 8 — owner retest, 1 Aug 2026 — ✅ APPROVED

*"Nice! This time you nailed it. Everything works"* — live-delay readout and the framed settings both pass. Two refinements requested → Build 9.

### M3 Build 9 — 1 Aug 2026 (`CCTV-Streamer-M3-Build9.exe`, 4,799,488 bytes)

1. **MS UPDATE slider** — new settings row directly under SOFTNESS, same short-slider style, controlling how often the strip's live-delay readout refreshes: 0.0 s = per-frame (Build 8 behaviour) → 3.0 s hold, **default 1.0 s** so the number is readable. **Stall exception:** when `since > gap + 150 ms` the climbing value always displays live regardless of the slider — the climb is the alarm and is never held back. **settings.json v2 gains a key:** `"msup"` (0–30 → 0.0–3.0 s), written after `"soft"`; older files without it load fine and default to 10. Slider releases save immediately (softness drag now saves on release too).
2. **☰ row grips** — U+2630 before each checkbox marks the rows as draggable; the grip and the name area are both drag handles (LED insertion line unchanged). Checkbox and name shifted right 24 px to make room.

### M3 Build 10 — 29 Aug 2026 (`CCTV-Streamer-M3-Build10.exe`, 4,808,704 bytes) — CAMERA ROTATION

Owner-specced in the Build 10 session (clarifying answers recorded verbatim in spirit): *all panes rotating at once* with a per-pane *"this will stick / lock it"* button, *seamless — "preload it … no CONNECTING, boom live view"*, interval *3–60 s default 10*, plus one remembered polish: *the strip shadow covers too much — same opacity, just thinner / cut downwards, don't touch anything else.*

1. **The model** — every camera has a `rot` flag (default **true** = in the rotation pool). Cameras that are ON but locked (`rot=0`) are **pinned**; parked pool cameras wait in a FIFO (`g_rotQ`). Every tick, **all unlocked visible panes advance together**: pane *k* takes queue entry *k*, the outgoing camera rejoins the queue's back — fair round-robin, equal wall time. Pool membership has **two access points flipping the same flag**: a **⟳ checkbox** in each settings row (between the show-checkbox and the name; name/HD-SD geometry shifted 26 px right) and a **🔒/🔓 strip button** left of ↻, drawn only while rotation is ON so the Build 9 strip is untouched otherwise (locked = LED border + LED padlock).
2. **Seamless swap = preroll** — incoming cameras get `Cam.pre` set `lead = min(4 s, interval−1 s)` before the tick; their workers connect **hidden** (`on||pre` drives the whole connect machinery: outer loop, stagger, both read-loop gates, and the ffmpeg interrupt callback). The swap fires only when **every** incoming feed is `ST_LIVE` — or after a **6 s grace** (`ROT_GRACE_MS`), then it advances honestly showing the real state. The WASAPI mixer gained `&& c->on` so a hidden preroll can never leak audio; frames land in the triple buffer and upload on the swap frame, so the pane cuts straight to live video. Log lines: `rotation preroll · connecting hidden`, then `rotate: Gate -> K_Back, Balcony -> K_Side, …`.
3. **Scheduler laws** — driven per rendered frame (`rotTick()` at the top of `render()`), UI thread only. **Paused** whenever the wall isn't the plain grid: settings sheet, editor, windowed or monitor fullscreen, or a pane drag — pausing cancels any preroll and, on resume, re-arms a **fresh full interval**. **Every manual wall change resets the clock** (`rotKick()`): pane takeover, ✕/show-checkbox, R restore, RESET WALL, delete, and any `rot` flag flip; the interval slider's release also re-arms at the new pace. The wall never yanks a camera the owner just deliberately chose.
4. **Settings** — two rows under MS UPDATE, existing styling: **ROTATION** OFF/ON segments (FIT style) and **ROTATE EVERY** short slider, 3–60 s, `%d s` readout, dimmed to 0.45 while OFF, saved on release. **settings.json v2 gains:** top-level `"rotate"` (0/1) and `"rotsec"` (3–60) written after `"msup"`, and per-camera `"rot"` (0/1) after `"on"`. Older files load fine: rotation defaults **off**, interval 10, every camera in the pool — behaviour is Build-9-identical until the owner flips ROTATION ON.
5. **Strip scrim cut (owner polish)** — the hover strip's gradient band shrunk **84 → 46 px** (scaled); the shader ramp is untouched so bottom opacity is identical — the shadow now hugs the button row instead of climbing the picture. Nothing else on the strip changed.
6. New enums slot before `HT_E_PANEL`, preserving the editor's outside-click law; `DR_ROTS` joins the drag kinds; glyphs U+1F512/U+1F513 (Segoe UI Symbol, same family as the Build 2 speaker) and U+27F3 for the pool checkbox.

**Retest scope (Build 10):** ROTATION ON with 3 open / 4 parked → all three panes flip together, already live, no CONNECTING flash; lock a pane mid-cycle → it pins while the rest rotate; ⟳ unticks drop cameras from the pool; sheet/editor/fullscreen/drag pause and re-arm; manual takeover resets the clock; settings survive restart; rotation OFF = Build 9 behaviour; strip shadow visibly shorter at identical darkness.

## 25. Standing Orders From the Owner (recorded 29 Aug 2026 — every session obeys these without being reminded)

1. **Read this document first**, before touching anything (the owner opens every session with this instruction — it is now standing).
2. **Ask clarifying questions and get answers BEFORE building anything.** Pop the questions out first; the owner will answer; only then build. Never assume on ambiguous specs.
3. **Every build session is incognito — nothing persists except the delivered files.** Therefore **every** build delivers and the owner downloads ALL of: the exe, `camerawall_m3.cpp`, `camerawall.rc`, `camerawall.ico`, the `README-M3-BuildN.txt`, and **this updated documentation .md**. This extends §24's source law: the doc ships with every build too, because it is the only memory. The owner keeps everything next to the exe.
4. These orders were given with "put it in the memory so that I won't keep saying it" — an incognito session has no other memory, so this section IS that memory. Future sessions: honour it.

---

*End of record — two walls now. Part 1 is the proven Chrome system and stays the daily driver; Part 2 is the native successor being built milestone by milestone with every measurement logged above. Future-you: §9's measured facts still rule both worlds; this file **plus the shipped `camerawall_m3.cpp`** are the only memory either of them has — §24 and §25 are the laws that keep it that way.*
